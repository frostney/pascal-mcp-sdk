# Build system

The contract LWPT's build system satisfies, the self-host pattern that makes `lwpt` build `lwpt`, the bootstrap that breaks the chicken-and-egg, and the `[build]` manifest shape that downstream consumers use.

## Executive Summary

- **The contract:** single entry point from repo root (`./build/lwpt build`), a clean development build of every binary by default, named build entries as positional args, `--mode dev` (default) / `--mode release`, `--clean` flag, single `build/` output directory.
- **Self-host.** LWPT's own `lwpt.toml` declares `lwpt` as a `[build]` entry; `lwpt build` rebuilds the binary that just ran. See [ADR-0005](./adr/0005-self-host-build.md).
- **Bootstrap once per fresh clone.** `scripts/bootstrap.pas` (via `bootstrap.sh` / `bootstrap.bat`) produces the first `build/lwpt`. The script's `fpc` flags must stay in sync with the dev translation in `TLWPTFPCCompilerDriver.BuildArguments`.
- **Compiler output is invocation-private.** FPC executables and intermediates
  first land under `.lwpt/sessions/<session-id>/`. A completed executable is
  atomically published to its manifest `output` only after its declared inputs
  are revalidated.
- **Compiler-default target unless overridden.** A bare probe supplies the
  request target when `FPC_TARGET_CPU` / `FPC_TARGET_OS` are unset. Explicit
  overrides are strictly probed and translated to `-P` / `-T` when dispatch is
  required.
- **Compiler-neutral request first.** Build and test select a root-owned named
  compiler profile, validate a versioned request against on-demand compiler
  capabilities, and normalize the result through the selected driver. FPC is
  the implicit built-in fallback; Delphi, Blaise, and Lakon are explicit
  built-in profiles; external drivers exchange canonical TOML over short-lived
  child processes.
  Unsupported combinations are hard errors, with no compiler or target
  fallback. See ADR-0029 and ADR-0030.
- **Compiler processes are bounded duplex operations.** A shared runner writes
  request stdin while draining stdout and stderr, retains at most 16 MiB from
  each stream and discards later bytes while drainage continues, owns the
  complete process tree, and terminates it on timeout or capture failure.
  Stdin pumping and writer cleanup remain deadline-bounded when an escaped
  descendant retains the pipe.
  Capability probes time out after 30 seconds. Compiles
  default to 30 minutes; `LWPT_COMPILER_TIMEOUT_MS` sets a positive
  millisecond override for unusually short or long toolchains.
- **Dependency-aware parallel builds.** Independent ready build entries run in
  parallel by default, bounded by `--jobs=<n>` and the machine-wide
  `LWPT.WorkerBudget`. `--jobs=1` is the sequential escape hatch. See
  [ADR-0023](./adr/0023-parallel-build-target-scheduler.md).
- **Generator hooks** are declared in `[prebuild]` / `[postbuild]` / `[pretest]` per [ADR-0011](./adr/0011-build-lifecycle-hooks.md); each entry runs via InstantFPC with staleness gating (output older than any input → re-run). The earlier `[generated]` shape is no longer parsed.

## The contract

Every project on this stack satisfies the build-system contract from `native-nostalgia-stack`:

| Contract item | How LWPT satisfies it |
| --- | --- |
| Single entry point from repo root | `./build/lwpt build` |
| Clean development build of every binary by default | `lwpt build` (no args) builds every `[build]` entry in dev mode |
| Named build entries as positional args | `lwpt build cli` builds only `cli`; multiple entries are selected by passing more positionals |
| Bounded parallelism | Ready entries overlap by default; `--jobs=<n>` sets the invocation ceiling and the machine worker budget may lower it |
| Dev / prod distinction | `--mode dev` (default) / `--mode release` |
| Clean selection | `--clean` flag; combined: `lwpt build --clean cli` forces a full compile in fresh private staging |
| Single public output directory | Completed binaries land at the selected entry's `output`, conventionally under `build/`; compiler intermediates remain session-private |

## Self-host

LWPT's own `lwpt.toml` registers itself:

```toml
[package]
name = "lwpt"
version = "0.1.0"
units = ["source"]

[build]
lwpt = { source = "source/lwpt.pas", output = "build/lwpt" }
```

`./build/lwpt build` first probes and validates the requested target, then the
FPC driver produces:

- `-Sh` (Delphi-compatible string handling; objfpc/delphi-safe)
- `-FE .lwpt/sessions/<session>/jobs/lwpt-<mode>/bin`
- `-FU .lwpt/sessions/<session>/jobs/lwpt-<mode>/units`
- `@lwpt.cfg` (the cfg emitted by `lwpt install`; lists `-Fu source` since `units = ["source"]`)
- `-Fu source` (also added explicitly from `Man.Units`; redundant with the cfg but harmless)
- The driver's dev-mode flags (or release flags when `--mode release`)
- `-o .lwpt/sessions/<session>/jobs/lwpt-<mode>/bin/lwpt`
- `source/lwpt.pas`

After FPC exits successfully, LWPT revalidates the build publication
fingerprint under a short output-specific lock and atomically replaces
`build/lwpt`. The full mode-flag sets are in
`TLWPTFPCCompilerDriver.BuildArguments`:

| Mode | Flags |
| --- | --- |
| `dev` (default) | `-O- -gw -godwarfsets -gl -Ct -Cr -Sa` |
| `release` (`--mode release`) | `-O4 -dPRODUCTION -Xs -CX -XX -B` |

`--clean` does not delete shared paths. Every invocation already begins with
empty private staging; clean additionally passes `-B` for dev mode (release
already includes it) to force recompilation. The last successful executable,
another live session, legacy `build/targets/` directories, source-adjacent
artefacts, and the currently running LWPT executable remain untouched.

When a build fails with output matching a stale-artefact signature (internal
compiler exception, resource-compile errors, missing `.reslst`), `lwpt build`
prints a hint to retry with `--clean`. Failure classification and exit-message
shaping belong to `TLWPTFPCCompilerDriver.ClassifyFailure`.

### The current executable

Clean never deletes the current executable. Publication uses the platform's
atomic replacement operation (`rename(2)` on Unix and `MoveFileEx` with
replace/write-through on Windows), after the replacement candidate has
finished compiling in its session. If the operating system refuses the
replacement, LWPT reports publication failure and retains the completed
candidate for diagnosis rather than deleting the last successful executable.

## Bootstrap

The chicken-and-egg: `lwpt build` requires `build/lwpt` to already exist, but `build/lwpt` is produced by `lwpt build`. The resolution is a one-time bootstrap step:

```sh
./bootstrap.sh         # Unix
bootstrap.bat          # Windows
```

Both wrappers:

1. Check whether `instantfpc` is on `PATH`.
2. If yes, run `scripts/bootstrap.pas`, which invokes `fpc -Mdelphi -Sh <dev-flags> -FE build -Fu source -Fi source -Fu packages/<name>/source -Fi packages/<name>/source ... -o build/lwpt source/lwpt.pas` (one `-Fu` / `-Fi` pair per workspace package: `httpclient`, `cli`, `semver`, `toml`, `testing`) to produce the binary.
3. If `instantfpc` is not found, the wrapper falls back to a direct `fpc` invocation with the same flag set.

Both code paths are dev-mode only; release builds always go through `./build/lwpt build --mode release`.

An earlier bootstrap script also regenerated `source/LWPT.Embedded.TestingLibrary.inc` when `TestingPascalLibrary.pas` or `Shared.inc` were newer than the embedded blob. [ADR-0015](./adr/0015-drop-export-testing-becomes-workspace-package.md) deleted the embed model — the testing framework now lives in `packages/testing/` and is consumed via workspace auto-discovery like every other dep, so the staleness check is gone and the bootstrap script does one thing.

### Why a Pascal bootstrap and not pure shell

Both code paths produce the same binary; the InstantFPC wrapper exists so the bootstrap stays in the project's primary language (per the scripts rule in `project-structure`). The shell + batch fallbacks are duplicates of the same `fpc` invocation, kept as a defensive measure for environments where InstantFPC is unavailable.

### Flag synchronisation

The dev-mode flags in `scripts/bootstrap.pas` are the same set as the dev
translation in `TLWPTFPCCompilerDriver.BuildArguments`. They must stay in sync:
when one changes, the other changes in the same commit. A future small refactor
may lift them into a shared `scripts/bootstrap-flags.inc` `{$I}`-included from
both sites; for now, a comment in `scripts/bootstrap.pas` names the requirement.

## `[build]` shape

```toml
[build]
mybin = { source = "src/app.pas",     output = "build/mybin" }
cli   = { source = "src/cli/main.pas" }           # output defaults to source path without ext
app   = { source = "src/app/main.pas", depends = ["mybin", "cli"] }
objc  = { source = "src/objc.pas", flags = ["-k-ld_classic"] }
shortform = "src/quicktool.pas"                   # bare-string shorthand
```

- `source` (required): the program/`.dpr`/`.pas` file FPC compiles.
- `output` (optional): the binary path; defaults to `ChangeFileExt(source, '')`. On Windows, `.exe` is appended automatically when missing.
- `depends` (optional): entries that must publish successfully before this
  entry starts. Named builds include transitive prerequisites; unknown names
  and cycles fail before build work.
- `flags` (optional): ordered compiler-driver arguments for this root-manifest
  entry. Each TOML string is passed as exactly one argument, so values are not
  shell-split and duplicates remain significant. The field must be an array of
  non-empty strings. FPC accepts option-shaped values such as
  `-dISSUE95_FLAG` and `-k-ld_classic`; positional/response-file arguments and
  options that replace the selected compiler, request target, or
  session-private output paths are rejected. Build entries discovered in
  dependency manifests never contribute flags.
- Build-entry names become job-directory path segments inside a session, so the
  names `""`, `"."`, and `".."` are rejected at manifest load. Each segment
  combines a bounded readable prefix with a hash of the full entry identity,
  preventing sanitisation collisions without creating unbounded paths.

LWPT's own `lwpt.toml` is the reference: one `lwpt` build entry.

## Session staging and public outputs

Every `lwpt build` and `lwpt test` invocation creates a unique
`.lwpt/sessions/s-<pid>-<timestamp>-<counter>-<n>/` directory (PID and
timestamp base36-encoded — the slug prefixes every compiler staging path,
and FPC's file API silently truncates paths over 255 characters, so each
component stays short). Build-entry job directories contain separate `bin/` and
`units/` children used for `-FE`, `-FU`, and `-o`. No two processes share
writable compiler paths, even when they build the same entry and mode in
the same worktree. Before compiling, LWPT verifies the staging path plus
the longest reachable unit name fits the 255-character budget and refuses
the compile with an explanatory error when it cannot.

Before compiling, LWPT creates a schema-versioned `TLWPTBuildRequest` covering
the source set and entry point, output kind, mode, defines, search paths,
resources, ordered extra arguments, private output locations, target
OS/architecture, and requested compiler identity/version. Build-request schema
v2 adds the `extra_arguments` array. The canonical TOML serialization is
embedded in a separate publication fingerprint. That fingerprint also covers
the selected compiler executable/live version,
the previous public-output content, the implicit source directory, declared
unit/include/resource inputs,
manifest, cfg, lockfile, and installed module contents. After compilation it
reacquires machine-wide worker capacity and retains it through per-entry
postbuild, live compiler refresh, fingerprint revalidation, and atomic
publication. Publication takes a short output-specific lock, combining an
in-process critical section with an OS-held lock, and captures the same
fingerprint again. Search-root
hashing excludes `.lwpt/sessions/` and all declared build outputs, so a project
that declares `units = ["."]` tracks compiler inputs without treating private
staging or another entry's publication as an input. Explicit file inputs are
still hashed when they are also declared outputs. Workspace-package
symlinks and junctions are followed, with physical-directory cycle detection.
`LWPT_FPC_UNIT_PATHS` directories are content-hashed as both unit and include
inputs. Changed input, compiler version, or the requested public-output
generation means the result is stale: publication is refused and the candidate
stays private. Per-entry postbuild hooks receive `LWPT_BUILD_OUTPUT` for the
private candidate, `LWPT_BUILD_PUBLIC_OUTPUT` for the requested manifest path,
and `LWPT_BUILD_ENTRY` for the entry name. Existing `{item.output}`
references in their script, arguments, inputs, and staleness output are
retargeted to the private candidate at execution time when the expanded path
is a complete path token. Related paths such as `build/app.json` are not
rewritten. Hook definitions,
scripts, and declared inputs participate in publication revalidation. A hook
failure prevents publication. Dependency-free builds retain whole-build
postbuild as the final gate before batch publication. A declared graph
publishes prerequisites progressively so dependants start only after successful
publication; its whole-build postbuild consequently runs once after all
selected outputs publish. Artifact transformations therefore belong in the
per-entry hook. See ADR-0023.

Successful sessions remove compiler jobs and compiled hooks but retain stable
job logs and completed state for diagnosis. Failed, stale, or interrupted
sessions retain their private diagnostics. `lwpt repair` removes inactive
sessions only after their OS-held owner guard is absent; malformed state fails
closed while its guard remains held. Artifact reuse is deliberately absent
here and belongs to the content-addressed cache work.

`[version]` include files are staged beside their destination and generated
through true same-filesystem replacement before fingerprinting, so concurrent
builds never expose a missing or partially rewritten
compiler input.

## Cross-compile

```sh
FPC_TARGET_CPU=aarch64 ./build/lwpt build --mode release
```

With neither target environment variable set, the request uses the target
reported by the compiler's bare `-iV -iTO -iTP` probe and compilation stays
bare. `FPC_TARGET_CPU` and `FPC_TARGET_OS` replace their corresponding default
dimensions; the completed explicit request is validated strictly. The driver
adds `-P<value>` and `-T<value>` only when the bare compiler target does not
satisfy that request. The standard FPC target values apply
(`x86_64`, `aarch64`, `i386`, `arm`, `darwin`, `linux`, and the values reported
by `fpc -h`). Before compiling, the driver runs the requested dispatch with
`-iV -iTO -iTP`, validates the returned version/target through
`BuildRequestIsCompatible`, and caches that result for the invocation. A
missing `ppcross*` compiler or unsupported target fails with a message naming
FPC and the requested tuple; LWPT never falls back to the host compiler. The
publish step refreshes the probe and repeats the complete compatibility check;
a changed compiler identity/version, target, output kind, or mode during
compilation withholds the candidate.

## Lakon compiler profile

The opt-in `lakon` driver targets the released
[`frostney/lakon` 0.1.0 CLI](https://github.com/frostney/lakon/releases/tag/0.1.0)
or newer. The executable defaults to `lakon` on `PATH`; a root profile can
pin a project-relative or absolute executable:

```toml
[compiler]
default = "wasm"

[compiler.profiles.wasm]
driver = "lakon"
executable = "tools/lakon"
version = ">=0.1.0"
```

Every selection and concrete build operation launches both `lakon --version`
and `lakon --help` again. The adapter requires the `lakon <semver>` identity,
enforces the 0.1.0 floor, and confirms the released compile/options surface
before translating the request. It advertises only the released
`wasi/wasm32` target with the `wasip1` environment, executable WebAssembly
output, and dev mode. Lakon's native lane and a release-mode switch are not
released, so LWPT does not advertise or infer them.

The adapter translates the entry source, output path, unit paths, defines,
and the three verified diagnostic options. It always passes `--no-cache`:
Lakon 0.1.0 roots its `.lku` cache at `build/cache`, outside the neutral
request's private output roots, so disabling that cache preserves LWPT's
session-isolation contract and also implements `--clean`. Multiple explicit
sources, resources, include-only paths, release mode, and unverified extra
arguments fail with a driver diagnostic. LWPT never installs Lakon and never
falls back to FPC when a Lakon profile is selected.

The generic `lwpt test` runner executes compiled test artifacts as native
processes. A Lakon artifact is a WASI module, so the external adapter rejects
that path explicitly instead of handing a WebAssembly file to the operating
system. A Lakon-branded embedding host that exposes `test` must own its WASI
execution path outside the generic native runner; no Node or wasmtime
dependency is added to the LWPT binary.

An embedding host uses the same public `TLWPTCompilerHost` factory API. It
registers `LAKON_COMPILER_ID`, optionally sets `DefaultProfile` to that ID,
and returns a driver consuming the versioned neutral request/result types.
For the `lakon` ID only, that registered factory takes precedence over the
external CLI adapter. This lets a Lakon-branded host replace the ordinary
implicit FPC default without changing the manifest, while explicit project or
build-entry profiles remain authoritative. Factory identity, configured
version, live capabilities, and result/artifact validation are enforced by
the same selection and build paths; a Lakon failure never selects FPC.

## Delphi compiler profiles

Delphi support is opt-in and applies only to consumer projects; LWPT itself
remains built and tested with FreePascal. A root profile selects the built-in
`delphi` driver and one command-line compiler executable:

```toml
[compiler]
default = "delphi-win64"

[compiler.profiles.delphi-win64]
driver = "delphi"
executable = "C:/path/to/dcc64.exe"
version = ">=36.0.0"
```

Replace the placeholder with the installed compiler path; Embarcadero's
installation directory differs by product version. An explicit `executable`
may be absolute or project-relative. When it is omitted, the driver looks for
`dcc32.exe` under `BDSBIN`, then `BDS/bin`, then uses `dcc32` from `PATH`.
Embarcadero's `rsvars.bat` initializes the normal command-line environment.
Discovery never selects a different target on the user's behalf: configure
another profile and executable for each target.

The minimum supported backend is Delphi 12 Athens (compiler `36.0.0`). Every
concrete build or test operation launches the selected executable with `-h`,
parses its Embarcadero identity/version/target header, and checks it against
both the executable name and neutral request. The deterministic contract
matrix is:

| Executable | Advertised target tuple | LWPT release-platform coverage |
| --- | --- | --- |
| `dcc32(.exe)` | `win32/i386` | `i386-win32` |
| `dcc64(.exe)` | `win64/x86_64` | `x86_64-win64` |
| `dcclinux64(.exe)` | `linux/x86_64` | `x86_64-linux` |
| `dccosx64(.exe)` | `darwin/x86_64` | `x86_64-darwin` |
| `dccosxarm64(.exe)` | `darwin/aarch64` | `aarch64-darwin` |

The version floor, executable names, and target claims follow Embarcadero's
[compiler-version table](https://docwiki.embarcadero.com/RADStudio/Florence/en/Compiler_Versions_Table),
[Delphi compiler reference](https://docwiki.embarcadero.com/RADStudio/Florence/en/Delphi_Compiler),
and [supported-platform table](https://docwiki.embarcadero.com/RADStudio/Florence/en/Supported_Target_Platforms).
The `BDS`/`BDSBIN` discovery inputs are the vendor's documented
[environment variables](https://docwiki.embarcadero.com/RADStudio/Florence/en/Defined_Environment_Variables).

Delphi has no advertised `linux/aarch64` compiler in this contract, so
`aarch64-linux` fails before compilation with the supported and requested
tuples. Other installed Delphi toolchains are deliberately not inferred or
advertised until their tuple and translation contract have dedicated
coverage.

The driver translates neutral defines, unit/include/resource search paths,
development/release switches, clean rebuilds, private executable/unit/object
directories, output extension, and ordered extra options. Resource files
remain source-declared through Delphi's `{$R ...}` directive; neutral resource
inputs add their containing directories to the command-line resource search
path. On success the compiler's source-derived output basename is atomically
moved inside private session staging to the exact requested artifact name
before normal publication. Delphi diagnostics such as
`Unit.pas(12,7) Error: E2003 ...` retain path, line, column, code, severity,
and message in the normalized result.

The ordinary FPC CI lane runs translation, probe-parser, version-floor,
target-matrix, diagnostic, artifact, and no-fallback fixtures without needing
a Delphi license. The manual `delphi-native.yml` workflow provides an opt-in,
non-gating Win64 smoke on a licensed self-hosted runner; it is not a release
requirement.

## Blaise compiler profile

The opt-in `blaise` driver targets the released
[`graemeg/blaise` v0.13.0 CLI](https://github.com/graemeg/blaise/releases/tag/v0.13.0)
or newer. The executable defaults to `blaise` on `PATH`; a root profile can
pin a project-relative or absolute executable explicitly:

```toml
[compiler]
default = "modern"

[compiler.profiles.modern]
driver = "blaise"
executable = "tools/blaise"
version = ">=0.13.0"
```

Profile selection constructs and caches the driver; each concrete build or
test operation launches `blaise --help`. The driver requires the
`Blaise Compiler v<semver>` identity, enforces the v0.13.0 floor, and confirms
the supported target names are still present before translating the request.
It advertises only `linux/x86_64` and
`freebsd/x86_64`: those are the two targets Blaise v0.13.0 documents as
self-hosted, bidirectionally cross-compiled, and shipped as release binaries.
The CLI also parses names for planned targets, but LWPT does not advertise
those until upstream proves and releases them.

The adapter invokes Blaise's native backend explicitly and translates the
entry source, artifact, target, unit paths, defines, and private unit/object
cache. Installed dependency unit paths are extracted from LWPT's generated
`lwpt.cfg` and translated to repeated `--unit-path` arguments rather than
passing Blaise an FPC response file. Dev mode adds Blaise's `--debug` runtime
leak reporting; release mode does not. `--clean` adds
`--no-incremental`. The current upstream contract produces executables only.
Additional explicit source inputs, resources, distinct unit/object cache
directories, and include-only search paths fail with a driver diagnostic.
Test compilation currently repeats unit paths in the neutral include-path
field; exact duplicates are accepted because they do not request an additional
Blaise feature. Profile or entry arguments cannot override the driver-owned
source, output, target, backend, mode, defines, cache, or RTL selection.
LWPT never installs Blaise and never falls back to FPC when a Blaise profile
is selected.

## Generator hooks (formerly `[generated]`)

An earlier `[generated]` section was replaced by the lifecycle-hook model in [ADR-0011](./adr/0011-build-lifecycle-hooks.md). Each entry is a named hook in `[prebuild]` / `[postbuild]` / `[pretest]` / etc. with explicit `script`, `inputs`, and `output` fields, and a staleness gate (run iff output is older than any input):

```toml
[prebuild]
build-foo = { script = "scripts/bar.pas",
              inputs = ["a.pas", "b.pas"],
              output = "source/Foo.inc" }
```

`lwpt build` (and `lwpt test`, for `[pretest]`) walks each hook before the phase runs. If the output is missing or any input is newer than the output, the script is re-run via InstantFPC. On Unix, LWPT points InstantFPC at a cache below the owning build/test session; Windows compiles the hook directly into that session. The generator consumes its inputs and rewrites its output; no arguments are passed unless the manifest declares them.

If `instantfpc` is not on `PATH`, the failure names the generator script and recommends installing InstantFPC (bundled with FPC).

LWPT's own root manifest previously carried a paired `[prebuild]` + `[pretest]` `embed-testing-library` hook that regenerated `source/LWPT.Embedded.TestingLibrary.inc`. [ADR-0015](./adr/0015-drop-export-testing-becomes-workspace-package.md) removed that embedded-blob hook. The current root manifest instead declares the `[prebuild]` `stamp-version` hook, which derives `source/Version.inc` from `lwpt.toml`.

## Pre-commit hook (Lefthook)

The pre-commit gate at the repo root in `lefthook.yml` runs two commands:

| Command | Glob | Fires on |
| --- | --- | --- |
| `format` | `*.{pas,inc,dpr,toml}` | Any staged Pascal source or manifest |
| `agents` | `*.{pas,toml,md}` | Anything that can affect the generated `AGENTS.md` command reference |

Both commands use `stage_fixed: true`, so formatter rewrites and generated command-reference refreshes are staged back into the same commit. A missing bootstrap binary or malformed agents marker remains an actionable failure.

Install once per fresh clone:

```sh
lefthook install
```

The heavyweight gates — `lwpt format --check` + `lwpt build` + `lwpt agents --check` + `lwpt test` — run on the PR workflow in CI (`.github/workflows/pr.yml`) rather than every local commit. This keeps local commits fast and the pre-merge gate strict.

Do **not** bypass with `git commit --no-verify` unless a maintainer explicitly authorises it on the PR.

The analysis commands remain outside the v1 pre-commit gate per
[ADR-0006](./adr/0006-stack-contracts-deferred-from-v1.md). Duplication and
[`lwpt health`](./health.md) are user-invoked reports and do not widen that
gate. Architecture drift is checked for LWPT itself during release preparation
and is not a consumer command. [Issue #28](https://github.com/frostney/lwpt/issues/28)
delivered parallel, process-safe, observable builds and tests through private
sessions and the shared worker budget.

## Machine-wide worker capacity

The build scheduler acquires capacity from `LWPT.WorkerBudget` before starting
each compiler process and releases it when that process finishes. Before each
per-entry or whole-build postbuild path and before revalidation/publication it
reacquires a lease, so compiler and hook work never runs outside the machine
budget. Finalization retains its lease until the candidate is either published
or rejected. The
coordinator bounds aggregate work from several LWPT invocations and worktrees,
not just the `--jobs` value of one process.

The module uses reclaimable filesystem leases with a heartbeat rather than a
permanent counter. A crashed owner therefore cannot leak capacity
indefinitely. Heartbeat age is diagnostic only, so a healthy compiler that
runs longer than the stale threshold keeps its lease while its OS-held owner
guard remains live. FIFO acquisition tickets prevent release/reacquire loops
from jumping existing waiters, and nested LWPT subprocesses consume a one-shot
delegation that transfers one grant to their own guarded request instead of
consuming a second slot. The parent reacquires through the FIFO after the child
finishes. See
[`tooling.md`](./tooling.md#machine-wide-worker-budget) for configuration and
[ADR-0021](./adr/0021-machine-wide-worker-budget.md) for the decision.
