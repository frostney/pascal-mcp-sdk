{ Tests.LwptSubprocess — spawn ./build/lwpt as a subprocess and capture
  exit code, stdout, stderr.

  E2E tests need this because the whole point of the tier is to test
  the binary as users invoke it: argv parsing through the real CLI
  layer, exit codes the shell sees, stdout/stderr the user sees, and
  on-disk side effects in a real CWD. Tests that `uses LWPT.Core`
  link the library and skip the binary surface entirely — which is
  what Unit + Integration are for.

  Design choices:

    - Stdout and stderr are captured separately (not merged) so tests
      can assert on each independently. Ordinary completion summaries
      and most LWPT errors land on stderr; silent success alone reports
      its final summary on stdout.
    - The caller's environment is inherited by default; AExtraEnv
      adds or overrides individual variables for that subprocess
      only.
    - cwd defaults to the current directory; AInDir overrides for
      per-test scratch dirs (matches the integration-tier pattern
      from InstallLocalDiamond.Test.pas).
    - The binary path is configurable via LwptBinaryPath but defaults
      to ./build/lwpt (resolved relative to the test's CWD, which
      lwpt test sets to the project root before launching each test).
    - poWaitOnExit + reading streams after exit. Output is short
      for LWPT subcommands; if a future subcommand streams large
      output we'll switch to incremental drain.

  Surface — kept minimal:

    function RunLwpt(const AArgs; AInDir; AExtraEnv): TLwptResult;
    function LwptBinaryPath: string;
    function ExpectedExe(const APath: string): string;
    procedure SetLwptBinaryPath(const APath: string);
}

unit Tests.LwptSubprocess;

{$mode delphi}{$H+}

interface

uses
  Classes,
  Process,
  SysUtils;

type
  TLwptResult = record
    ExitCode: Integer;
    ProcessExitCode: Integer;
    ProcessExitStatus: Integer;
    Stdout:   string;
    Stderr:   string;
    TimedOut: Boolean;
  end;

{ Spawn the lwpt binary with the given arguments. Stdout + stderr are
  captured separately. AInDir defaults to '' which means "inherit the
  caller's CWD". AExtraEnv is an array of "KEY=value" strings; each is
  added to the inherited environment, replacing any existing value
  with the same key. }
function RunLwpt(const AArgs: array of string;
  const AInDir: string = ''): TLwptResult; overload;
function RunLwpt(const AArgs: array of string;
  const AInDir: string;
  const AExtraEnv: array of string): TLwptResult; overload;
function RunLwpt(const AArgs: array of string;
  const AInDir: string;
  const AExtraEnv: array of string;
  const ATimeoutMilliseconds: QWord): TLwptResult; overload;

{ Path to the lwpt binary. Defaults to './build/lwpt' resolved at the
  point of the call. Override via SetLwptBinaryPath when running
  from a non-standard layout (e.g. a side-by-side comparison). }
function LwptBinaryPath: string;
function ExpectedExe(const APath: string): string;
procedure SetLwptBinaryPath(const APath: string);
procedure ConfigureProcessEnvironment(const AProcess: TProcess;
  const AOverrides: array of string);

{ When a nested LWPT run exits with an unexpected code, its captured
  output is the only evidence of why. Call this before the exit-code
  assertion: on mismatch it writes the captured stdout/stderr to
  ADiagnostics when supplied. Otherwise, it writes them to the suite's
  stdout, which the scheduler's failure replay surfaces directly in CI
  logs. No-op when the exit code matches. }
procedure DumpRunFailure(const ALabel: string; const ARun: TLwptResult;
  const AExpectedExit: Integer; const ADiagnostics: TStrings = nil);

{ Quick helper for "is the env saying skip network?". E2E tests that
  touch the live internet should consult this and self-skip via a
  WriteLn + early-return. }
function SkipNetworkTests: Boolean;

{ Did a non-zero `lwpt` result fail purely because the network / host
  was unreachable — as opposed to LWPT producing wrong output? E2E
  tests call this after their install run and SKIP (rather than FAIL)
  when it returns True: a TCP connect failure or DNS resolution
  failure to a third-party host (bitbucket.org, github.com, gitlab.com)
  is transient infrastructure flakiness, not an LWPT defect.

  Detection is deliberately NARROW — only HTTPClient's two clean
  pre-transfer failures:
    - "Failed to connect to <host>:<port>"   (TCP connect failed)
    - "Failed to resolve host: <host>"        (DNS lookup failed)
  Both fire before any byte is fetched or parsed. Errors that indicate
  a real LWPT bug — "truncated chunked body", "no header terminator",
  a hash mismatch, a missing extracted file — are intentionally NOT
  matched, so the e2e assertions still fail HARD on those. The split
  is the whole point: third-party downtime skips; LWPT regressions
  fail. }
function IsNetworkUnavailable(const AResult: TLwptResult): Boolean;

implementation

var
  GLwptBinaryPath: string = '';
  GForwardWorkerLease: Boolean = True;

function LwptBinaryPath: string;
begin
  if GLwptBinaryPath <> '' then Exit(GLwptBinaryPath);
  Result := ExpandFileName('build/lwpt');
end;

function ExpectedExe(const APath: string): string;
begin
  Result := APath;
  {$IFDEF MSWINDOWS}
  if ExtractFileExt(Result) = '' then Result := Result + '.exe';
  {$ENDIF}
end;

procedure SetLwptBinaryPath(const APath: string);
begin
  GLwptBinaryPath := APath;
end;

function SkipNetworkTests: Boolean;
begin
  Result := GetEnvironmentVariable('LWPT_SKIP_NETWORK') = '1';
end;

function IsNetworkUnavailable(const AResult: TLwptResult): Boolean;
var
  Err: string;
begin
  if AResult.ExitCode = 0 then Exit(False);
  Err := LowerCase(AResult.Stderr);
  Result := (Pos('failed to connect to', Err) > 0)
         or (Pos('failed to resolve host', Err) > 0);
end;

{ Drain a stream into a string buffer. Stops at EOF; assumes the
  subprocess has already exited so no blocking reads. Uses a 4 KiB
  chunk size — large enough that LWPT's typical output (a few lines)
  fits in one read. }
function DrainStream(AStream: TStream): string;
const
  CHUNK = 4 * 1024;
var
  Buf: array of Byte;
  N, Total: Integer;
begin
  Result := '';
  SetLength(Buf, CHUNK);
  Total := 0;
  while True do
  begin
    N := AStream.Read(Buf[0], CHUNK);
    if N <= 0 then Break;
    SetLength(Result, Total + N);
    Move(Buf[0], Result[Total + 1], N);
    Inc(Total, N);
  end;
end;

{ Name part of a NAME=value environment entry. Windows env blocks can
  contain entries starting with '=' (drive-letter cwd entries); those
  yield an empty name and never match an override. }
function EnvironmentEntryName(const AEntry: string): string;
var EqPos: Integer;
begin
  EqPos := Pos('=', AEntry);
  if EqPos = 0 then
    Result := AEntry
  else
    Result := Copy(AEntry, 1, EqPos - 1);
end;

function EnvironmentNamesEqual(const ALeft, ARight: string): Boolean;
begin
  {$IFDEF MSWINDOWS}
  Result := SameText(ALeft, ARight);
  {$ELSE}
  Result := ALeft = ARight;
  {$ENDIF}
end;

function EnvironmentEntryIsOverridden(const AEntry: string;
  const AOverrides: array of string): Boolean;
var
  EnvironmentIndex: Integer;
begin
  for EnvironmentIndex := 0 to High(AOverrides) do
    if EnvironmentNamesEqual(EnvironmentEntryName(AEntry),
      EnvironmentEntryName(AOverrides[EnvironmentIndex])) then
      Exit(True);
  Result := False;
end;

procedure ConfigureProcessEnvironment(const AProcess: TProcess;
  const AOverrides: array of string);
var
  EnvironmentIndex: Integer;
begin
  for EnvironmentIndex := 1 to GetEnvironmentVariableCount do
    if not EnvironmentEntryIsOverridden(
      GetEnvironmentString(EnvironmentIndex), AOverrides) then
      AProcess.Environment.Add(GetEnvironmentString(EnvironmentIndex));
  for EnvironmentIndex := 0 to High(AOverrides) do
    AProcess.Environment.Add(AOverrides[EnvironmentIndex]);
end;

{ Discover the one-shot worker token by its protocol suffix so this shared
  subprocess helper stays link-safe for E2E programs. The owning LWPT binary
  remains the only source of the project-prefixed environment name. }
function FindWorkerLeaseTokenEnvironment: string;
const
  TOKEN_SUFFIX = '_WORKER_LEASE_TOKEN';
var
  i: Integer;
  Name: string;
begin
  Result := '';
  for i := 1 to GetEnvironmentVariableCount do
  begin
    Name := EnvironmentEntryName(GetEnvironmentString(i));
    if (Length(Name) >= Length(TOKEN_SUFFIX))
       and EnvironmentNamesEqual(Copy(Name,
         Length(Name) - Length(TOKEN_SUFFIX) + 1,
         Length(TOKEN_SUFFIX)), TOKEN_SUFFIX)
       and (GetEnvironmentVariable(Name) <> '') then
      Exit(Name);
  end;
end;

function RunLwpt(const AArgs: array of string;
  const AInDir: string): TLwptResult;
var Empty: array of string;
begin
  SetLength(Empty, 0);
  Result := RunLwpt(AArgs, AInDir, Empty);
end;

function RunLwpt(const AArgs: array of string;
  const AInDir: string;
  const AExtraEnv: array of string): TLwptResult;
begin
  Result := RunLwpt(AArgs, AInDir, AExtraEnv, 0);
end;

function RunLwpt(const AArgs: array of string;
  const AInDir: string;
  const AExtraEnv: array of string;
  const ATimeoutMilliseconds: QWord): TLwptResult;
var
  P: TProcess;
  i: Integer;
  SavedDir: string;
  WorkerLeaseTokenEnvironment: string;
  ForwardedWorkerLease: Boolean;
  StartedAt, TerminatedAt: QWord;
const
  TERMINATION_GRACE_MILLISECONDS = 2000;
begin
  Result.ExitCode := -1;
  Result.ProcessExitCode := -1;
  Result.ProcessExitStatus := -1;
  Result.Stdout   := '';
  Result.Stderr   := '';
  Result.TimedOut := False;

  P := TProcess.Create(nil);
  try
    P.Executable := LwptBinaryPath;
    for i := 0 to High(AArgs) do P.Parameters.Add(AArgs[i]);
    P.Options := [poUsePipes];
    if AInDir <> '' then P.CurrentDirectory := AInDir;

    { Always materialise the child environment so a consumed one-shot worker
      token can be omitted from later LWPT children without mutating this test
      process's own environment. Extras replace matching parent entries. }
    WorkerLeaseTokenEnvironment := FindWorkerLeaseTokenEnvironment;
    ForwardedWorkerLease := GForwardWorkerLease
      and (WorkerLeaseTokenEnvironment <> '')
      and not EnvironmentEntryIsOverridden(
        WorkerLeaseTokenEnvironment + '=', AExtraEnv);
    for i := 1 to GetEnvironmentVariableCount do
      if not EnvironmentEntryIsOverridden(GetEnvironmentString(i), AExtraEnv)
         and (GForwardWorkerLease
           or (WorkerLeaseTokenEnvironment = '')
           or not EnvironmentNamesEqual(
             EnvironmentEntryName(GetEnvironmentString(i)),
             WorkerLeaseTokenEnvironment)) then
        P.Environment.Add(GetEnvironmentString(i));
    for i := 0 to High(AExtraEnv) do
      P.Environment.Add(AExtraEnv[i]);

    { Run + drain. We do NOT use poWaitOnExit with poUsePipes; on
      Linux+macOS that pair can deadlock when the child blocks
      writing past the pipe buffer because the parent isn't reading.
      Instead: Execute, then drain both streams while the child runs,
      then WaitOnExit. }
    SavedDir := GetCurrentDir;
    try
      P.Execute;
      StartedAt := GetTickCount64;
      while P.Running do
      begin
        if P.Output.NumBytesAvailable > 0 then
          Result.Stdout := Result.Stdout + DrainStream(P.Output);
        if P.Stderr.NumBytesAvailable > 0 then
          Result.Stderr := Result.Stderr + DrainStream(P.Stderr);
        if (ATimeoutMilliseconds > 0)
           and (GetTickCount64 - StartedAt >= ATimeoutMilliseconds) then
        begin
          Result.TimedOut := True;
          P.Terminate(1);
          Break;
        end;
        Sleep(10);
      end;
      if Result.TimedOut then
      begin
        TerminatedAt := GetTickCount64;
        while P.Running
          and (GetTickCount64 - TerminatedAt <
            TERMINATION_GRACE_MILLISECONDS) do
        begin
          if P.Output.NumBytesAvailable > 0 then
            Result.Stdout := Result.Stdout + DrainStream(P.Output);
          if P.Stderr.NumBytesAvailable > 0 then
            Result.Stderr := Result.Stderr + DrainStream(P.Stderr);
          Sleep(10);
        end;
        if P.Running then
          raise Exception.CreateFmt(
            'timed-out lwpt subprocess did not terminate within %d ms',
            [TERMINATION_GRACE_MILLISECONDS]);
      end;
      { final drain after exit }
      if P.Output.NumBytesAvailable > 0 then
        Result.Stdout := Result.Stdout + DrainStream(P.Output);
      if P.Stderr.NumBytesAvailable > 0 then
        Result.Stderr := Result.Stderr + DrainStream(P.Stderr);
      { Mirrors LWPT.Command.Common.NormalisedExitCode (this unit must
        not link LWPT units): on Unix, ExitCode decodes correctly only
        when the Running poll reaped the raw waitpid(2) status; if
        WaitOnExit reaps instead it stores the already-decoded code and
        ExitCode collapses most failures to 0. ExitStatus is nonzero on
        genuine failure either way, so trust it when ExitCode claims
        success. }
      Result.ProcessExitCode := P.ExitCode;
      Result.ProcessExitStatus := P.ExitStatus;
      Result.ExitCode := Result.ProcessExitCode;
      if (Result.ExitCode = 0) and (Result.ProcessExitStatus <> 0) then
        Result.ExitCode := Result.ProcessExitStatus;
      { A test process may invoke LWPT more than once. Once a nested build or
        test scheduler starts, it has consumed the one-shot worker delegation;
        stop forwarding that stale token so the next command can join the
        worker queue normally. Validation failures before scheduler creation
        deliberately leave the still-live delegation available. }
      if ForwardedWorkerLease
         and (((Length(AArgs) > 0) and SameText(AArgs[0], 'build')
           and (Pos('build jobs:', Result.Stdout) > 0))
         or ((Length(AArgs) > 0) and SameText(AArgs[0], 'test')
           and (Pos('discovered ', Result.Stdout) > 0))) then
        GForwardWorkerLease := False;
    finally
      SetCurrentDir(SavedDir);
    end;
  finally
    P.Free;
  end;
end;

procedure WriteRunDiagnostic(const ALine: string;
  const ADiagnostics: TStrings);
begin
  if Assigned(ADiagnostics) then ADiagnostics.Add(ALine)
  else WriteLn(ALine);
end;

procedure DumpRunFailure(const ALabel: string; const ARun: TLwptResult;
  const AExpectedExit: Integer; const ADiagnostics: TStrings);
begin
  if ARun.ExitCode = AExpectedExit then Exit;
  WriteRunDiagnostic('RUN FAILURE [' + ALabel + '] exit='
    + IntToStr(ARun.ExitCode) + ' expected=' + IntToStr(AExpectedExit)
    + ' process-exit-code=' + IntToStr(ARun.ProcessExitCode)
    + ' process-exit-status=' + IntToStr(ARun.ProcessExitStatus),
    ADiagnostics);
  WriteRunDiagnostic('--- captured stdout ---', ADiagnostics);
  WriteRunDiagnostic(ARun.Stdout, ADiagnostics);
  WriteRunDiagnostic('--- captured stderr ---', ADiagnostics);
  WriteRunDiagnostic(ARun.Stderr, ADiagnostics);
  WriteRunDiagnostic('--- end captured output ---', ADiagnostics);
end;

end.
