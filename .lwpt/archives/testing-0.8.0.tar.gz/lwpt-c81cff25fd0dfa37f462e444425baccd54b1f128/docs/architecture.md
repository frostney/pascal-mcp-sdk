# Architecture

How LWPT is shaped: the through-line that ties every subcommand to the manifest, the on-disk layout that makes zero-install work, and the deliberate boundaries we drew during the spike-to-production grilling.

## Executive Summary

- **The package manager is the foundation.** `lwpt install` resolves the dependency graph and writes `lwpt.cfg`; every other subcommand consumes that same cfg. The manifest (`lwpt.toml`) is the single source of truth.
- **Zero-install by default.** `.lwpt/modules/` (extracted) and `.lwpt/archives/` (verification) are committed; a fresh clone is buildable with `fpc @lwpt.cfg` before `lwpt install` is ever run. See [ADR-0002](./adr/0002-lwpt-namespace-zero-install.md).
- **Dependency downloads are reused without weakening zero-install.** Verified
  archive bytes are admitted once into a per-user immutable SHA-256 store, then
  copied atomically back into each project's authoritative committed archive
  path when its lockfile proves the identity. See
  [ADR-0036](./adr/0036-per-user-dependency-archive-cas.md).
- **Self-hosting from day one.** LWPT builds LWPT through `lwpt build` against the repo's own manifest; the one-time `scripts/bootstrap.pas` resolves the chicken-and-egg. See [ADR-0005](./adr/0005-self-host-build.md).
- **RTL-only with LWPT-canonical packages.** No third-party FPC dependencies in the binary; HTTPS is `HTTPClient` from LWPT's `packages/httpclient/`. Per [ADR-0017](./adr/0017-packages-lwpt-canonical.md), LWPT is the canonical source for HTTPClient, CLI, Semver, TOML, and TestingPascalLibrary — all consumed as workspace packages via the root manifest's `[workspaces]` glob (Phase 1 done per ADR-0014 + ADR-0015). GocciaScript is the first named consumer and commits to Path A adoption; Phase 2 graduates individual packages to standalone repos when warranted.
- **The registry origin is self-hosted.** `lwpt registry init|serve` owns stable
  identity, content-addressed archives and metadata, atomically activated
  snapshots under signed checkpoints, crash recovery, and the foreground HTTP/TLS lifecycle per
  [ADR-0043](./adr/0043-self-hosted-registry-origin.md). `registry rotate-key`
  adds dual-signed local key rotation, and `registry init --role mirror` with
  `registry sync|verify|serve` runs a read-only mirror. The mirror verifies the
  origin's signed proof and serves it without contacting the origin while it
  serves requests, per [ADR-0045](./adr/0045-verified-registry-mirror.md).
  Synchronization rejects checkpoints signed for longer than seven days plus
  five minutes of clock skew, and refuses to run while the local UTC clock is
  behind the highest accepted `published_at`, so mirror hosts need a
  synchronized clock that is never set back.
  An origin with an active token accepts authenticated publication while it
  serves: uploads stage in accounted `incoming/` reservations, commits use the
  existing publication lease and checkpoint path with the server clock, and
  `registry issue-token|revoke-token` manage hashed, scoped, expiring
  credentials, per [ADR-0049](./adr/0049-registry-remote-publication.md).
  `registry publish` is the client (`LWPT.Registry.Publish`, over the shared acquisition in `LWPT.Registry.Client`): it validates or
  normalizes the archive and maps its `lwpt.toml` dependencies to record
  dependencies before it reads the token from its environment variable or
  connects. Per [ADR-0051](./adr/0051-registry-dependency-sources.md)
  decision 10, each must be a `registry:` source with a canonical constraint
  and no `include` or `exclude` key, and its alias must resolve through the
  archive manifest's own `[registries]` to an explicit canonical `identity`
  (`https`, or `http://localhost` as `--origin` allows), and it must not name
  the package itself on any origin; the record omits the
  publishing origin and sorts entries in protocol order, and the package name
  must use the consumer grammar. Anything else fails with
  `unsupported_dependencies` or `invalid_package_name`. It uploads to the one
  origin named on its command line without following redirects, and exits
  0 only after verifying from the `--key-id`/`--public-key` pin that the new
  signed head extends the head it saw first and includes the published
  record. Its diagnostics are local text plus allow-listed codes, and every
  message is redacted for the credential.
  Publication and clients build on the wire contract in
  [`registry-spec.md`](./registry-spec.md).
- **Error handling is production-grade.** Every multi-step install write goes through `.lwpt/tmp/` + atomic rename (EXDEV fallback to copy-then-delete), and `lwpt install` takes a cross-process lock (`.lwpt/install.lock`, O_CREAT|O_EXCL). See ADR-0002 and ADR-0008.
- **Compiler work is session-private.** Build/test compiler outputs stay below a project-owned build-session root (project-local by default, relocatable for path budget); successful build outputs are revalidated and atomically published, while completed-session logs remain available until `lwpt repair` reclaims the session. See ADR-0020.
- **Build scheduling follows the manifest DAG.** Ready build entries overlap within
  both the `--jobs` ceiling and machine-wide worker budget; dependants start
  only after prerequisites publish. See ADR-0023.
- **Build intent and compiler execution meet at one driver seam.**
  `LWPT.BuildRequest` owns the versioned request, target tuple, capability, and
  normalized result structures. `TLWPTCompilerDriver` owns capability probing,
  argument translation, executable naming, failure classification, and result
  normalization. Root-owned profiles select built-in FPC, Delphi, Blaise, the
  opt-in Lakon adapter, a short-lived external driver, or an embedding-host
  registered command for build and test. Host registration uses the same
  out-of-process command/arguments definition as manifest profiles;
  lifecycle commands use that definition too. See ADR-0022, ADR-0029, and
  ADR-0030.
- **Analysis commands share structure, not policy.** `LWPT.Analysis.Scope`
  resolves root/workspace ownership, `LWPT.Analysis.Pascal` exposes normalized
  tokens and typed declaration/executable regions, and `LWPT.Analysis.JSON`
  wraps command-owned payloads in a deterministic versioned envelope. Matching,
  scoring, thresholds, and payload schemas remain owned by their commands.

## Tech stack

- **Compiler:** FreePascal 3.2.2 (`fpc -iV` verified live; see `tooling.md`).
- **Mode:** `delphi` everywhere. Project-owned units (`lwpt.pas`, the `LWPT.*` family) and the package units (`CLI.*`, `Semver`, `HTTPClient`, etc) flow through `{$I Shared.inc}` which sets `{$mode delphi} {$H+}` (a few test-support units declare their own mode instead). Several LWPT units additionally enable `{$modeswitch nestedcomments+}` so documentation prose can contain literal placeholder strings (the `{user}` / `{repository}` / `{ref}` substrings) without prematurely closing the surrounding `{ ... }` block.
- **Runtime:** RTL only. No fcl-web, no fphttpclient, no third-party packages. The `HTTPClient` package exposes GET, HEAD, and byte-safe POST over one body-capable HTTP/1.1 request core. POST generates its own `Content-Length` and `Content-Type`; 301/302/303 redirects continue as bodyless GET, while 307/308 preserve the method and body. HTTPS uses `TransportSecurity` with platform-native TLS per ADR-0016: SChannel on Windows, SecureTransport on macOS, runtime-loaded system OpenSSL on Unix-not-Darwin. Server accept follows ADR-0024 (memory-BIO OpenSSL on Unix-not-Darwin) and ADR-0033 (native SChannel on Windows), and uses native Secure Transport on macOS. The registry's HTTPS listener alone uses Network.framework on Darwin kernel 25 and newer ([ADR-0043](./adr/0043-self-hosted-registry-origin.md); see [`deployment.md`](./deployment.md#tls-backends-per-platform)).
- **Scripts:** Pascal via InstantFPC (`scripts/bootstrap.pas`). Shell wrappers (`bootstrap.sh`, `bootstrap.bat`) fall back to direct `fpc` when InstantFPC is absent.

## The package-manager-is-the-foundation through-line

```text
                  lwpt.toml  (manifest, hand-edited, single source of truth)
                      │
                      ▼
              ┌──────────────────┐
              │   lwpt install   │  ← resolves deps, fetches/reuses verified bytes,
              │                  │     commits .lwpt state, writes lwpt.lock
              └────┬─────────────┘
                   │
                   ▼
            lwpt.lock           lwpt.cfg     ← FPC response fragment
                                    │           (-Fu lines for every module)
                                    │
        ┌────────────────────┬──────┴──────┬────────────────┐
        ▼                    ▼             ▼                ▼
   lwpt build         lwpt test       lwpt format     lwpt run
   (fpc @lwpt.cfg)    (compile +      (rewrite or     (invoke a
                       run *.Test.pas) check sources)  user-defined
                                                       run task)

   ↕ per-user dependency-archive CAS stores immutable verified bytes only;
     project .lwpt/archives/ remains authoritative.
   ↑ lwpt repair operates on project residue, owned build-session roots,
     and the per-user worker coordinator orthogonally, and reports the
     per-user registry document store without changing it.
   ↑ lwpt init scaffolds a new project (manifest, source dir, optional install/build).
```

The arrow from `lwpt install` to `lwpt.cfg` is the through-line. Every other subcommand reads `lwpt.cfg` (or skips it cleanly if `lwpt install` hasn't run — which only happens during the bootstrap window, since zero-install means consumers commit `lwpt.cfg`). Adding a new subcommand should not require teaching it about every source kind; it just consumes the resolved cfg.

## Manifest model

`lwpt.toml` is parsed by the bundled TOML 1.1 reader. `LWPT.Manifest.Schema`
then validates its structural contract from an immutable registry before
`LWPT.Manifest` applies source syntax, placeholder, cross-field, and other
domain rules. The same ordered registry renders the manifest reference in the
`lwpt agents` block, so accepted field shapes, defaults, root-only scope, and
the deliberately mixed malformed-value policies have one source of truth.
Array-of-tables are valid TOML, but are not a supported LWPT manifest shape;
`[build]` uses a table of named tables or the documented single-entry form.

Sections currently supported:

| Section | Purpose |
| --- | --- |
| `[package]` | name, version, units (`-Fu` roots from the project's own source) |
| `[dependencies]` | bare-string `"<source>@<version>"` shorthand or inline-table `{ source = "...", version = "...", include = [...], exclude = [...] }` — see [ADR-0009](./adr/0009-source-syntax-and-tag-resolution.md); the retired `subdir` field hard-errors with a migration hint |
| `[registries]` / `[registries.<alias>]` | root-only registry declarations per [ADR-0051](./adr/0051-registry-dependency-sources.md): an optional `default` alias, and per alias an optional canonical HTTPS `identity`, the pinned Ed25519 root key (`key-id`, `public-key`), an `origin` contact (required when `identity` is omitted), and ordered `mirrors`. Every value is validated at load; nothing is trusted on first use, and no secrets or machine-local data belong here. |
| `[sources]` | per-project custom git-host declarations. Each entry is an inline table mapping a prefix name to `archive` + `git` URL templates with `{user}` / `{repository}` / `{ref}` placeholders; enables prefixes like `gitea:owner/repo` against the user's self-hosted instance |
| `[build]` | one entry per binary; `lwpt build [<entry-name>]` consumes this. Inline entries may declare `depends = ["prerequisite"]`, ordered `flags = ["-dFEATURE"]`, a compiler profile, and an independent target tuple (`os`, `architecture`, optional `abi` and `environment`). Single-binary shorthand defaults the entry name to `[package].name`. |
| `[compiler]` / `[compiler.profiles.<name>]` | root-owned compiler policy. `default` names the project profile; profiles select a driver plus optional `command`, ordered `args`, and `version`. Built-in IDs are `fpc`, `delphi`, `blaise`, and `lakon`; other IDs use the short-lived external protocol. Hosts may register an out-of-process compiler command and bind it as their default. A build entry's `compiler` field overrides the project default. Dependency manifests cannot contribute this policy. |
| `[workspaces]` | `include` / `exclude` glob arrays for monorepo workspace auto-discovery (each matched dir with its own `lwpt.toml` is installed as a validated local snapshot) |
| `[preinstall]` / `[postinstall]` / `[prebuild]` / `[postbuild]` / `[pretest]` / `[posttest]` | Root lifecycle hooks per [ADR-0011](./adr/0011-build-lifecycle-hooks.md); each entry is a direct `command` plus ordered `args`, with optional shared literal/glob `inputs` / `output` staleness gating. Plus per-`[build]`-entry inline `prebuild` / `postbuild`. |
| Any other top-level section with a `command` field | A user-declared run task callable via `lwpt run <name>` per [ADR-0013](./adr/0013-run-subcommand-and-build-rename.md) |
| `[version]` | optional version-baking: writes a generated `.inc` with `<prefix>_VERSION` + `<prefix>_BUILD_DATE` |
| `[lwpt]` | toolkit-state overrides (`modules-dir`, `archives-dir`, `tmp-dir`, `sessions-dir`, `cfg-file`). Defaults match the constants in `LWPT.Core`; `sessions-dir` is overridden by `LWPT_SESSION_DIR` |
| `[format]` | `include = [...]` adds format-scope globs; `exclude = [...]` subtracts them. Toolkit state (root `.lwpt/**`, redirected toolkit paths, and only the project-owned namespace below a shared `sessions-dir` base) is excluded by default unless an explicit include matches it (ADR-0028). Workspace packages are included by the root walk by default and opt out via their own `[format]` section |
| `[test]` | test runner and compiler policy: `bail` (a non-negative failure count; `0`, the default, runs the full queue; `--bail` overrides it) and root-only ordered `flags` passed to every test-program compile. See [`testing.md`](./testing.md). |
| `[analysis]` | shared analysis source scope only: `include = [...]` adds Pascal source globs on top of `[package].units` and exact `[build]` sources; `exclude = [...]` subtracts them. Workspaces inherit the root configuration unless they declare their own `[analysis]` table. Command-specific thresholds and policy do not live here. |
| `[health]` | optional strict maxima for routine/file cyclomatic and cognitive complexity plus the separate `0..100` hotspot score. Workspaces inherit root limits unless they declare their own table. See [`health.md`](./health.md). |
| `[duplication]` | command-owned clone policy: `minimum-tokens` defaults to 100 and must be at least 25; optional integer `maximum-percent` fails only when aggregate duplication is greater than the configured value. Workspaces inherit the root table unless they declare their own. |

Dependency source shapes (per [ADR-0009](./adr/0009-source-syntax-and-tag-resolution.md)): bare `owner/repo` defaults to GitHub; `gitlab:owner/repo` and `bitbucket:owner/repo` prefixes route to those hosts; any `[sources.<name>]` table declares a custom prefix (Gitea, Forgejo, self-hosted GitHub Enterprise / GitLab / Bitbucket Server); `https://...` is an arbitrary tarball URL; paths (`./foo`, `../foo`, `/abs/foo`, `~/foo`, or `local:./foo`) are local sources; `registry:<package>` and `registry:<alias>/<package>` name a package from a declared registry origin ([ADR-0051](./adr/0051-registry-dependency-sources.md)), whose dependency key must equal the package name and whose version is a SemVer range or exact version without `v`, selected from the registry snapshot named by the origin's signed checkpoint. Registry dependencies may be declared by the root and by workspace members (through the root's `[registries]`); a git-host, URL, or local package manifest that declares one fails. Version specs accept SemVer 2.0.0 ranges (`^1.0.0`, `>=1.0.0 <2.0.0`), exact SemVer versions (`1.0.0` — preferred per [semver.org](https://semver.org/#is-v123-a-semantic-version)), commit SHAs, or arbitrary Git tag names (`v1.0.0`, `release-2024`). SemVer-shaped specs resolve through git smart-HTTP tag listing (uniform across GitHub / GitLab / Bitbucket / Gitea / Forgejo / self-hosted, no JSON, no auth). Explicitly *not* supported: `[[target]]` array-of-tables syntax, the legacy separate `source = "github|gitlab|..." + repo/ref/tag/asset/path` shape (hard-errored with a migration hint), and `git clone` (HTTP archives only — preserves the single-binary RTL-only constraint).

Commit-SHA pins (per [ADR-0047](./adr/0047-commit-pins-must-be-reachable.md)): every commit requirement must use the full 40-character SHA and be reachable from an advertised `refs/heads/*` or `refs/tags/*` tip, whether it stands alone or beside a named requirement. Hosts serve fork-only and pull-request commits under the upstream name, so the archive endpoint alone proves nothing. A pin equal to the object an advertised branch or tag names is accepted from the tag listing; peel claims never count. Otherwise `LWPT.GitProtocol.ProveCommitReachable` asks the host's upload-pack service (protocol v2, `filter tree:0`, commits and annotated tags only) for the objects between the tips and the pin, and `LWPT.GitPack` recomputes their ids and walks tag targets and parents. A pin that is unknown, unreachable, abbreviated, or unprovable (host without `filter`, invalid listing, response or proof budget exceeded) fails before its archive is fetched. The lock records the proving ref as `reachableFrom`. The proof runs when a lock entry is created, its commit changes, or it lacks a valid `reachableFrom` (a ref under `refs/heads/` or `refs/tags/`); `--frozen` and `--offline` never contact the host and warn about unproven entries. The resolver's legacy ref listing is parsed with the same name rules, strict framing, and its own count limits; the proof-only 20,000-tip cap does not restrict named requirements. The proof trusts the host for archive contents; see the ADR's threat model.

## Shared analysis foundation

The pre-approved duplication and health commands depend on three neutral deep
modules. `ResolveAnalysisScope` recursively resolves each declared workspace,
assigns every Pascal source to its globally deepest discovered project owner,
skips hidden and linked walks, and returns stable root-relative ordering.
Package unit roots and exact build entry sources seed the scope;
`[analysis].include` adds files and `[analysis].exclude` is the final
subtraction.

`AnalyzePascal` is an RTL-only lexical/structural pass. It strips whitespace and
comments, retains compiler directives, normalizes case-insensitive tokens, and
records zero-based byte offsets plus one-based line/column locations. Its typed
model keeps unit declarations, routine-local declarations, nested routines,
routine bodies, program bodies, initialization, and finalization separate.
Consumers therefore choose executable-versus-declaration comparisons explicitly
instead of inferring them from raw token positions.

`SerializeAnalysisEnvelope` writes a fixed-order LF-delimited JSON envelope with
an envelope schema/version, command name and independently versioned command
schema, LWPT name/version, project identity, sorted analyzed-file list, neutral
effective-configuration name/value entries, threshold outcome, and diagnostics.
The caller supplies one validated JSON object or array as its payload. Shared
code does not know duplication matches, health metrics, hotspot scores,
command-specific configuration schemas, or either command's presentation
policy.

`LWPT.Health` and `LWPT.Command.Health` consume that neutral foundation for the
shipped `lwpt health` command. The exact structural scoring table, threshold
contract, 100-commit rename-aware Git window, hotspot formula, and JSON payload
are documented once in [`health.md`](./health.md).

`LWPT.Duplication` consumes those neutral modules without feeding clone policy
back into them. It generates parameterized minimum-token fingerprints inside
each typed region, verifies candidates with a bidirectional identifier/literal
mapping, extends them to their maximal forward length, then selects
non-overlapping groups by descending length and stable coordinates. The command
owns its `[duplication]` inheritance, thresholds, human report, and versioned
JSON payload; `[analysis]` remains the only source-scope contract.

## Resolver shape

Materializing resolution in `LWPT.Install` is a breadth-first graph walk inside
deterministic fixed-point rounds ([ADR-0031](./adr/0031-fixed-point-single-version-resolution.md)).
Every candidate archive, extracted tree, and copied local source stays below a
private `.lwpt/tmp/resolver-plan-*` directory while LWPT:

1. accumulates all root and transitive requirements by package name;
2. rejects different canonical sources for the same name;
3. selects the highest advertised Git tag satisfying the node's complete
   SemVer constraint set;
4. uses lightweight or peeled annotated-tag SHAs to prove tag/SHA identity; and
5. repeats discovery when a selected candidate changes the transitive graph.

A repeated selection vector is an error: the resolver does not backtrack
through lower parent candidates. Once a round is stable, its exact filtered
module snapshots and archives are published, followed by `lwpt.lock` and
`lwpt.cfg`; mutable local/workspace sources are not reread during publication.
Failures before stability leave committed state untouched, and conflict
diagnostics list every requirer and constraint. The flat-graph hard error is
deliberate because FPC has one global unit namespace; nested multi-version
installs are not supported.

## Fetch / extract / build / test pipeline

- **Fetch:** Before HTTPS, a prior authoritative lock entry can address the
  per-user dependency archive store by raw SHA-256. Every hit and staged copy
  is re-hashed before atomic project publication; corruption is quarantined and
  becomes a miss. Identical known-hash misses share a local producer guard;
  waiters recheck the desired hash after publication or crash takeover. A first
  fetch without an authoritative content hash does not coordinate by mutable
  provenance. Otherwise HTTPS GET uses the LWPT-canonical `HTTPClient`
  package (raw sockets + SChannel on Windows / SecureTransport on macOS /
  OpenSSL on Linux per [ADR-0016](./adr/0016-tls-backend-per-platform.md)). The
  byte-safe `AppendRawBytes` accumulator fixes a header-recv truncation bug that
  previously corrupted binary downloads. URL templates per source kind live
  in `FetchURL`. Frozen mode does not read or materialize from the shared store.
- **Extract:** gunzip (zstream) + a direct ustar reader. The bundled FPC `libtar` has a bug — it ignores the 155-byte `prefix` field at offset 345, so paths longer than 100 bytes get silently dropped. LWPT's reader joins `prefix + '/' + name` correctly and also follows GNU `'L'`/`'K'` long-name entries.
- **Build:** `BuildOneEntry` creates a `TLWPTBuildRequest`, asks the selected driver
  to probe the requested target, validates the request against those
  capabilities, and obtains its invocation. Root-manifest per-entry flags
  become ordered neutral extra arguments before the driver translates them;
  dependency-manifest flags are dropped. `TLWPTCompilerProcess` executes
  them below the seam. `LWPT.BuildCache` derives a session-neutral fingerprint
  from that request plus content and environment inputs, and can materialize a
  verified immutable result from the per-user object store before the compiler
  runs. The driver normalizes diagnostics while the scheduler
  retains raw output for ordered log replay. The publication fingerprint embeds
  the deterministic request serialization alongside the implicit source
  directory, declared inputs, and postbuild hook contributors. Per-entry
  postbuild hooks receive the private candidate through `LWPT_BUILD_OUTPUT`,
  and existing `{item.output}` references are retargeted to it; only after hooks
  succeed does LWPT take a short thread-and-process lock derived from the
  destination's filesystem identity, refresh the target probe, revalidate the
  snapshot, and atomically replace the public executable when it is still
  current. Search-root fingerprints follow workspace directory links with cycle
  protection and exclude unrelated declared outputs, while explicit file inputs
  remain hashed. Only a successfully published current candidate is admitted
  to the build-result namespace; failed, cancelled, stale, and hook-failed
  candidates remain session-private. `--no-cache` bypasses lookup and storage.
- **Producer coordination:** `LWPT.ProducerLease` places per-key OS-held guards
  and heartbeat metadata below the shared cache root. Build fingerprints and
  known dependency archive hashes are separate key domains. Waiters report the
  object and elapsed wait, verified publication remains atomic, different keys
  proceed independently, and owner death releases the guard for takeover.
  Heartbeat age is diagnostic rather than authority, preserving a healthy
  long-running producer.
- **Cache lifecycle:** `LWPT.CacheLifecycle` owns one aggregate per-user object
  budget across dependency archives and build results. It records a monotonic
  deterministic LRU index, protects admission and materialization with
  per-object OS-held guards, and serializes only index/budget mutations.
  Build fingerprints transitively name both a result manifest and its artifact;
  mutation invalidates that logical reference before either object is removed.
  `lwpt repair` verifies object manifests, content, and both hops of each build
  reference, reconstructs damaged index state, reclaims abandoned/incomplete
  residue, preserves live guards, and evicts unleased objects until the
  configured budget is met.
- **Test:** Each `*.Test.pas` is a self-contained program using
  `TestingPascalLibrary`. The runner discovers all programs or resolves strict
  file, directory, and glob selectors; projects own any grouping and network
  policy. `lwpt test` resolves the project-scoped compiler
  driver once and shares it across every test worker; per-entry compiler
  profiles apply to `lwpt build`, not to individual test files. Workers validate
  each neutral request and first seek a verified compilation artifact set under
  a test-specific cache fingerprint. Hits are materialized only below the
  current private session; misses compile there and admit only a complete,
  successful driver-reported set. Workers retain raw compiler output and store
  normalized build-result diagnostics before running a successful binary.
  Execution is always fresh: pass/fail state, output, timing, and inventory
  results are never cached, and `--no-cache` bypasses compilation reuse.
  `TestingPascalLibrary.Protocol` exposes the opt-in,
  executable-bound registration record consumed by `LWPT.TestInventory`;
  ordinary bodies and inventory-only enumeration therefore share one runtime
  registration source without allowing nested test subprocesses to impersonate
  their parent program. See
  [ADR-0035](./adr/0035-runtime-test-registration-inventory.md),
  [ADR-0041](./adr/0041-verified-test-executable-cache.md), and
  [`testing.md`](./testing.md).
- **Worker coordination:** `LWPT.WorkerBudget` owns the per-user machine-capacity seam. Invocations register owner-guarded requests and acquire FIFO, reclaimable leases under a short cross-platform transaction lock. Nested LWPT subprocesses consume a one-shot opaque delegation that transfers one grant to the child's own guarded request instead of consuming another slot. `lwpt repair` reclaims requests only when their OS-held owner guard is absent; stale heartbeats remain diagnostic. Build and test scheduling consume this module in their own workstreams.

## Output and observability boundary

Output facts cross two deliberately separate layers. The reusable CLI package's
`CLI.Events` unit owns only a monotonically sequenced envelope and a synchronous
sink interface. Its dispatcher serializes delivery across producers, owns each
payload through the delivery call, and frees it after the sink returns. A sink
borrows the payload only during delivery and must copy or serialize anything it
needs to retain; successful, missing, and failed sinks follow the same ownership
rule. Observer failure cannot replace the command result. The generic layer has
no LWPT event names, terminal streams, rendering, or retention policy.

`LWPT.Observability` supplies the project-specific typed payloads: job
lifecycle, heartbeat, diagnostic, raw child stdout/stderr, command terminal,
truncation, and capture-degradation events. Source and correlation tags live on
those payloads. Retention classification distinguishes ordinary progress from
protected diagnostics and terminal outcomes, so a host can retain or replay
events without teaching the generic CLI package about LWPT policy. Raw child
chunks use `RawByteString` and remain byte-safe across embedded NUL bytes.
Failed job events preserve a child-process exit code when one exists and reject
zero; internal scheduler failures use the documented generic failure outcome.

`LWPT.ProgressReporter` consumes typed job and heartbeat events for build and
test. It owns their shared heartbeat cadence, active-job assembly, established
human rendering, and per-job log persistence. The executable host's broader
terminal and retention policy lives in `LWPT.OutputRenderer`. A registry-level
shared flag gives every command an independent `--silent` option object, while
the neutral prepared-dispatch hook lets the executable install the renderer
only after parsing and alias resolution. The renderer routes stdout/stderr and
continuously drained child chunks through `CLI.Events`, suppresses ordinary
events in silent mode, and replays protected diagnostics and failed-operation
output before the user-visible terminal failure result line. Raw child chunks
are correlated with their invocation and promoted from ordinary to protected
retention only when that child exits unsuccessfully; successful hook output
therefore stays suppressed if a later operation fails. Its normal journal
is capped at 64 MiB; a preallocated 1 MiB emergency ring preserves
protected/recent evidence when journal creation, writing, capacity, or replay
degrades. Observer failure
never replaces the command exit result. `LWPT.Observability` remains free of
human strings and stream policy, and
`LWPT.BuildSession` owns only session-path allocation and atomic log writes.

## `.lwpt/` layout

See [ADR-0002](./adr/0002-lwpt-namespace-zero-install.md) for the full design rationale.

| Path | Status | Purpose |
| --- | --- | --- |
| `.lwpt/modules/<dep>/` | **Committed** | Exact extracted or copied dependency snapshots from the stable resolver plan. Include/exclude policy has already been applied; the thing `-Fu` paths point at is never a live reread of a mutable local/workspace source. ADR-0031 supersedes ADR-0014's earlier publication-time monorepo-link amendment for materializing installs. |
| `.lwpt/archives/<dep>-<safe-ref>.tar.gz` | **Committed** | Source-of-truth tarballs, named after the resolved ref (tag or SHA) with characters outside `[A-Za-z0-9._-]` replaced by `_`; a URL source uses `<dep>-url.tar.gz`. Used for hash verification on `--frozen` and exact reconstruction by `install --offline`. |
| `.lwpt/archives/registry-proofs/sha256/<hex>.toml` | **Committed** | Exact bytes of each registry origin's locked selection proof: checkpoint, signature envelope, rotation triplets, head snapshot, and selected records ([ADR-0051](./adr/0051-registry-dependency-sources.md)). A set derived from `lwpt.lock`: the install transaction stages exactly the referenced documents, publishes them with the lockfile and cfg, and removes unreferenced ones. `--frozen` and `--offline` verify each registry selection from these documents and the manifest pin without network; `--offline` restores a missing document from the per-user document store by hash. Follows the `[lwpt] archives-dir` override. The deepest path an install writes is a retained proof document below the journaled transaction root, about 170 characters below the project root, so without Windows long-path support keep project roots under about 85 characters ([#347](https://github.com/frostney/lwpt/issues/347)). |
| `.lwpt/tmp/` | Gitignored | Install workspace and journaled rollback copies. A normal or offline materializing install, or `lwpt repair`, recovers pending state before ordinary residue cleanup. Frozen verification recovers and cleans nothing; it only creates, and removes on exit, a uniquely named scratch directory in which it re-derives each registry module from its archive and each local or workspace module from its source. An interrupted run's scratch is reclaimed by the next materializing install or `lwpt repair`. |
| `.lwpt/install.lock` | Gitignored | Cross-process install lock (`LWPT.InstallLock`, [ADR-0053](./adr/0053-install-lock-ownership-and-reclamation.md)). Created with O_CREAT\|O_EXCL (Windows: `CREATE_NEW`) by `lwpt install` or `lwpt repair`, whose kernel record lock on it (`fcntl`; Windows: `LockFileEx`) is the liveness signal; a second concurrent install fails with `EConcurrencyError` naming the lock holder's PID. Deleted by the normally-completing owner; a crashed owner leaves it, and `lwpt repair` takes it over only when the record lock proves that owner dead. See [`tooling.md`](./tooling.md#install-lock--crash-recovery). |
| `.lwpt/sessions/<session-id>/` | Gitignored | Build/test compiler staging. Every invocation owns distinct, bounded, hash-qualified job, unit, and executable paths. Completed sessions retain stable job logs until `lwpt repair`; failed/crashed sessions retain their private diagnostics. The sibling `locks/` directory contains stable publication-lock files and per-session owner guards. |
| `.lwpt/session-roots` | Gitignored | Atomic schema-versioned ledger of exact identity-verified relocated session namespaces used by `lwpt repair`. |
| `.lwpt/workers/` | Gitignored | Repository fallback for machine-wide worker-budget leases ([ADR-0021](./adr/0021-machine-wide-worker-budget.md)), used only when `LWPT_WORKER_STATE_DIR` is unset and the per-user default below the application config directory is not writable. |
| `.lwpt/registry/` | Gitignored | Default data directory for `lwpt registry` (`--data-dir` overrides it): origin or mirror configuration, keys, signed state, and stored objects ([ADR-0043](./adr/0043-self-hosted-registry-origin.md)). |

### ⚠️ Windows safe-deletion warning

Older zero-install trees may still contain a **junction** from the superseded
monorepo-link publication policy. Current materializing installs replace it
with a validated snapshot, but standard recursive-delete commands remain
dangerous until that happens:

- **PowerShell** `Remove-Item -Recurse -Force` **follows the junction into the target** and deletes files outside the link. If you run this on `.lwpt/`, you can lose your `packages/<name>/source/*.pas` files. Documented Windows-platform behaviour, not an LWPT bug; bit pnpm hard enough to warrant a public incident report ([pnpm issue #10707](https://github.com/pnpm/pnpm/issues/10707)).
- **Git Bash / MSYS** `rm -rf` has the same behaviour.
- **Safe alternative on Windows**: `cmd.exe /c "rmdir /S /Q .lwpt"` — removes junction reparse points as links rather than traversing them.

LWPT's own `AtomicRemovePath` cleanup detects junctions and removes them safely
(`RemoveDirectoryW` on the link itself). The hazard is only for *external*
tools the user invokes on the `.lwpt/` tree. Unix users are unaffected —
symlink-following deletion is a documented Windows quirk.

## Error model

`LWPT.Core` declares `ELWPTError` (base) + six subclasses; worker coordination,
build requests, compiler drivers, and the registry add module-specific
subclasses:

| Class | Raised for |
| --- | --- |
| `EFetchError` | Network failures, HTTP non-2xx, local source dir missing |
| `EVerifyError` | `--frozen` or `--offline` identity, archive-hash, or tree-hash mismatch against the lockfile, a link inside an installed module under `--frozen`, a local or workspace source that is missing or no longer reproduces its locked snapshot under `--frozen`, a tree path that is not well-formed UTF-8 (or UTF-16 on Windows), or a registry selection whose committed proof does not verify from the manifest pin or whose module differs from the tree re-derived from its archive; a locked tag that moved or became a branch, or a locked commit whose downloaded archive no longer matches, during an online install (unless `--accept-moved-tags`) |
| `EExtractError` | Archive parse failures, tar corruption, missing archive, atomic-move failure |
| `ELockfileError` | Corrupt TOML in `lwpt.lock`, schema version mismatch, or missing lockfile when `--frozen` or `--offline` |
| `EManifestError` | TOML errors, missing required keys, unsatisfiable constraints, unknown source kinds |
| `EConcurrencyError` | Concurrent `lwpt install`, or `lwpt repair` against a live install lock — second process fails fast naming the first's PID |
| `ELWPTWorkerBudgetError` | Invalid worker-budget configuration, ownership, lease, or delegation state |
| `ELWPTBuildRequestError` | Unsupported contract schemas, invalid build requests/results/capabilities, or invalid compiler compatibility constraints |
| `ELWPTCompilerDriverError` | Compiler probe, target dispatch, or request/capability mismatch failures |
| `ELWPTRegistryError` (`LWPT.Registry.Store`) and its subclass `ELWPTRegistryStaleContactError` (`LWPT.Registry.Verification`) | Registry failures carrying a stable machine-readable code (for example `registry_transport_failed`, `unsupported_dependencies`): server configuration and storage, signature and proof verification, consumer acquisition, and publication. `ELWPTRegistryStaleContactError` marks a correctly authenticated response that is older than the accepted state or expired, so acquisition tries the next contact instead of treating it as a trust failure |

Each error class carries an `Operation` and a `Recovery` field. The subcommand wrappers in `source/lwpt.pas` print `<program> <subcommand>: <message>` and the `Recovery` hint when set. Hash mismatches under `--frozen` print exactly which side mismatched (archive vs tree) and which dep is affected, so the recovery action is obvious from the message itself.

## Lockfile schema (v4)

`lwpt.lock` is machine-written; the `version = 4` header pins the schema ([ADR-0052](./adr/0052-lockfile-schema-v4-framed-tree-digest.md)). Each `[package.<name>]` table records:

| Key | Type | Notes |
| --- | --- | --- |
| `source` | string | The verbatim source string from the manifest (e.g. `"HashLoad/horse"`, `"gitlab:org/repo"`, `"../path"`). Host + kind are inferable by re-running `ParseDependencySource` on this value. |
| `resolvedRef` | string | The concrete tag name or commit SHA the resolver picked. Empty for `skLocal` + `skURL`. |
| `resolvedCommit` | string | The authoritative advertised commit fetched for a Git ref. Newly generated entries record it; v4 entries carried from early v3 locks by repair, which may lack it, remain frozen-verifiable when their existing fields prove an unambiguous identity. |
| `resolvedRefKind` | string | `tag` or `branch` for a dependency selected from a named Git ref; omitted for SHA pins and non-Git sources. Additive field (introduced in v3, unchanged in v4; [ADR-0048](./adr/0048-git-host-fetch-trust.md)): a locked tag is immutable, a locked branch may move. |
| `reachableFrom` | string | For a commit-SHA pin, the branch or tag ref that proved the commit reachable (for example `refs/tags/v1.2.0`); omitted otherwise. Additive field (introduced in v3, unchanged in v4; [ADR-0047](./adr/0047-commit-pins-must-be-reachable.md)): an online install proves an entry without it again, and `--frozen` / `--offline` warn. |
| `sourceIdentity` | string | Canonical source plus normalized include/exclude extraction policy. |
| `constraintFingerprint` | string | Digest of every accumulated requirement and requirer used to select this package. Requirement lines are sorted by ordinal byte value and each — including the last — is terminated with a pinned LF (never the platform line ending, and never a between-lines join), so the digest is byte-identical on every platform and a lockfile written on one verifies on another. Missing additive evidence in a v4 entry carried from an early v3 lock by repair is accepted only when the remaining identity is unambiguous; mixed named-ref/SHA identity without an authoritative commit requires regeneration. |
| `resolvedURL` | string | The actual archive URL fetched. Empty for `skLocal`. Self-documents the host: a `gitlab:` dep shows up as `https://gitlab.com/...`. |
| `computedHash` | string | `sha256-tree2:<hex>`, the framed digest of the extracted tree under `.lwpt/modules/<dep>/`: SHA-256 over the magic `sha256-tree2` NUL and one record per file in `TreeHashPathCompare` order (type byte `0x01`, 4-byte path length, the strictly validated UTF-8 relative path, 8-byte normalized content length, and the SHA-256 of the CRLF-normalized content; NUL-bearing files are hashed verbatim), integers big-endian. Files are streamed in 64 KiB chunks. Regular files and resolving file links count; directories, directory links, and dangling links do not. A v4 lock holds no other form. |
| `archiveHash` | string | `sha256:<hex>` of the cached `.tar.gz` under `.lwpt/archives/`; empty for `skLocal` (no archive). For a registry entry it equals the signed record's `archive` digest. |
| `registryOrigin` | string | Registry entries only: the origin identity. Contact URLs never enter identity, so moving an origin or its mirrors changes no lock byte ([ADR-0051](./adr/0051-registry-dependency-sources.md)). A record-derived entry's `source` is `registry:<name>`; `sourceIdentity` is `registry\|<identity>\|<name>` plus extraction policy. Registry entries omit `resolvedCommit`, `resolvedRefKind`, and `reachableFrom`. |
| `registryRecord` | string | Registry entries only: `sha256:` of the selected signed record. `resolvedURL` is the informational archive URL, kept while the record is unchanged. |

Each registry origin adds one `[registry."<identity>"]` table. `trustKeyId` is the pinned root key id, as evidence. `keyId`, `sequence`, `snapshot`, `checkpoint`, `signature`, `publishedAt`, `expiresAt`, and `rotations` are the selection proof: the signed head that the current selection was verified against, carried forward byte for byte unless the origin's selected records, the pin, or the retained proof's verification change. The `accepted*` keys and `clockFloor` are the recorded accepted state at the last lock change, a prior for machines without per-user state. A lock that would otherwise be byte-identical is never rewritten, even when acquisition advanced; any other change writes every origin's merged maximum (decision 11). Per-user accepted state lives under `LWPT_REGISTRY_STATE_DIR` or the per-user configuration root, keyed by identity and pin, and never moves backwards; it absorbs only its own prior and authenticated heads, never the lock's unsigned fields. Persisting it is part of a successful install: when it cannot be written, the install fails and rolls project state back, because with an unchanged lock it is the only record of the new high-water mark. Checkpoint freshness is judged when each proof is verified and again immediately before publication. The per-user state directory also keeps a content-addressed document store of authenticated snapshots, records, and rotation documents; acquisition consults it (then the committed proofs) before a contact, so a lagging contact that lacks newer history is judged stale rather than unreachable, and accepted rotation chains are loaded within the verifier's count and byte limits. Failure contract: documents are admitted before the state file is replaced and origins persist one after another, so a failed install can leave earlier origins' advances and admitted documents in place. Those remnants are authenticated and monotonic; nothing is rolled back and no atomicity across origins, documents, and project state is claimed. The store is bounded ([#345](https://github.com/frostney/lwpt/issues/345)). Documents in the current accepted history of a stored origin state are live and never evicted: the accepted checkpoint and each signature envelope naming it, the accepted snapshot and every predecessor reached through `previous` among stored, hash-verified snapshots, every record those snapshots name, and the accepted rotation triplets. A lock's committed selection proof lies on that history, so its snapshot, records, and rotations are live; only a checkpoint the per-user head has superseded, and its signature, are not. Every other document (superseded checkpoints and signatures, documents of deleted states) is evictable; re-pinning alone evicts nothing while the old pin's state file remains. Evictable documents' bytes are capped by `LWPT_REGISTRY_STATE_MAX_BYTES`, 64 MiB by default, the verifier's cumulative metadata limit. After each successful online install, under a store-wide producer lease that every state merge also takes, LWPT stamps the documents the install verified or its lock references in an atomically replaced recency index, stamps documents it sees for the first time, publishes that index, and only then removes evictable documents least recently used first while their bytes exceed the budget; a removal that fails (a document another process holds open on Windows) is retained, warned about, and retried later. Any uncertainty about the live set removes nothing: an `origins` or document directory that is a link (dangling or not) or another non-directory, or that cannot be listed completely, a state file that cannot be read, a missing, unreadable, or corrupt accepted snapshot, an unreadable small document that could be a live signature, or an exceeded bound (1,000,000 entries per directory, the verifier's snapshot and byte limits per history). Only regular files are documents: links, reparse points, directories, devices, and FIFOs are never opened, counted, or removed, and neither are state files; eviction failure only warns. `--frozen` and `--offline` write nothing there, so their reads do not refresh recency. `lwpt repair` reports the store's size, live and evictable documents, the budget, evictable bytes still over it, and why nothing is evictable when the live set is uncertain, and removes nothing. `--frozen` and `--offline` never select a contact or construct a registry client. They verify each registry entry from its committed proof and the manifest pin, taking the table's checkpoint, signature, sequence, key, and snapshot and the entry's record, name, version, and archive as claims, and take the node's edges from the signed record; neither applies expiry nor the clock floor, and an expired proof is only reported. Every lock entry is bound to its own claims on each check, so two entries can never share one signed record, and the committed documents are loaded within the verifier's count, per-document, and cumulative byte limits, with repeated rotation or record hashes refused before any read. `--frozen` then copies each registry archive into a private scratch directory, re-derives the module there under the declared extraction policy, and requires its tree digest to equal both the unsigned `computedHash` and the installed tree's digest. The framed digest makes equal digests prove an equal layout; a file-for-file comparison only names the first difference after a mismatch. `--offline` always re-extracts registry modules, stages archives from the committed project or the per-user CAS, restores missing proof documents from the per-user document store, and leaves the lock byte-identical.

Registry requests are time-bounded. One contact attempt, including history verification, has 10 minutes (`RegistryContactAttemptMilliseconds` in `LWPT.Registry.Consumer`); each metadata request within it gets the smaller of that remainder and 120 seconds (`RegistryRequestTimeoutMilliseconds` in `LWPT.Registry.Client`). An archive fetch, which never switches contacts, gets 5 minutes (`RegistryArchiveRequestMilliseconds`) and at most the signed `archive_size` bytes, never above 256 MiB.

Older lockfile schemas (v1 or v2) fail to load with a clear migration hint: delete `lwpt.lock` and re-run `lwpt install`. See [ADR-0008](./adr/0008-lockfile-schema-v2-archive-hash.md) for the archiveHash split (v1 → v2) and [ADR-0009](./adr/0009-source-syntax-and-tag-resolution.md) for the source-syntax + resolvedURL refactor (v2 → v3). A v3 lock, whose unframed tree hash cannot detect a rearranged module tree (#352), is a hard error for every command that reads the lock (`install`, `add`, `remove`, `update`, `outdated`, `--frozen`, `--offline`): the shared gate refuses it before any recovery, cleanup, or write and points to `lwpt repair`. Repair is the only reader that accepts v3: under the install lock and through the install transaction it re-derives every module without network from its committed archive or per-user cache copy, proof, or source, never consulting the v3 `computedHash`, reports and replaces a committed module that differs, and writes the v4 lock without moving versions; a missing anchor or a disagreeing manifest fails with a migration-specific message and leaves the lock v3 ([ADR-0052](./adr/0052-lockfile-schema-v4-framed-tree-digest.md)). A lock newer than v4 names the schema it needs. Any further schema break requires an ADR that ships a machine migration. Rollback files written with the legacy digest (`tree:sha256:`) are still validated with it, so a transaction a pre-v4 binary interrupted is recovered after the upgrade. Entries that an early v3 file wrote without the additive authoritative identity fields, and that repair carried into v4, remain frozen-verifiable when their existing source and ref fields prove an unambiguous identity. Ambiguous mixed named-ref/SHA entries fail with an instruction to run the machine writer; lockfiles must never be hand-edited.

## Self-host

LWPT's own `lwpt.toml` lists `lwpt` as a `[build]` entry with `source = "source/{item.name}.pas"` and `output = "build/{item.name}"` (placeholder interpolation per [ADR-0012](./adr/0012-manifest-placeholder-interpolation.md)). A second entry, `lwpt-testing`, compiles the same program with `-dINSTALL_TESTING` into `build/lwpt-testing`, the only binary that honours the `LWPT_TEST_*` seams; a `[pretest]` hook rebuilds it before every `lwpt test` ([ADR-0044](./adr/0044-test-seams-only-in-test-builds.md)). The pre-commit hook runs `./build/lwpt format` and `./build/lwpt agents`; `./build/lwpt build` recompiles LWPT against itself when needed. The bootstrap (`scripts/bootstrap.pas` + `bootstrap.sh` / `bootstrap.bat`) is the once-per-fresh-clone seed that produces the first `build/lwpt`. See [`build-system.md`](./build-system.md) and [ADR-0005](./adr/0005-self-host-build.md).

## Source layout and package code

`source/` carries LWPT-internal code (`lwpt.pas`, `LWPT.Core.pas`,
`LWPT.Manifest.pas`, `LWPT.Manifest.Schema.pas`, `LWPT.Install.pas`,
`LWPT.InstallLock.pas` (the install lock install and repair share),
`LWPT.WorkerBudget.pas`,
`LWPT.Command.*.pas`, `LWPT.CompilerDriver.pas`,
`LWPT.CompilerDriver.FPC.pas`, `LWPT.CompilerDriver.Delphi.pas`,
`LWPT.CompilerDriver.External.pas`,
`LWPT.CompilerRegistry.pas`, `LWPT.ProcessRunner.pas`, `LWPT.Formatter.pas`,
`LWPT.GitProtocol.pas` (ref listing and commit-reachability proofs),
`LWPT.GitPack.pas` (bounded commits-only packfile reader), `LWPT.SHA1.pas` (self-contained SHA-1 for git object ids; the cross toolchain ships no `sha1` unit),
`LWPT.FetchPolicy.pas` (built-in forge origins and per-dependency fetch
destination policy), `LWPT.Gzip.pas` (stream-based RFC 1952 decoding for archive
extraction), `LWPT.Archive.pas` (archive-contract primitives shared by the
installer's extraction preflight and the publication archive layer: traversal,
link, component, and UTF-8 name rules, tar header readers, stable failure
codes, and fixed bounds), `LWPT.TarWriter.pas` (the deterministic canonical
tar.gz writer), `LWPT.Zip.pas` (the bounded in-tree zip container reader),
`LWPT.ArchiveNormalize.pas` (publication input detection, the tar.gz scan, and
zip normalization per [ADR-0049](./adr/0049-registry-remote-publication.md)),
and the `LWPT.Registry.*` origin storage, signing,
shared proof verification, mirror synchronization, HTTP routing, upload
staging, publication tokens, audit records, publication handling, the
publication client, and native macOS listener units) plus a small remainder of utility units
(`Platform.pas`, `Shared.inc`) not yet extracted into `packages/`. The five
LWPT-canonical packages — `httpclient`, `cli`, `semver`, `toml`, `testing` —
live under `packages/<name>/` per
[ADR-0014](./adr/0014-packages-extraction.md) +
[ADR-0015](./adr/0015-drop-export-testing-becomes-workspace-package.md) +
[ADR-0017](./adr/0017-packages-lwpt-canonical.md). Each is a standalone Object
Pascal project with its own `lwpt.toml`, `source/`, tests, version, and bundled
`Shared.inc`; LWPT's root manifest auto-discovers them via `[workspaces]
include = ["packages/*"]`. [`packages.md`](./packages.md) is the table of the
package set, the divergence vs GocciaScript's older copies, the bootstrap
chicken-and-egg story, and the graduation roadmap. The Hard Constraint in
`AGENTS.md` is "Packages own their contents" — each package owns its versioning,
lifecycle hooks, tests, and public surface. Formatting is the explicit exception:
the root manifest formats workspace packages by default, and a package opts out
by declaring its own `[format]` section.

## ADR-0006 contract status

ADR-0006 originally deferred customer-facing `project-structure` contracts
beyond the build system and formatter. Duplication and codebase health have
since shipped:

- **duplication** — delivered as the Pascal-native `lwpt duplication`
  subcommand from [issue #32](https://github.com/frostney/lwpt/issues/32).
- **codebase-health** — delivered as `lwpt health` from [issue #33](https://github.com/frostney/lwpt/issues/33), with its current contract in [`health.md`](./health.md).

The pre-merge CI/PR gate is `lwpt format --check` + `lwpt build` + `lwpt agents --check` + `lwpt test`; the local pre-commit hook runs the formatter and the AGENTS.md agents-block refresh only. Architecture drift is checked across LWPT's own source, tests, manifests, workflows, documentation, ADRs, and domain context during release preparation. It is not a consumer-project responsibility or an LWPT subcommand.

## Production-readiness checklist (v1)

The production gaps the spike's handoff flagged + the current status of each:

| Gap | Status | Notes |
| --- | --- | --- |
| Self-test suite (HTTPClient regression first) | Done | The single most important test is the mock-server-based binary-fetch regression that pins HTTPClient's byte-safe `AppendRawBytes` contract |
| Live network tests against GitLab + Bitbucket + fetch-failure-mode tests | Done | Live GitHub (`octocat/Hello-World`), GitLab (`gitlab-examples/ci-debug-trace`), and Bitbucket (`atlassian/atlaskit`) suites ship under the repository's `tests/e2e/` path. The cross-platform loopback suite covers HTTP 500, refused connections, redirect confinement, stalled deadlines, truncated bodies, transaction cleanup, and preserved canonical production URLs. |
| Error handling hardened | Done | Validated journaled rollback under `.lwpt/tmp/`, stable-plan publication, recovery before tmp cleanup, aggregate rollback diagnostics, EXDEV fallback, `O_CREAT\|O_EXCL` cross-process install lock, lockfile schema v4 with `archiveHash`, `resolvedURL`, and the framed `sha256-tree2` tree digest, and read-only `--frozen` two-hash verification. |
| CI on the platform tier matrix | Done | Tier 1 cross-build and native-test coverage ships for Linux, Windows, and macOS (see [`deployment.md`](./deployment.md)). Windows install locking (`LockFileEx`), subprocess paths, and WinSock-backed HTTP mock-server regressions run natively. |
| Release artifacts | Done | Windows + macOS releases ship the binary alone; Linux relies on distro libssl per [ADR-0016](./adr/0016-tls-backend-per-platform.md). |
| Embedded testing library refresh wired into `lwpt build` | Retired per [ADR-0015](./adr/0015-drop-export-testing-becomes-workspace-package.md) | The embedded blob is gone; the testing framework is the workspace `testing` package, consumed via `lwpt install` like any other dep. |
| GocciaScript adopts LWPT-canonical packages | Direction set per [ADR-0017](./adr/0017-packages-lwpt-canonical.md); migration on the GocciaScript side | LWPT is now canonical for the shared packages; GocciaScript commits to Path A (full toolchain adoption). Until adoption lands, GocciaScript's older copies are frozen; backports only for P0 bugs. |
