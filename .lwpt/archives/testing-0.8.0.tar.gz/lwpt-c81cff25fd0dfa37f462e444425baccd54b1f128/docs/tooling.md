# Tooling

Pinned tool versions, environment variables, lint/format/test commands, OpenSSL stories per platform, EXDEV fallback, and current stack-contract status.

## Executive Summary

- **FPC 3.2.2 is pinned for v1.** Verify live with `fpc -iV` before any change that depends on FPC behavior — memory and prior conversation are not acceptable sources.
- **Lefthook 2.x runs the pre-commit hook.** Local pre-commit runs `lwpt format` and `lwpt agents` with `stage_fixed: true`; the heavyweight gates (`lwpt format --check` + `lwpt build` + `lwpt agents --check` + `lwpt test`) run on the PR workflow in CI. Install with `lefthook install`.
- **Build configuration uses the worker-budget environment too.** Alongside
  `LWPT_CACHE_DIR`, `FPC_TARGET_CPU`, and `PATH`, builds consume the
  `LWPT_WORKER_*` settings below. `--jobs=<n>` is the invocation ceiling; the
  machine budget remains authoritative across processes and worktrees.
- **Worker capacity is coordinated across worktrees.** The internal worker-budget module uses per-user, reclaimable filesystem leases. Its default budget is the host's logical processor count; `LWPT_WORKER_BUDGET` overrides it.
- **TLS is platform-native on Windows and macOS in both directions.** Clients use SChannel on Windows, SecureTransport on macOS, and system OpenSSL on other Unix. Server accept is native SChannel on Windows, Secure Transport on macOS, and requires runtime-loaded OpenSSL 3 or newer on Unix-not-Darwin. Only the registry's HTTPS listener uses Network.framework, and only on Darwin kernel 25 and newer (macOS 26 and newer); on kernel 24 and older it uses the portable listener with Secure Transport. Per [ADR-0016](./adr/0016-tls-backend-per-platform.md), [ADR-0024](./adr/0024-openssl-server-tls-accept.md), [ADR-0033](./adr/0033-schannel-server-tls-accept-on-windows.md), and [ADR-0043](./adr/0043-self-hosted-registry-origin.md); see [`deployment.md`](./deployment.md#tls-backends-per-platform).
- **EXDEV-rename failures fall back safely.** When `.lwpt/tmp/` and a file destination end up on different filesystems, `AtomicMoveFile` copies into an unaddressed sibling on the destination filesystem and atomically replaces the destination before deleting the source. Directory moves retain their recursive copy-then-delete fallback.
- **Compiler outputs are session-private.** Build and test invocations write
  below the resolved project-owned build-session root; only a successful,
  revalidated build
  result is atomically published to its manifest output.
- **Every resolved subcommand reports completion.** A status-aware elapsed-time
  line is written to stderr after ordinary success or failure diagnostics.
  Every command also inherits long-only `--silent` for final-result-only use;
  silent success writes its sole completion line to stdout (or, for
  `registry publish` and `registry issue-token`, their one outcome line
  instead), and neither mode changes the command's exit code.
- **Local Win32 iteration is cached.** On the maintainer Mac,
  [`.github/ci/windows-wine/run.sh`](../.github/ci/windows-wine/run.sh)
  uses OrbStack's Docker engine to cross-compile i386-win32 and run bounded
  Wine-compatible smoke checks. Wine does not replace the final native Windows
  console-control proof.
- **Duplication analysis is Pascal-native and offline.** `lwpt duplication`
  reports deterministic Type-2 token clones in manifest-owned root and
  workspace sources. The remaining deferred stack contracts stay tracked
  separately. Architecture drift is a project-local release-preparation check
  for LWPT itself; it is not a customer feature.
- **Codebase health is shipped.** `lwpt health` is an offline Pascal complexity report with opt-in local Git hotspots; [`health.md`](./health.md) owns the scoring and configuration contract.

## Pinned versions

| Tool | Pinned for v1 | Verify with |
| --- | --- | --- |
| FreePascal | 3.2.2 | `fpc -iV` |
| InstantFPC | bundled with FPC | `instantfpc --help` |
| Lefthook | 2.x | `lefthook version` |
| git-cliff | Verify the installed release live | `git-cliff --version` |
| Docker Engine with BuildKit | Not pinned; CI uses the GitHub-hosted `ubuntu-latest` engine and logs `docker version` | `docker version`. Used by the registry container smoke in CI ([`registry-deployment.md`](./registry-deployment.md)) and the local Win32 Wine helper. Building, testing, and using LWPT never require Docker. |
| OpenSSL (Unix-not-Darwin only) | 3.x | `openssl version` on Unix. Windows and macOS never load it: both directions are SChannel / SecureTransport (per [ADR-0033](./adr/0033-schannel-server-tls-accept-on-windows.md) and [ADR-0016](./adr/0016-tls-backend-per-platform.md)). The CI PE-import guard keeps Windows free of any OpenSSL linkage. |

When you touch code that depends on the version, **verify it live, not from memory.** The Hard Constraint in `AGENTS.md` is explicit about this. If you bump a version, the new pin lives in this file and in the relevant CI workflow.

## Command completion timing

Every registered subcommand invocation ends with one status-aware line.
Ordinary successful and failed completion are written to stderr, with failure
following its diagnostics:

```text
lwpt build: completed in 1.24s
lwpt build: failed after 0.03s
```

The duration uses an increasing millisecond clock and is rendered in seconds to
two decimal places. Existing diagnostics and exit codes are unchanged.
`lwpt run <subcommand>` reports the resolved subcommand name, so
`lwpt run build` ends with `lwpt build: ...`. Top-level help, version output,
and unknown command names are not resolved subcommand executions and do not get
a completion line. The output-neutral sequenced event envelope and LWPT's typed
payload ownership are documented in the
[architecture guide](./architecture.md#output-and-observability-boundary).

Every registered subcommand also inherits the long-only `--silent` flag after
the command name. Silent success suppresses progress, summaries, and successful
child output and writes exactly the final completion line to stdout. The
exception is a command whose result is a single outcome line: silent
`registry publish` writes only its `published ...` or `already published ...`
line, and silent `registry issue-token` only the token, each instead of the
completion line ([ADR-0049](./adr/0049-registry-remote-publication.md)). Silent
failure suppresses ordinary progress, replays retained diagnostics and failed
child output in event order, and ends with exactly one failed completion line
on stderr. `--silent --verbose` is rejected because the two policies
contradict each other. `init --silent` also requires `--yes` or `--adopt` so an
invisible prompt cannot block the invocation. Aliases follow the resolved identity, so
`lwpt run build --silent` finishes as `lwpt build: ...`; there is deliberately
no `lwpt --silent build`, short alias, or silent top-level help/version mode.

The host retains silent events in a 64 MiB temporary journal while a
preallocated 1 MiB emergency ring continuously mirrors protected diagnostics
and recent output. Child output is grouped by invocation and promoted to
protected evidence only when that child exits unsuccessfully, so a successful
hook cannot leak into a later compiler failure. Journal creation, write,
capacity, or replay failure degrades
to that ring without changing the command's exit code or stopping child-pipe
drainage. A failed degraded invocation says so before replaying the surviving
tail. If the emergency reserve cannot be allocated, LWPT fails before invoking
the selected command.

## Pre-commit hook

Lefthook config (`lefthook.yml`):

```yaml
pre-commit:
  commands:
    format:
      glob: "*.{pas,inc,dpr,toml}"
      run: ./build/lwpt format
      stage_fixed: true
    agents:
      glob: "*.{pas,toml,md}"
      run: ./build/lwpt agents
      stage_fixed: true
```

The local hook refreshes formatting and the generated `AGENTS.md` command reference; both commands re-stage their changes. The heavyweight checks — `lwpt format --check` + `lwpt build` + `lwpt agents --check` + `lwpt test` — run on the PR workflow rather than every local commit, keeping local commits fast and the pre-merge gate strict.

Install once per fresh clone: `lefthook install`.

Do **not** use `--no-verify` unless a maintainer explicitly authorises it on the PR.

## Environment variables

| Variable | Effect | Default |
| --- | --- | --- |
| `LWPT_CACHE_DIR` | Absolute or working-directory-relative root for per-user immutable cache namespaces. Dependency archives use `dependency-archives/`; paths never enter committed project state. | `%LOCALAPPDATA%\lwpt\cache` on Windows, `~/Library/Caches/lwpt` on macOS, `$XDG_CACHE_HOME/lwpt` or `~/.cache/lwpt` on other Unix systems |
| `LWPT_CACHE_MAX_BYTES` | Aggregate regular-file byte budget for the complete per-user shared cache, including objects, references, control files, producer metadata, staging, and quarantine. This is user-owned process configuration, not a project manifest setting. `0` disables new admissions and lets repair evict all unleased objects. | `10737418240` (10 GiB) |
| `LWPT_REGISTRY_STATE_DIR` | Root of per-user registry consumer state: accepted-state files under `origins/` and the authenticated document store under `documents/`. | the platform application-config directory's `registry/` subdirectory |
| `LWPT_REGISTRY_STATE_MAX_BYTES` | Byte budget for evictable documents in the per-user registry document store. Documents in a stored origin state's accepted history are never evicted and never counted; beyond the budget, installs evict the least recently used of the rest. `0` keeps only accepted histories. An integer from 0 through 9223372036854775807; anything else fails registry acquisition (before any request) and `lwpt repair` with `registry_state_budget_invalid`. | `67108864` (64 MiB) |
| `LWPT_REGISTRY_TOKEN` | Publication token read by `lwpt registry publish` when `--token-env` is not given; `--token-env=<name>` reads a different variable instead. Never written to disk or printed. | unset |
| `LWPT_SESSION_DIR` | Build/test session base; relative values resolve from the invocation working directory and override `[lwpt].sessions-dir` | unset |
| `LWPT_WORKER_BUDGET` | Maximum aggregate LWPT workers for this user and machine | logical processor count |
| `LWPT_WORKER_STATE_DIR` | Override the worker coordinator state root; an explicit unwritable path fails rather than falling back | the platform application-config directory's `workers/` subdirectory, with automatic fallback to the repository's `.lwpt/workers/` when that default is unwritable |
| `LWPT_WORKER_LEASE_STALE_SECONDS` | Mark heartbeat diagnostics stale after this interval; values below 3 are rejected. Heartbeat age never authorises reclamation by itself. | `30` |
| `LWPT_WORKER_LEASE_TOKEN` | One-shot opaque delegation token added to one nested LWPT subprocess by the worker-budget API; do not configure, reuse, or persist manually | unset |
| `LWPT_PRODUCER_LEASE_STALE_SECONDS` | Mark producer heartbeat diagnostics stale after this interval; values below 3 are rejected. Heartbeat age never authorises reclamation while the OS-held owner guard exists. | `30` |
| `FPC_TARGET_CPU` | Requested compiler target processor. A non-host value is probed and passed as `-P<value>`; unavailable dispatch fails without fallback. | unset (host CPU) |
| `FPC_TARGET_OS` | Requested compiler target operating system. A non-host value is probed and passed as `-T<value>`; unavailable targets fail without fallback. | unset (host OS) |
| `LWPT_FPC` | Path to the FPC binary; overrides `PATH` lookup. The bare `FPC` variable is honoured as a fallback. | unset (`fpc` on `PATH`) |
| `LWPT_FPC_UNIT_PATHS` | Path-separator-delimited unit directories appended as `-Fu`/`-Fi` to every compile (CI uses it for non-standard FPC installs; see the prose below) | unset |
| `LWPT_COMPILER_TIMEOUT_MS` | Positive compiler-process timeout in milliseconds; capability probes retain their fixed 30-second deadline | 30 minutes |
| `LWPT_HEARTBEAT_INTERVAL_MS` | Diagnostic tuning knob: build/test heartbeat interval; values are clamped to the default ceiling | `30000` |
| `PATH` | Must contain `fpc`, `instantfpc`, `lefthook`; `git` too for `lwpt health --hotspots`, the only command that runs it | system default |
| `LWPT_BUILD_ENTRY` | Per-entry postbuild hook context: selected build-entry name | supplied by LWPT |
| `LWPT_BUILD_OUTPUT` | Per-entry postbuild hook context: session-private candidate path; transform this file before publication | supplied by LWPT |
| `LWPT_BUILD_PUBLIC_OUTPUT` | Per-entry postbuild hook context: requested manifest output path | supplied by LWPT |
| `LWPT_PROCESS_TREE_PARENT`, `LWPT_PROCESS_TREE_STATUS_HANDLE`, `LWPT_PROCESS_TREE_CONTROL_HANDLE`, `LWPT_PROCESS_TREE_CHANNEL_TOKEN` | Internal: set by LWPT on managed child processes for cascading process-tree cancellation ([ADR-0025](./adr/0025-cascading-process-tree-cancellation.md)); do not configure | set by LWPT |
| `TESTING_PASCAL_LIBRARY_INVENTORY`, `TESTING_PASCAL_LIBRARY_INVENTORY_EXECUTABLE`, `TESTING_PASCAL_LIBRARY_ACTIVE_CASE_FILE` | Internal: set by `lwpt test` on test programs for inventory-only listing and active-case diagnostics, read by the `testing` package; do not configure | set by `lwpt test` |

## Per-user dependency archive cache

Normal materializing installs admit each downloaded archive into an immutable
SHA-256 object store below the per-user cache root. A later project whose
existing machine-written lockfile proves the same source selection and archive
hash can reuse that object without downloading the bytes. If Git ref discovery
is unavailable, the recorded authoritative ref/commit may also be reused when
it still satisfies the complete manifest constraint set. This is the offline
materialization path; `lwpt install --frozen` remains verification-only and
never repairs missing project state.

Every hit is hashed before use, copied through the destination project's
`.lwpt/tmp/`, hashed again, and atomically published to its ordinary committed
`.lwpt/archives/` name. Cache filenames are not trusted, project archives are
not hardlinked, and no cache path is written to `lwpt.lock`. Corrupt objects are
moved to the store's `quarantine/` namespace and treated as misses. Incomplete
writes remain unaddressed below `tmp/`; same-key concurrent writers can publish
only complete bytes proving the same digest. Cache read/write failures emit a
warning and fall back to the source because the disposable cache is never
required for correctness. See
[ADR-0036](./adr/0036-per-user-dependency-archive-cas.md).

## Shared cache lifecycle

The dependency and build namespaces share one user-owned size budget. The
budget counts all regular-file bytes below the shared cache root, including
immutable objects, build-result references, lifecycle control files, producer
metadata, and incomplete or quarantined state pending repair. Every verified
hit advances a monotonic access sequence, so admission evicts the
least-recently-used object with the object identity as the deterministic tie
break. Admission never completes above the effective budget: an oversized
object, or one that cannot fit without deleting live state, is simply not
cached. The project-owned archive or freshly built output remains
authoritative.

Object admission and materialization hold per-object operating-system guards.
Eviction skips those guards and therefore preserves objects still being
produced, verified, or copied into a private project/session path. A short
cache-root mutation guard serializes index publication and eviction across
processes; it does not serialize independent downloads or compiles. Build
references are invalidated under that guard before their result manifest or
transitively named artifact is removed, so new readers see a miss while a
reader already holding the artifact guard may finish safely.

`lwpt repair` is the only maintenance command. It removes incomplete staging
and quarantined corruption, reclaims producer metadata only when its OS guard
is no longer held, atomically detaches the guarded key directory before
recursive removal so a concurrent link substitution cannot redirect cleanup,
using the directory rename itself as the final producer race check on Windows,
verifies content-addressed bytes, rebuilds a corrupt LRU index from verified
object manifests, removes malformed or incomplete transitive build references,
and enforces the current budget. Its
report names bytes reclaimed, corrupt objects removed, and live objects and
leases preserved. Live producer metadata and guarded object bytes may keep a
repair result above budget; the report makes that preservation explicit and a
later repair can reclaim the released state. Repeating repair on the repaired
state is safe and reports zero further reclamation. Shared-cache repair never
deletes the invoking project's committed `.lwpt/archives/` or
`.lwpt/modules/` state. See
[ADR-0040](./adr/0040-bounded-shared-cache-lifecycle.md).

## Machine-wide worker budget

`LWPT.WorkerBudget` provides the capacity seam used by parallel schedulers.
`lwpt build` acquires one lease per actively compiling build entry, while `lwpt test`
requests up to one worker per runnable test. Both are capped by the effective
machine budget, and `--jobs=N` sets a smaller invocation request.

Each invocation registers a session request in a per-user state root shared by
all worktrees. LWPT resolves that root once per process. When the default
application-config path cannot create and remove a unique sentinel file, LWPT
applies the same probe to the current repository's `.lwpt/workers/` directory.
It prints the fallback notice only after that probe passes. If neither root is
writable, LWPT fails with an error directing the user to
`LWPT_WORKER_STATE_DIR`. A valid fallback keeps write-restricted sandboxes
working but forfeits cross-worktree budget sharing. An explicit
`LWPT_WORKER_STATE_DIR` remains authoritative and fails if unwritable. The
effective budget is the first invocation's configured `LWPT_WORKER_BUDGET`, or
the logical processor count when unset. Free Pascal 3.2.2 can report only one
processor through `TThread.ProcessorCount`, so LWPT asks the OS directly: on
macOS it reads `hw.logicalcpu`, and on Linux `sysconf(_SC_NPROCESSORS_ONLN)`.
If the OS query fails, LWPT falls back to the runtime count with a minimum of
one. Later invocations adopt that active
budget until all current requests finish. A request cannot hold more than its
own requested worker count or the effective machine budget.

Short state transactions use `fcntl` on Unix and `LockFileEx` on Windows. Each
active request has a lifetime owner guard held by the operating system and
records its diagnostic PID, requested and granted workers, FIFO wait ticket,
lease-token hashes, pending delegation verifiers, start time, lease start, and
heartbeat. Each acquisition gets a new ticket, so releasing and reacquiring
never jumps ahead of an existing waiter. Owner death releases the guard and
allows immediate reclamation without relying on the PID, so PID reuse cannot
preserve a dead request. A stale heartbeat is reported but never authorises
reclamation while the owner guard remains held. Unreadable, malformed, and
unknown-schema requests with a live owner guard reserve capacity
conservatively rather than being deleted.

Nested LWPT subprocesses inherit capacity explicitly with
`AppendWorkerLeaseEnvironment`. It adds a cryptographically random,
one-shot `LWPT_WORKER_LEASE_TOKEN` to one child environment. The coordinator
stores only its verifier and atomically consumes it by transferring one grant
from the parent request to the child's own owner-guarded request. The parent
lease becomes locally unavailable and the parent reacquires through the FIFO
after the child finishes. Reuse and fan-out from one lease fail. The raw token
is never persisted or logged. The child clears the consumed token from its
process environment before running work, so unrelated descendants do not
inherit a dead delegation. The child remains counted independently if the
parent exits. Tokens are not command-line arguments, diagnostics, or project
configuration.

Session-local lease lists and counters are protected for concurrent scheduler
threads. Acquisitions join the FIFO queue serially and releases update durable
coordinator state before changing local state, so an explicit release can be
retried after a lock or atomic-write failure. Scheduler threads must join before
destroying their shared session.

`lwpt repair` now reclaims abandoned worker requests and prints diagnostics for
the remaining coordinator state. The report identifies session IDs, PIDs,
granted capacity, waiting state, lease age, heartbeat age, effective budget,
and state-root path.

## TLS backend per platform

Per [ADR-0016](./adr/0016-tls-backend-per-platform.md), the `TransportSecurity` unit (in `packages/httpclient/source/`) selects the TLS implementation by FPC conditional — each platform uses what ships with the OS:

- **Windows.** **SChannel** via `secur32.dll` (Windows API; built into every Windows install since Windows 2000) for both the client path and, per [ADR-0033](./adr/0033-schannel-server-tls-accept-on-windows.md), server accept — with `crypt32.dll` importing the PKCS#12 identity into a snapshot-owned, persisted user CNG key container that is deleted on ordinary teardown. No DLLs to install, no DLLs in the release archive, no OpenSSL in either direction. CI rejects normal, delay-loaded, renamed, legacy, and static OpenSSL linkage while permitting runtime-loader strings.
- **macOS.** **SecureTransport** via Apple's framework (built into every macOS install). No Homebrew dependency, no `DYLD_LIBRARY_PATH` setup.
- **Linux** (and other Unix-not-Darwin). **System OpenSSL** loaded at runtime via `DynLibs.LoadLibrary`. Install the distro's libssl package: `apt install libssl3` / `dnf install openssl-libs` / `apk add openssl3-libs` / equivalent. No special configuration beyond that — the library is usually already present (every distro pulls it in transitively via `curl`, `git`, `wget`, etc.).

The per-platform selection above is the **client** (outbound) story. The **server accept** path added per [ADR-0024](./adr/0024-openssl-server-tls-accept.md) is nonblocking memory-BIO OpenSSL on Unix-not-Darwin, per [ADR-0033](./adr/0033-schannel-server-tls-accept-on-windows.md) nonblocking native SChannel on Windows, and native Secure Transport on macOS, each with an identical observable contract. Its primary input is a maximum 16 MiB caller-supplied PKCS#12 byte array; it privately copies and wipes those bytes, while the path overload opens once without following links and delegates. Strict validation of validity, explicit server purpose, leaf/CA constraints, and bundled chain coherence is the default; conformant leaves may omit basic constraints, while bundled issuers must carry them. `tsivPermissive` is an explicit self-signed development option and neither mode consults platform system trust. Atomic reload publishes a fully built immutable snapshot, existing connections retain their original reference, and a failed reload preserves the active snapshot. Listeners stop and join `Begin` and `Reload` callers before closing the holder; established connections can outlive it through retained snapshots. The API converts passphrases to UTF-8 and wipes temporary copies, installs intermediate certificates, and exposes WANT states plus `tssPeerClosed`. `Active` becomes true only after authentication. Retained ciphertext drains before another protocol operation, its returned span stays stable until consumed, and WANT-write plaintext is retained internally for a nil, zero-length resume call. Consumers must enforce a handshake deadline and byte budget. Network.framework is used only by the registry's HTTPS listener on Darwin kernel 25 and newer, which bypasses this server context ([ADR-0043](./adr/0043-self-hosted-registry-origin.md); see [`deployment.md`](./deployment.md#tls-backends-per-platform)).

If `lwpt install` fails on Linux with `HTTPS requires OpenSSL but it could not be loaded`, install the distro's libssl package. Windows + macOS never hit this path on the client side. Documented in [`quick-start.md`](./quick-start.md).

## Atomic writes + EXDEV rename fallback

Every committed-path write in LWPT goes through `.lwpt/tmp/` first. The helpers in `LWPT.Core` are:

| Helper | Used by |
| --- | --- |
| `AtomicWriteText(Dst, TmpRoot, StringList)` | `WriteLock`, `WriteCfg` |
| `AtomicWriteBytes(Dst, TmpRoot, Bytes)` | `FetchToCache` (network archive download) |
| `AtomicMoveFile(Src, Dst)` | Same-filesystem replacement, or cross-filesystem copy to an unaddressed destination sibling followed by atomic replacement |
| `AtomicMoveDir(Src, Dst)` | fixed-point resolver plan publication |

On the same filesystem, `rename(2)` is one syscall. Across filesystems (a Docker bind mount of `.lwpt/` onto a different volume; a network drive; certain remote-pair-programming setups), `rename` fails with `EXDEV`. File moves then copy into a unique unaddressed sibling of the destination and atomically replace the public path only after that copy completes; the source is deleted last. A crash therefore leaves readers on the complete old destination and may leave only a sibling/tmp orphan for repair. Directory moves use recursive copy-then-delete because operating systems expose no portable atomic cross-filesystem directory replacement.

If EXDEV failures are persistent and the fallback is too slow, ensure `.lwpt/` lives on the same filesystem as the project root (don't bind-mount it).

### Windows paths past MAX_PATH

Toolkit state nests 64-character hash names: committed registry proofs, and rollback copies of proofs and modules below the journaled `.lwpt/tmp/install-transaction.*` root. In a deep checkout those paths pass the 260-character Win32 `MAX_PATH`, which the plain-path Win32 APIs and the FPC RTL file routines built on them enforce ([#347](https://github.com/frostney/lwpt/issues/347)). On Windows, `LWPT.Core`'s `LongPath*` primitives, `ListDirectoryEntries` and `OpenProtectedFileStream` therefore address every path by its extended-length spelling (`\\?\C:\...`, or `\\?\UNC\server\share\...`). `WindowsExtendedPath` builds that spelling from Win32's own parse of the ordinary path (`GetFullPathNameW`), so it names exactly what the ordinary path named: relative and root-relative paths resolve against the current drive or UNC directory, trailing dots and spaces fold, a reserved device name stays a device, and a trailing separator still names only a directory. On Unix the primitives delegate to the SysUtils routines of the same name.

These paths use them:

- the atomic helpers and everything they call: directory creation, enumeration and deletion, file open and copy, the EXDEV fallback, tree hashing, rollback retention and restore, and atomic replacement;
- the install transaction (shared by `add`, `remove`, `update` and repair's lock upgrade): the install lock, the rollback journal and its crash recovery, resolver plan staging, archive staging and verification, registry proof publication and committed proof and lockfile reads, dependency manifest reads from staging, and object-store materialization into the project;
- `lwpt repair`: the install lock, `.lwpt/tmp/`, abandoned build sessions (state, age, owner guard, root identity and ledger), and the retired-image sweep beside build outputs.

Three limits remain by design. Archive extraction keeps the legacy budget (259 characters for a file, 247 for a directory) and fails before writing when an entry would exceed it, because an extracted module tree must stay usable by the compiler and by tools that are not long-path aware. Builds and tests stay bound by the compiler's own 255-character path limit ([#309](https://github.com/frostney/lwpt/issues/309)), so build-input fingerprinting and compilation use ordinary paths, and a project root that deep cannot build anyway. Per-user stores (the shared dependency cache, producer leases, registry consumer state, registry server data) and user files outside toolkit state (`lwpt format`, `lwpt init`, workspace discovery) are not covered.

Toolkit-state streams take no `flock()` on Unix: `OpenProtectedFileStream` and the `AtomicWrite*` helpers open without FPC's share-mode lock, because an inherited flock wedged producer leases on Darwin (#312), and readers coordinate with writers through the install lock, producer leases and atomic rename rather than through advisory locks.

On Windows, a shared read through `OpenProtectedFileStream` (`fmOpenRead or fmShareDenyNone`) shares read, write and delete access, as a Unix descriptor does ([#372](https://github.com/frostney/lwpt/issues/372)). FPC's `fmShareDenyNone` shares only read and write, and that conflicts with an atomic replacement in both directions. The write-through rename keeps its handle, with delete access, open while the renamed file is already visible, so such a reader failed with a sharing violation. `ReplaceFileW` refuses to replace a file that a reader holds without delete sharing, so the publication failed. A shared read also retries `ERROR_SHARING_VIOLATION`, and only that, for up to one second (`PROTECTED_READ_SHARING_RETRY_MILLISECONDS`), because a handle without read sharing, such as a scanner's, can hold a fresh file briefly. Other share modes keep FPC's meaning. The case that needs this most is the registry consumer, which reads per-user state and documents without the producer lease while another project's install publishes them. `ReplaceFileW` moves the replaced file to its backup name before it moves the replacement in: its `ERROR_UNABLE_TO_MOVE_REPLACEMENT_2` contract describes a failure of the second step after the first has completed, and Wine's implementation does both renames on every successful call. A reader can therefore find the path briefly absent during a replacement. Per-user documents are never replaced, only published once and evicted, so this does not affect them. Per-user state is replaced, and a reader that took that moment for a fresh state directory would lose the per-user sequence prior and clock floor and could accept an older, still valid checkpoint. `LoadRegistryConsumerStateAt` therefore reads an absent state file, or one it cannot open, again under the per-origin producer lease that every merge holds while it replaces the file, so the read waits for a replacement in progress and then sees its result. A merge, which already holds that lease, and an eviction pass, which holds the store lease that every merge also holds while it writes, read the file directly.

## Install lock + crash recovery

`lwpt install` acquires a cross-process lock at `.lwpt/install.lock` before doing any work (`LWPT.InstallLock`, [ADR-0053](./adr/0053-install-lock-ownership-and-reclamation.md)). The file's existence is the mutual exclusion: it is created with `O_CREAT|O_EXCL` on Unix and `CREATE_NEW` on Windows, so only one process wins the create. A second concurrent `lwpt install` fails fast with `EConcurrencyError` naming the lock holder's command and PID. The normally-completing owner deletes the file; a crashed one leaves it behind.

Liveness is an operating-system record lock on the same file: `fcntl` `F_SETLK` on byte 0 on Unix, an exclusive `LockFileEx` on byte 1024 on Windows. After creating the file, the owner takes the record lock, checks that the path still names the file it created (an owner whose file was taken over, removed, or replaced meanwhile fails without touching it), and only then writes its owner record: the PID on the first line (the only line older binaries wrote), `holder=install` or `holder=repair`, and `lock=record`. It deletes the file before it releases the record lock. The kernel releases the record lock when the owner dies; it is not inherited by child processes and does not depend on PIDs. On a filesystem that keeps no record locks, the owner proceeds but writes no `lock=record` line.

`lwpt repair` takes the same lock before it recovers an interrupted install and sweeps `.lwpt/tmp/`, and releases it before the schema-v3 upgrade, whose install transaction takes it again. When the file exists, repair takes it over only when the owner is provably dead: it holds the record lock, its open file is still the one at the path, and the owner record carries `lock=record`. That owner held the record lock when it wrote the record and holds it no more, so it has exited, whatever process its PID names now (repair's own included). Repair adopts the file in place, rewriting the owner record while it holds the record lock, so the path never disappears and no install can create a lock meanwhile. Otherwise repair fails with `EConcurrencyError` and changes nothing:

- the record lock is held: the owner runs, and the error names it; a second repair, or an install, finds a running repair the same way;
- the filesystem keeps no record locks: nothing proves the owner dead or keeps a second repair out;
- the record has no `lock=record` line: it was written by LWPT 0.7.0 or earlier, or on a filesystem without record locks. A PID cannot prove such an owner dead, because it may run in another PID namespace or on another host sharing the project;
- the file has no owner record: its creator is still starting, or died between creating the file and writing the record. No age proves which.

Any other locking error is reported with its code. In the refused cases that name it, recover by hand: once no `lwpt install` or `lwpt repair` runs for the project anywhere, other hosts and containers sharing it included, delete `.lwpt/install.lock` and run `lwpt repair`. LWPT 0.7.0's `lwpt repair` still deletes the lock unconditionally, so never run it beside a newer install.

Within one process, `fcntl` record locks are released when any descriptor of the file is closed. A process therefore registers an install-lock path before opening it, refuses a second acquisition of a path it holds, and reads and writes the owner record only through the locked descriptor; a failing contender reads the holder's record through a read-only open.

Before publication, old committed paths are copied and content-validated below one pending transaction directory in `.lwpt/tmp/`; they are not removed merely to create a backup. Retention preserves the exact object type, including raw symlink or junction target data instead of copying through links. Successful publication writes a committed marker before discarding those copies. After a crash, `lwpt repair` takes over the dead owner's install lock and, while it holds it, restores every pending entry before its ordinary tmp sweep. Rollback validates backups before touching the current path, catches each restore exception independently, attempts all later restores, retains failed evidence, and reports aggregate failures alongside the original error. Frozen verification neither performs recovery nor cleans tmp, keeping failure paths read-only for lockfile, cfg, and modules state.

## Build sessions and publication

Build and test sessions are project-owned and process-owned. They use
`LWPT_SESSION_DIR`, then `[lwpt].sessions-dir`, then the project-local default.
Configured bases receive an identity-verified project-hash namespace; absolute
shallow bases are recommended for dependable FPC path-budget relief. Each
compiler
invocation receives private executable and unit-output directories. A build
captures a schema-versioned, compiler-neutral publication fingerprint covering
the selected compiler identity, executable, and live version; the requested
build-entry source/output/mode plus target-tuple dimensions; the previous public-output content; and
the manifest, cfg, lockfile, implicit source directory,
source/include/resource paths, and installed modules.

After compilation succeeds, LWPT acquires a short lock derived from the public
output path. A keyed in-process critical section complements the OS-held
advisory byte-range lock on a stable file, so threads and processes both
serialize publication and process exit still releases OS ownership without a
stale-file unlink race. LWPT captures the fingerprint again and refuses
publication if any declared input changed. Search-root hashing excludes
the resolved build-session root and declared build outputs, follows workspace directory
links with physical cycle detection, and content-hashes directories from
`LWPT_FPC_UNIT_PATHS`; explicit file inputs remain hashed even if also listed
as outputs. A current candidate is replaced with one same-filesystem
atomic rename. Failed and stale candidates never become public and remain
below the session for diagnosis. `--clean` means fresh session staging plus a
forced compiler rebuild; it does not sweep `build/`, delete the running LWPT
executable, or remove another process's output.

Build reuse is a separate per-user namespace over `LWPT.ObjectStore`. Its
schema-versioned fingerprint excludes session paths and the previous public
artifact while covering the neutral request, effective driver invocation,
source/resource/workspace/dependency content, target, hooks, and relevant
environment. A hit is hash-verified into the new session and still crosses the
ordinary postbuild and publication boundary. A miss reports a stable reason;
`--no-cache` reports `disabled` and performs neither lookup nor admission.
Only a successfully published candidate is stored, so failures, cancellation,
staleness, and hook failures cannot seed later hits.

Per-entry postbuild hooks run before publication with the private candidate
in `LWPT_BUILD_OUTPUT`, the requested path in `LWPT_BUILD_PUBLIC_OUTPUT`, and
the entry name in `LWPT_BUILD_ENTRY`. Runtime retargeting also maps existing
`{item.output}`-expanded hook fields to the private candidate. Hook failure
keeps the candidate private, and hook definitions, commands, arguments, and
declared inputs are revalidated before publication. For dependency-free manifests, the
whole-build postbuild hook runs against all staged outputs and gates batch
publication. A declared build-entry graph publishes prerequisites progressively;
its whole-build postbuild runs once after all selected outputs publish.
Lifecycle hooks are never compiled: each runs its declared `command` with its
`args` directly as a child process. Compiler directories use
bounded readable prefixes plus hashes of their full source identities, so
different paths cannot collide after sanitisation.

Each session holds an OS owner guard from before it becomes visible until final
state is written. Successful completion removes compiler jobs but retains stable job logs; `lwpt repair` removes only unlocked sessions and
conservatively retains live guards even when their state file is malformed.
Repair also deletes retired executable images (`.lwpt-retired-*.tmp`) that a
Windows build publication left beside a declared build output because the
replaced image was still running; images still in use stay and are reported.
It never follows or removes links and skips, with a message, any output
directory outside the project or reached through a symlink or junction.
Relocated roots are atomically recorded in `.lwpt/session-roots`; repair reads
only exact historical entries whose full project identity matches.

## Duplication analysis

`lwpt duplication [--json]` scans only the Pascal files resolved from the
manifest-owned analysis scope. It compares typed regions so a match never spans
a routine or unit-section boundary; executable regions compare only with other
executable regions, and declaration regions only with declarations. Whitespace,
comments, and Pascal letter case are ignored. Identifiers and literals may be
renamed when their token kinds and equality pattern remain consistent, which
makes the detector Type-2 rather than text-only.

Candidates are selected by descending normalized length and stable source
coordinates. The report retains maximal non-overlapping occurrences, including
same-file and cross-file groups, and verifies each new occurrence against every
member already accepted into its clone group. Aggregate duplication is duplicate
tokens beyond each group's first occurrence divided by all analyzed region tokens.
The default minimum is 100 normalized tokens:

```toml
[duplication]
minimum-tokens = 100
# maximum-percent = 5
```

`minimum-tokens` may be lowered to 25, but not below it. `maximum-percent` is
an optional integer from 0 through 100; the command fails only when the observed
percentage is strictly greater than that value. Without a maximum it is
report-only. Root settings are inherited by workspaces; a workspace's own
`[duplication]` table replaces them. The root maximum gates the complete scope,
while workspace maxima also gate duplication internal to that package.
`[analysis].include` and `[analysis].exclude` remain the single source-selection
policy shared with `lwpt health`.

Human output is the default. `--json` writes the versioned shared analysis
envelope plus a duplication-owned payload containing effective project policy,
token totals, clone groups, stable locations, and the threshold outcome. Both
forms are deterministic and the command performs no network operations.

## Analysis command status

ADR-0006 originally deferred several customer-facing stack contracts beyond the
build system and formatter. Duplication analysis and codebase health now ship:

| Contract | Workstream | Notes |
| --- | --- | --- |
| **Codebase-health** (`lwpt health`) | Delivered; see [`health.md`](./health.md) | Deterministic routine/file complexity, optional local Git hotspots, stable JSON, and strict opt-in thresholds. |
| **Duplication** (`lwpt duplication`) | Delivered from [issue #32](https://github.com/frostney/lwpt/issues/32) | Deterministic Type-2 clone reporting across manifest-owned source scope. |

The v1 pre-commit gate excludes these analysis commands; they run on demand or
through an explicit consumer gate. ADR-0006 records the original deferral.
Architecture drift is checked across LWPT's source, tests, manifests,
workflows, documentation, ADRs, and domain context during release preparation;
it is not exposed to consumer projects.

## Other deferrals

| Item | Status | Comes back in |
| --- | --- | --- |
| Markdown linting (`markdownlint-cli2` + `.markdownlint-cli2.jsonc`) | Wired in `pr.yml` docs job | Keep blocking; fix Markdown drift rather than making the job advisory |
