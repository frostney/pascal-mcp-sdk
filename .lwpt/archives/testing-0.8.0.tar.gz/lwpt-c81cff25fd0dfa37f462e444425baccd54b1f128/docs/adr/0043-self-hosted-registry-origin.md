# Self-hosted registry origin lifecycle

> **Extended by [ADR-0045](./0045-verified-registry-mirror.md) and
> [ADR-0049](./0049-registry-remote-publication.md).** The `registry` command
> family is no longer only `init|serve`. ADR-0045 adds the mirror role
> (`registry init --role mirror`), `registry sync`, `registry verify`, and
> local `registry rotate-key`. ADR-0049 adds remote publication:
> `registry publish`, `registry issue-token`, `registry revoke-token`, and
> authenticated publication requests on `registry serve`.
> [ADR-0051](./0051-registry-dependency-sources.md) specifies the consumer
> side. The Darwin transport selector below picks Secure Transport for every
> kernel release below 25, not only kernel 24.

Issue [#53](https://github.com/frostney/lwpt/issues/53) turns the registry
protocol from [a wire contract](../registry-spec.md) into an origin that the
LWPT executable can initialize and run. The command surface is
`lwpt registry init|serve`: one ADR-backed command family with lifecycle
operations below it, rather than two unrelated top-level subcommands. This is
the interface approved by the registry parent issue and preserves the frozen
top-level vocabulary as one cohesive capability.

`registry init` accepts `--data-dir`, `--identity`, `--base-url`, `--listen`,
`--port`, `--tls-pkcs12`, and `--tls-password-env`. Its deterministic defaults
are `.lwpt/registry`, `http://localhost:8080`, `localhost`, and port `8080`.
On first initialization the canonical base URL becomes the identity unless an
explicit canonical HTTPS identity is supplied. Later initialization may move
the base URL or listener and atomically updates operational configuration, but
an existing identity cannot change. `registry serve` opens that data directory
and remains in the foreground; process supervisors own daemonization and
restart policy.

## Storage and activation

The data directory is an origin, not an install cache:

```text
registry.toml
keys/root.seed
keys/ed25519-<public-key-hash>.toml
objects/sha256/<hash>
records/sha256/<hash>.toml
snapshots/sha256/<hash>.toml
checkpoints/<sequence>.toml
checkpoints/<sequence>.sig.toml
checkpoints/renewals/sha256/<checkpoint-hash>.toml
checkpoints/renewals/sha256/<checkpoint-hash>.sig.toml
indexes/sha256/<package-name-hash>.toml
state/current.toml
locks/
tmp/
```

Archives and protocol metadata are immutable at their content-addressed path.
Writing different bytes to an occupied path is an `immutable_conflict`.
Publishing an existing `(origin, name, version)` with identical bytes is
idempotent; different bytes are an `identity_conflict`. A per-package version
index is replaced atomically and is a derived lookup aid, not a trust root.
Its filename is the SHA-256 of the canonical UTF-8 package name, so every
protocol-valid name has the same safe storage key on Windows, macOS, and Unix.

Publication writes the archive, record, next snapshot, checkpoint, and
detached signature before replacing `state/current.toml`. That one small
atomic pointer is the authority for the complete committed checkpoint,
signature, and snapshot. Derived version indexes are atomically replaced only
after activation and are rebuilt from the active snapshot after a crash. An
index or numeric checkpoint ahead of the pointer is never publication proof
and cannot make a retry idempotent or consume a sequence.

Publication takes an operating-system advisory producer lease. Its persistent
guard and diagnostic files do not establish liveness: the kernel lock is
released when a process exits. Startup reclaims `tmp/` only after acquiring
that lease, then verifies the activated snapshot hash, checkpoint relationship,
key record, signature payload, and Ed25519 signature. If a publisher is live,
startup leaves its staging alone and serves the previous committed pointer.
Initialization and operational reconfiguration use a separate operating-system
lease from marker inspection through commit. Recovery removes only enumerated
origin-owned artifacts carrying a valid initialization marker; it never wipes
the caller's data root. Every registry path rejects symbolic-link and reparse
components before reads, writes, recovery, or serving.

All committed-state writes use atomic replacement. The private seed has a
stricter creation path: staging and destination are private from their first
open, Unix mode `0600` or the Windows owner-and-system ACL is verified before
commit, and initialization fails closed if that cannot be guaranteed. The
password is read from the named environment variable only while constructing
the TLS listener, and its mutable buffer is wiped before the listener run loop
begins; it is never persisted. The PKCS#12 path is persisted as an absolute
path so a supervisor may restart from another working directory. Its components
are opened without following links, and a nonblocking retained handle must name
a regular file before any bytes are imported.

An active checkpoint is renewed when less than 24 hours of its seven-day
validity remains. Renewal keeps the package sequence and snapshot unchanged,
writes a content-addressed checkpoint and signature, then atomically replaces
the same state pointer. Historical sequence checkpoint bytes never change.

## Signing and diagnostics

`LWPT.Registry.Crypto` is the shared signing and verification primitive for
origin, mirror, resolver, and cache consumers. It implements SHA-512 and
RFC 8032 Ed25519 in Pascal, produces the same bytes on every release platform,
uses platform secure randomness only for seed generation, rejects non-canonical
signature scalars, noncanonical field encodings, and small-order public keys
and `R` points. RFC 8032 positive vectors and negative forgery vectors pin the
behavior. It does not select OpenSSL, Security.framework, or CNG signing APIs,
which prevents provider defaults from changing registry identity across
platforms.

Registry failures begin with a stable lowercase reason code followed by a
colon, including `insecure_transport`, `identity_conflict`,
`immutable_conflict`, `publication_locked`, `snapshot_hash_mismatch`,
`signature_payload_mismatch`, and `signature_invalid`. Human detail may grow;
consumers branch only on the code.

## Listener and TLS lifecycle

Plain HTTP is accepted only when the canonical base URL host is the exact name
`localhost` and the listener is `localhost` or `127.0.0.1`. A wildcard,
private address, or other host produces `insecure_transport` before serving.

HTTPS uses the repository's native server policy:

- Windows uses the HTTPClient package's native SChannel server context.
- Unix other than Darwin uses its runtime-loaded OpenSSL 3 memory-BIO server
  context.
- macOS 26 and newer import the configured PKCS#12 identity into a
  process-private temporary keychain, validate its bundled chain with a
  private anchor and Apple's server policy, and serve with Network.framework.
  The current-user 0600 PID-and-random-nonce keychain file remains available
  for lazy private-key access while the server is active; graceful shutdown
  verifies deletion, and the next start recovers an exact owned file only
  after its PID is definitely dead. FPC 3.2.2 reaches the Network C API
  through the stable blocks ABI, with one serial queue per connection.
- macOS 15 and older use the portable socket listener and the HTTPClient
  package's public Secure Transport server backend. Its PKCS#12 import uses an
  isolated temporary keychain without changing the default keychain or search
  list. Because Security.framework legitimately replaces the file while
  importing and caches `SecKeychainOpen` references by path, neither inode
  continuity nor `CFEqual` proves which post-import object occupies that path.
  The backend instead writes a bounded CSPRNG-derived marker into the explicit
  isolated keychain, moves the candidate to an unpredictable same-directory
  quarantine, reopens only that path, and requires the marker there before
  publishing its identity. Ordinary teardown uses the resulting public
  CoreServices `FSRef` with `FSUnlinkObject`, which removes that object even if
  its pathname is replaced. Scan-capped recovery atomically moves a candidate
  to a separate unpredictable quarantine, validates its device, inode, owner,
  and file type, binds an `FSRef`, validates the reference's resolved object,
  and unlinks only that object. Pathname replacements are preserved and fail
  closed. Recovery also
  requires that the residue's owner PID is definitely dead. The feed/drain
  connection contract keeps parsing, routing, resources, deadlines, and
  shutdown in the same registry implementation used on other platforms.

The registry selects these Darwin transports from the public runtime Darwin
kernel release returned by `uname`: kernel 25 and newer selects
Network.framework, while kernel 24 selects Secure Transport. These correspond
to macOS 26 and newer and macOS 15, respectively. The selector does not
synthesize a macOS marketing version, depend on compatibility-sensitive
Foundation product-version reporting, or inspect CPU architecture.

The portable socket listeners on Windows, Unix other than Darwin, and macOS
15 and older accept
`localhost` or an IPv4 address. Initialization rejects other listener families
there rather than persisting a configuration that can fail only at `serve`.
The macOS 26-and-newer Network.framework listener also accepts IPv6 addresses.

The listener admits at most 32 owned connections, handles each independently,
and closes it after one bounded HTTP/1.1 GET or HEAD request. One ten-second
monotonic deadline covers handshake, request, and response; request headers are
capped at 32 KiB, and every short response send rechecks the same absolute
deadline. Unix sends suppress SIGPIPE per socket: Linux uses `MSG_NOSIGNAL`,
while Darwin listeners enable `SO_NOSIGPIPE` for accepted sockets. Committed-
state reads and hashes report progress in 64 KiB
steps to the same deadline before routing may select a resource. Fixed-schema
configuration, state, checkpoint, signature, key, and seed documents are capped
at 1 MiB before allocation or parsing; snapshot verification hashes its retained
stream without materializing the snapshot. A response resource is capped at
2,147,483,647 bytes, matching the platform-safe maximum accepted by the current
publication and state-loading surface. The listener opens every path component
without following links,
retains verified parent handles through a nonblocking regular-file open, checks
the resource length and digest in cancellable 64 KiB steps, rewinds that retained
handle, and sends from the same handle through one connection-owned buffer. The
route descriptor carries the authoritative digest for content-addressed files;
other routed files are hashed under the same deadline, so the later retained
delivery handle must prove the exact bytes that routing accepted. The
same retained component-safe boundary protects committed configuration, state,
checkpoint, signature, index, and signing-seed reads during startup, recovery,
and publication. The listener never builds a second body-sized wire response in
memory. Shutdown
interrupts acceptance, cancels every client, drains
its workers or Network.framework callbacks, and only then releases the store
and TLS context. Hashed objects, records, and snapshots are SHA-256 checked
again before every response and receive immutable cache headers. Checkpoint
aliases and historical checkpoint paths require cache revalidation.

Discovery and capabilities advertise only the implemented read surface:
checkpoint, key, package-record, snapshot, and object schemas with
`snapshot-sync-v1`. [ADR-0045](0045-verified-registry-mirror.md) extends this
with local signed key rotation and the `rotation-chain-v1` read endpoints.
Package lists and remote publication remained issue #54 and were not
advertised here; [ADR-0049](0049-registry-remote-publication.md) adds them.

## Rejected alternatives

- **Run tasks as the server interface.** Run tasks launch user commands and
  cannot own persisted identity, generated trust roots, recovery, or a stable
  cross-project contract.
- **Extend project `init`.** Project scaffolding and registry-origin creation
  have unrelated state, secrets, and lifecycle rules.
- **Rewrite `latest.toml` and `latest.sig.toml` independently.** Two renames
  permit a reader to observe a checkpoint and signature from different
  publications. The activation pointer makes their relationship atomic.
- **Use cache eviction or mutable object paths.** An origin is authoritative
  durable state. Cache policy must never remove a snapshot ancestor or replace
  published bytes.
- **Select a platform Ed25519 provider.** Provider-specific parsing and
  canonicality behavior would make signatures and diagnostics drift between
  release targets.

## Consequences

The origin can be hosted directly by LWPT and supervised by any ordinary
process manager. Old snapshots and objects accumulate until an explicit,
protocol-aware retention design is approved; general cache repair and eviction
must not touch them. Remote publication, mirror synchronization, and registry
dependency resolution build on this store and shared crypto unit in issues #54
and #55.
