{ LWPT.BuildSession — private compiler staging and atomic publication. }
unit LWPT.BuildSession;

{$I Shared.inc}
{$J-}

interface

uses
  Classes,
  SysUtils,

  LWPT.BuildRequest,
  LWPT.Core;

const
  BUILD_SESSION_SCHEMA_VERSION = 1;
  BUILD_PUBLICATION_FINGERPRINT_SCHEMA_VERSION = 1;
  BUILD_CACHE_FINGERPRINT_SCHEMA_VERSION = 2;
  BUILD_CACHE_OPERATION_BUILD_ENTRY = 'build-entry';
  BUILD_CACHE_OPERATION_TEST_PROGRAM = 'test-program';
  BUILD_SESSIONS_DIR = LWPT_DIR + '/sessions';
  BUILD_SESSION_DIR_ENV = PROJECT_NAME + '_SESSION_DIR';
  BUILD_SESSION_ROOT_LEDGER = LWPT_DIR + '/session-roots';
  ObservabilityLogsDirectory = '/logs/';
  ObservabilityLogExtension = '.log';
  { FPC's RTL FileRec/TextRec name buffer holds this many characters. The
    compiler writes .s assembly files and link scripts through that API and
    silently truncates longer paths: the assembly lands under a truncated
    name while the assembler command line carries the full path, so clang
    fails with "no such file or directory: ....s". Session staging must
    keep every compiler-written path within this budget. }
  COMPILER_PATH_LIMIT = 255;

type
  TLWPTBuildPublicationRequest = record
    BuildRequest: TLWPTBuildRequest;
    CompilerExecutable: string;
    CompilerArguments: TStringArray;
    ManifestContentHash: string;
    PublicOutput: string;
    Environment: TStringArray;
    CompilerImplicitInputs: TStringArray;
    WorkspacePaths: TStringArray;
    PrerequisiteOutputs: TStringArray;
    HookDefinition: TStringArray;
    HookInputs: TStringArray;
    ExcludedPaths: TStringArray;
  end;

  TLWPTBuildPublicationResult = (bprPublished, bprStale);

  TLWPTBuildSession = class
  private
    FProjectRoot: string;
    FSessionsRoot: string;
    FDefaultSessionsRoot: Boolean;
    FSessionID: string;
    FSessionRoot: string;
    FSessionOwnerGuardPath: string;
    FSessionOwnerGuard: TObject;
    FFinished: Boolean;
    function JobLogPath(const AName: string): string;
    procedure WriteState(const AState: string);
  public
    constructor Create(const AProjectRoot: string); overload;
    constructor Create(const AProjectRoot, ASessionsRoot: string); overload;
    destructor Destroy; override;
    function JobRoot(const AName: string): string;
    function JobLogReference(const AName: string): string;
    function SessionReference: string;
    procedure WriteJobLog(const AName, AOutput: string);
    procedure Finish(ASuccess: Boolean; const ADetail: string = '');
    property SessionID: string read FSessionID;
    property SessionRoot: string read FSessionRoot;
    property SessionsRoot: string read FSessionsRoot;
  end;

function ResolveBuildSessionsRoot(const AProjectRoot,
  AManifestSessionsDir, AEnvironmentBase: string): string;
function BuildSessionsProjectRoot(const AProjectRoot,
  AConfiguredRoot: string): string;

function CaptureBuildPublicationFingerprint(
  const AProjectRoot, AManifestPath, ACfgPath, ALockPath,
  AModulesPath: string;
  const ARequest: TLWPTBuildPublicationRequest): string;
function CaptureBuildCacheFingerprint(
  const AProjectRoot, AManifestPath, ACfgPath, ALockPath,
  AModulesPath: string;
  const ARequest: TLWPTBuildPublicationRequest;
  const AOperation: string = BUILD_CACHE_OPERATION_BUILD_ENTRY): string;
function NeutralBuildCacheRequest(const ARequest: TLWPTBuildRequest;
  const APublicOutput: string): TLWPTBuildRequest;
function BuildSessionPathKey(const AValue: string): string;
procedure AppendUnitDirsFromOptions(const AOptions: TStrings;
  var ADirs: TStringArray);
procedure AppendUnitDirsFromCfg(const ACfgPath: string;
  var ADirs: TStringArray);
function LongestCompiledBaseNameLength(const ADirectories: TStringArray;
  const AEntrySource: string): Integer;
procedure EnsureCompilerPathBudget(const AUnitDirectory,
  AExecutableDirectory: string; ALongestBaseNameLength: Integer);
function BuildPublicationLockPath(const ASessionsRoot, AOutput: string): string;
{ Take the project's build-coordination lock, the session-root ledger lock
  that every build's publication already shares across processes, threads
  and relocated session roots, for a short project-wide critical section.
  Free the result to release it. }
function AcquireBuildCoordinationLock(const AProjectRoot: string): TObject;
function PublishBuildArtifact(const AProjectRoot, ACandidatePath,
  ADestinationPath, AExpectedFingerprint, AManifestPath, ACfgPath,
  ALockPath, AModulesPath: string;
  const ARequest: TLWPTBuildPublicationRequest;
  const ASessionsRoot: string = ''):
  TLWPTBuildPublicationResult;
procedure RepairBuildSessions(const AProjectRoot: string;
  out ARemoved, ARetained: Integer); overload;
procedure RepairBuildSessions(const AProjectRoot, ATemporaryRoot: string;
  out ARemoved, ARetained: Integer;
  out ATemporaryRootCleaned: Boolean); overload;

implementation

uses
  {$IFDEF UNIX}
  BaseUnix,
  Unix,
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  Windows,
  {$ENDIF}
  DateUtils;

const
  PUBLICATION_LOCK_WAIT_MILLISECONDS = 30000;
  SESSION_PARTIAL_GRACE_MILLISECONDS = 5000;
  SESSION_ROOT_LEDGER_SCHEMA_VERSION = 1;
  SESSION_ROOT_IDENTITY_SCHEMA_VERSION = 2;
  SESSION_ROOT_IDENTITY_FILE = 'project.identity';
  {$IFDEF UNIX}
  {$IFDEF LINUX}
  F_WRLCK_LWPT = 1;
  F_UNLCK_LWPT = 2;
  {$ELSE}
  F_WRLCK_LWPT = F_WRLCK;
  F_UNLCK_LWPT = F_UNLCK;
  {$ENDIF}
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  LOCKFILE_EXCLUSIVE_LOCK_LWPT = $00000002;
  LOCKFILE_FAIL_IMMEDIATELY_LWPT = $00000001;
  {$ENDIF}

var
  NextSessionCounter: QWord;
  PublicationCriticalSections:
    array[0..63] of TRTLCriticalSection;

type
  ELWPTParsedManifestChanged = class(ELWPTError);

  {$IFDEF UNIX}
  {$IFDEF LINUX}
  TLWPTFlock = BaseUnix.FLock;
  {$ELSE}
  TLWPTFlock = TFlock;
  {$ENDIF}
  {$ENDIF}

  TLWPTPublicationLock = class
  private
    FPath: string;
    FCriticalSectionIndex: Integer;
    FCriticalSectionEntered: Boolean;
    {$IFDEF UNIX}
    FDescriptor: LongInt;
    {$ENDIF}
    {$IFDEF MSWINDOWS}
    FHandle: THandle;
    {$ENDIF}
  public
    constructor Create(const APath: string);
    destructor Destroy; override;
  end;

  TLWPTSessionOwnerGuard = class
  private
    FPath: string;
    FLocked: Boolean;
    {$IFDEF UNIX}
    FDescriptor: LongInt;
    {$ENDIF}
    {$IFDEF MSWINDOWS}
    FHandle: THandle;
    {$ENDIF}
  public
    constructor Create(const APath: string);
    destructor Destroy; override;
  end;

function RootedPath(const AProjectRoot, APath: string): string;
begin
  if APath = '' then Exit('');
  if (APath[1] = '/') or (APath[1] = '\')
    or ((Length(APath) >= 2) and (APath[1] in ['a'..'z', 'A'..'Z'])
      and (APath[2] = ':')) then
    Exit(ExpandFileName(APath));
  Result := ExpandFileName(IncludeTrailingPathDelimiter(AProjectRoot) + APath);
end;

function TextHash(const AText: string): string;
var
  Bytes: TBytes;
begin
  SetLength(Bytes, Length(AText));
  if Length(AText) > 0 then
    Move(AText[1], Bytes[0], Length(AText));
  Result := SHA256BytesPrefixed(Bytes);
end;

function ResolveBuildSessionsRoot(const AProjectRoot,
  AManifestSessionsDir, AEnvironmentBase: string): string;
var
  EnvironmentValue: string;
begin
  EnvironmentValue := SysUtils.GetEnvironmentVariable(
    BUILD_SESSION_DIR_ENV);
  if EnvironmentValue <> '' then
    Exit(RootedPath(AEnvironmentBase, EnvironmentValue));
  if AManifestSessionsDir <> '' then
    Exit(RootedPath(AProjectRoot, AManifestSessionsDir));
  Result := RootedPath(AProjectRoot, BUILD_SESSIONS_DIR);
end;

function BuildSessionPathKey(const AValue: string): string;
var
  BaseName, Digest: string;
begin
  { Keys sit inside compiler staging paths that must stay within
    COMPILER_PATH_LIMIT, so the readable prefix and the digest are both
    kept short. 12 hex digits (48 bits) still make accidental collisions
    between the handful of keys inside one session implausible. }
  BaseName := SanitisePathSegment(ChangeFileExt(ExtractFileName(AValue), ''));
  if BaseName = '' then BaseName := 'job';
  if Length(BaseName) > 16 then SetLength(BaseName, 16);
  Digest := TextHash(AValue);
  Result := BaseName + '-' + Copy(Digest, 8, 12);
end;

{ Single home for "which directories does this compile search for unit
  sources". Both the target-build flow (cfg passed to FPC unexpanded via
  @file) and the test/script flow (cfg already expanded onto the parameter
  list) feed the path-budget check through these two helpers, so the two
  flows cannot silently diverge in how they extract -Fu directories. }
procedure AppendUnitDirsFromOptions(const AOptions: TStrings;
  var ADirs: TStringArray);
var
  i, Count: Integer;
  Line: string;
begin
  for i := 0 to AOptions.Count - 1 do
  begin
    Line := Trim(AOptions[i]);
    if Copy(Line, 1, 3) <> '-Fu' then Continue;
    Count := Length(ADirs);
    SetLength(ADirs, Count + 1);
    ADirs[Count] := Copy(Line, 4, MaxInt);
  end;
end;

procedure AppendUnitDirsFromCfg(const ACfgPath: string;
  var ADirs: TStringArray);
var
  Lines: TStringList;
begin
  if not FileExists(ACfgPath) then Exit;
  Lines := TStringList.Create;
  try
    LoadProtectedStrings(Lines, ACfgPath);
    AppendUnitDirsFromOptions(Lines, ADirs);
  finally
    Lines.Free;
  end;
end;

function LongestCompiledBaseNameLength(const ADirectories: TStringArray;
  const AEntrySource: string): Integer;
var
  i, Len: Integer;
  Search: TSearchRec;
  Dir, Ext: string;
begin
  { The compiler writes '<unit>.s' into the staging unit directory for the
    entry program and for every unit it recompiles from the search paths.
    Scanning the search paths for the longest Pascal base name makes the
    path budget below exact instead of guessing an allowance. A long-named
    unit that the entry never uses still counts — refusing such a compile
    is deliberate: any unit on a search path is one uses-clause edit away
    from compiling, and a deterministic setup error beats the truncation
    failure appearing only once that edit lands. }
  Result := Length(ChangeFileExt(ExtractFileName(AEntrySource), ''));
  for i := 0 to High(ADirectories) do
  begin
    if ADirectories[i] = '' then Continue;
    Dir := IncludeTrailingPathDelimiter(ExpandFileName(ADirectories[i]));
    if SysUtils.FindFirst(Dir + '*', faAnyFile, Search) <> 0 then Continue;
    try
      repeat
        if (Search.Attr and faDirectory) <> 0 then Continue;
        Ext := LowerCase(ExtractFileExt(Search.Name));
        if (Ext <> '.pas') and (Ext <> '.pp') then Continue;
        Len := Length(ChangeFileExt(Search.Name, ''));
        if Len > Result then Result := Len;
      until SysUtils.FindNext(Search) <> 0;
    finally
      SysUtils.FindClose(Search);
    end;
  end;
end;

procedure EnsureCompilerPathBudget(const AUnitDirectory,
  AExecutableDirectory: string; ALongestBaseNameLength: Integer);
const
  { Longest fixed-name artefact FPC writes beside the executable
    ('symbol_order.fpc'; 'ppaslink.sh' and 'link.res' are shorter). }
  LINK_ARTEFACT_LENGTH = 16;
var
  UnitDirectory, ExecutableDirectory: string;
  WorstLength, LinkLength: Integer;
begin
  UnitDirectory := ExpandFileName(AUnitDirectory);
  ExecutableDirectory := ExpandFileName(AExecutableDirectory);
  WorstLength := Length(UnitDirectory) + 1 + ALongestBaseNameLength
    + Length('.s');
  LinkLength := Length(ExecutableDirectory) + 1 + LINK_ARTEFACT_LENGTH;
  if LinkLength > WorstLength then WorstLength := LinkLength;
  if WorstLength <= COMPILER_PATH_LIMIT then Exit;
  raise ELWPTError.CreateFmt(
    'compiler staging path is too long: files below "%s" would reach %d '
    + 'characters, but FPC''s file API silently truncates paths over %d '
    + 'characters and the compile then fails with a missing .s file; '
    + 'shorten the project path by at least %d characters',
    [UnitDirectory, WorstLength, COMPILER_PATH_LIMIT,
     WorstLength - COMPILER_PATH_LIMIT]);
end;

function SamePath(const AFirst, ASecond: string): Boolean;
begin
  {$IFDEF MSWINDOWS}
  Result := SameText(ExpandFileName(AFirst), ExpandFileName(ASecond));
  {$ELSE}
  Result := ExpandFileName(AFirst) = ExpandFileName(ASecond);
  {$ENDIF}
end;

function PathIsExcluded(const AProjectRoot, APath: string;
  const AExcludedPaths: TStringArray): Boolean;
var
  i: Integer;
begin
  for i := 0 to High(AExcludedPaths) do
    if (AExcludedPaths[i] <> '')
       and SamePath(APath, RootedPath(AProjectRoot, AExcludedPaths[i])) then
      Exit(True);
  Result := False;
end;

function DirectoryIdentity(const APath: string): string;
{$IFDEF UNIX}
var
  Info: BaseUnix.Stat;
begin
  if FpStat(APath, Info) <> 0 then Exit('');
  Result := IntToStr(Info.st_dev) + ':' + IntToStr(Info.st_ino);
end;
{$ENDIF}
{$IFDEF MSWINDOWS}
var
  Handle: THandle;
  Info: TByHandleFileInformation;
begin
  Result := '';
  Handle := Windows.CreateFileW(PWideChar(WindowsExtendedPath(APath)), 0,
    Windows.FILE_SHARE_READ or Windows.FILE_SHARE_WRITE
      or Windows.FILE_SHARE_DELETE,
    nil, Windows.OPEN_EXISTING, Windows.FILE_FLAG_BACKUP_SEMANTICS, 0);
  if Handle = THandle(Windows.INVALID_HANDLE_VALUE) then Exit;
  try
    if Windows.GetFileInformationByHandle(Handle, Info) then
      Result := IntToStr(Info.dwVolumeSerialNumber) + ':'
        + IntToStr(Info.nFileIndexHigh) + ':'
        + IntToStr(Info.nFileIndexLow);
  finally
    Windows.CloseHandle(Handle);
  end;
end;
{$ENDIF}

function InputDirectoryFingerprint(const AProjectRoot, ARoot: string;
  const AExcludedPaths: TStringArray): string;
var
  Files, VisitedDirectories: TStringList;
  SessionsRoot: string;
  SessionsIdentity: string;

  procedure Collect(const ADir, ARelative: string);
  var
    Entries: TStringList;
    Search: TSearchRec;
    Base, Full, Relative, Identity: string;
    Attr, i: Integer;
  begin
    if PathContains(SessionsRoot, ADir) then Exit;
    if PathIsExcluded(AProjectRoot, ADir, AExcludedPaths) then Exit;
    Identity := DirectoryIdentity(ADir);
    if (Identity <> '') and (Identity = SessionsIdentity) then Exit;
    if (Identity <> '') and (VisitedDirectories.IndexOf(Identity) >= 0) then
      Exit;
    if Identity <> '' then VisitedDirectories.Add(Identity);
    Base := IncludeTrailingPathDelimiter(ADir);
    Entries := TStringList.Create;
    Entries.CaseSensitive := True;
    if SysUtils.FindFirst(Base + '*', faAnyFile or faSymLink, Search) <> 0 then
    begin
      Entries.Free;
      Exit;
    end;
    try
      repeat
        if (Search.Name <> '.') and (Search.Name <> '..') then
          Entries.Add(Search.Name);
      until SysUtils.FindNext(Search) <> 0;
    finally
      SysUtils.FindClose(Search);
    end;
    Entries.Sort;
    try
      for i := 0 to Entries.Count - 1 do
      begin
        Full := Base + Entries[i];
        if SysUtils.FindFirst(Full, faAnyFile or faSymLink, Search) <> 0 then
          Continue;
        try
          Attr := Search.Attr;
        finally
          SysUtils.FindClose(Search);
        end;
        Relative := ARelative + Entries[i];
        if PathIsExcluded(AProjectRoot, Full, AExcludedPaths) then Continue;
        if (Attr and faSymLink) <> 0 then
        begin
          if DirectoryExists(Full) then
            Collect(Full, Relative + '/')
          else if FileExists(Full) then
            Files.Add(IntToStr(Length(Relative)) + ':' + Relative + '='
              + SHA256File(Full));
        end
        else if (Attr and faDirectory) <> 0 then
        begin
          if not PathContains(SessionsRoot, Full) then
            Collect(Full, Relative + '/');
        end
        else
          Files.Add(IntToStr(Length(Relative)) + ':' + Relative + '='
            + SHA256File(Full));
      end;
    finally
      Entries.Free;
    end;
  end;

begin
  Files := TStringList.Create;
  VisitedDirectories := TStringList.Create;
  try
    SessionsRoot := RootedPath(AProjectRoot, BUILD_SESSIONS_DIR);
    SessionsIdentity := DirectoryIdentity(SessionsRoot);
    Collect(ARoot, '');
    Files.Sort;
    { Hash inputs never inherit the platform line ending: TStrings.Text joins
      with CRLF on Windows and LF elsewhere. LF keeps LF-platform digests
      byte-identical. }
    Files.LineBreak := #10;
    Result := TextHash(Files.Text);
  finally
    VisitedDirectories.Free;
    Files.Free;
  end;
end;

function PathFingerprint(const AProjectRoot, APath: string;
  const AExcludedPaths: TStringArray): string;
var
  Full: string;
begin
  Full := RootedPath(AProjectRoot, APath);
  if Full = '' then Exit('<none>');
  { Explicit files remain inputs even when they are also declared outputs.
    Exclusions apply to broad tree walks so unrelated published artifacts do
    not invalidate another target. }
  if FileExists(Full) then Exit('file:' + SHA256File(Full));
  if PathIsExcluded(AProjectRoot, Full, AExcludedPaths) then Exit('<excluded>');
  if DirectoryExists(Full) then
    Exit('tree:' + InputDirectoryFingerprint(AProjectRoot, Full,
      AExcludedPaths));
  Result := 'missing';
end;

procedure AddField(AFields: TStrings; const AName, AValue: string);
begin
  AFields.Add(AName + '=' + IntToStr(Length(AValue)) + ':' + AValue);
end;

procedure AddPathArray(AFields: TStrings; const AProjectRoot, AName: string;
  const APaths, AExcludedPaths: TStringArray);
var
  i: Integer;
begin
  AddField(AFields, AName + '.count', IntToStr(Length(APaths)));
  for i := 0 to High(APaths) do
  begin
    AddField(AFields, AName + '.' + IntToStr(i) + '.path', APaths[i]);
    AddField(AFields, AName + '.' + IntToStr(i) + '.content',
      PathFingerprint(AProjectRoot, APaths[i], AExcludedPaths));
  end;
end;

procedure AddStringArray(AFields: TStrings; const AName: string;
  const AValues: TStringArray);
var
  i: Integer;
begin
  AddField(AFields, AName + '.count', IntToStr(Length(AValues)));
  for i := 0 to High(AValues) do
    AddField(AFields, AName + '.' + IntToStr(i), AValues[i]);
end;

function CaptureBuildPublicationFingerprint(
  const AProjectRoot, AManifestPath, ACfgPath, ALockPath,
  AModulesPath: string;
  const ARequest: TLWPTBuildPublicationRequest): string;
var
  Fields: TStringList;
  EmptyPaths: TStringArray;
  ManifestFingerprint, SourceDirectory: string;
begin
  SetLength(EmptyPaths, 0);
  Fields := TStringList.Create;
  try
    AddField(Fields, 'schema',
      IntToStr(BUILD_PUBLICATION_FINGERPRINT_SCHEMA_VERSION));
    ValidateBuildRequest(ARequest.BuildRequest);
    AddField(Fields, 'build-request',
      SerializeBuildRequest(ARequest.BuildRequest));
    AddField(Fields, 'compiler.executable', ARequest.CompilerExecutable);
    AddStringArray(Fields, 'compiler.arguments', ARequest.CompilerArguments);
    AddField(Fields, 'manifest.parsed-hash', ARequest.ManifestContentHash);
    AddPathArray(Fields, AProjectRoot, 'sources',
      ARequest.BuildRequest.Inputs.Sources, EmptyPaths);
    SourceDirectory := ExtractFileDir(
      RootedPath(AProjectRoot, ARequest.BuildRequest.Inputs.EntryPoint));
    AddField(Fields, 'source-directory', SourceDirectory);
    AddField(Fields, 'source-directory.content',
      PathFingerprint(AProjectRoot, SourceDirectory,
        ARequest.ExcludedPaths));
    AddField(Fields, 'output', ARequest.PublicOutput);
    AddField(Fields, 'output.previous',
      PathFingerprint(AProjectRoot, ARequest.PublicOutput, EmptyPaths));
    AddStringArray(Fields, 'environment', ARequest.Environment);
    AddStringArray(Fields, 'excluded-paths', ARequest.ExcludedPaths);
    AddPathArray(Fields, AProjectRoot, 'unit-paths',
      ARequest.BuildRequest.Inputs.UnitPaths, ARequest.ExcludedPaths);
    AddPathArray(Fields, AProjectRoot, 'include-paths',
      ARequest.BuildRequest.Inputs.IncludePaths, ARequest.ExcludedPaths);
    AddPathArray(Fields, AProjectRoot, 'workspace-paths',
      ARequest.WorkspacePaths, ARequest.ExcludedPaths);
    AddPathArray(Fields, AProjectRoot, 'prerequisite-outputs',
      ARequest.PrerequisiteOutputs, EmptyPaths);
    AddPathArray(Fields, AProjectRoot, 'resources',
      ARequest.BuildRequest.Inputs.Resources, ARequest.ExcludedPaths);
    AddStringArray(Fields, 'hook-definition', ARequest.HookDefinition);
    AddPathArray(Fields, AProjectRoot, 'hook-inputs',
      ARequest.HookInputs, ARequest.ExcludedPaths);
    ManifestFingerprint := PathFingerprint(
      AProjectRoot, AManifestPath, EmptyPaths);
    if ManifestFingerprint <> 'file:' + ARequest.ManifestContentHash then
      raise ELWPTParsedManifestChanged.Create(
        'manifest changed after it was parsed');
    AddField(Fields, 'manifest', ManifestFingerprint);
    AddField(Fields, 'cfg',
      PathFingerprint(AProjectRoot, ACfgPath, EmptyPaths));
    AddField(Fields, 'lock',
      PathFingerprint(AProjectRoot, ALockPath, EmptyPaths));
    AddField(Fields, 'modules', PathFingerprint(AProjectRoot, AModulesPath,
      ARequest.ExcludedPaths));
    { Same invariant as InputDirectoryFingerprint: the fold separator is
      pinned, never inherited from the platform. }
    Fields.LineBreak := #10;
    Result := TextHash(Fields.Text);
  finally
    Fields.Free;
  end;
end;

function NeutralBuildCacheRequest(const ARequest: TLWPTBuildRequest;
  const APublicOutput: string): TLWPTBuildRequest;
const
  NEUTRAL_SESSION_ROOT = '<build-session>';
begin
  Result := ARequest;
  Result.Outputs.Artifact := APublicOutput;
  Result.Outputs.ExecutableDirectory := NEUTRAL_SESSION_ROOT + '/bin';
  Result.Outputs.UnitDirectory := NEUTRAL_SESSION_ROOT + '/units';
  Result.Outputs.ObjectDirectory := NEUTRAL_SESSION_ROOT + '/units';
  Result.Outputs.ResourceDirectory := NEUTRAL_SESSION_ROOT + '/resources';
end;

function CaptureBuildCacheFingerprint(
  const AProjectRoot, AManifestPath, ACfgPath, ALockPath,
  AModulesPath: string;
  const ARequest: TLWPTBuildPublicationRequest;
  const AOperation: string): string;
var
  EmptyPaths: TStringArray;
  Fields: TStringList;
  ManifestFingerprint, SourceDirectory: string;
  NeutralRequest: TLWPTBuildRequest;
begin
  SetLength(EmptyPaths, 0);
  Fields := TStringList.Create;
  try
    if AOperation = '' then
      raise ELWPTError.Create('cache operation identity must not be empty');
    AddField(Fields, 'schema',
      IntToStr(BUILD_CACHE_FINGERPRINT_SCHEMA_VERSION));
    AddField(Fields, 'operation', AOperation);
    ValidateBuildRequest(ARequest.BuildRequest);
    NeutralRequest := NeutralBuildCacheRequest(ARequest.BuildRequest,
      ARequest.PublicOutput);
    AddField(Fields, 'build-request', SerializeBuildRequest(NeutralRequest));
    AddField(Fields, 'compiler.executable', ARequest.CompilerExecutable);
    AddStringArray(Fields, 'compiler.arguments', ARequest.CompilerArguments);
    AddField(Fields, 'manifest.parsed-hash', ARequest.ManifestContentHash);
    AddPathArray(Fields, AProjectRoot, 'sources',
      ARequest.BuildRequest.Inputs.Sources, EmptyPaths);
    AddPathArray(Fields, AProjectRoot, 'compiler-implicit-inputs',
      ARequest.CompilerImplicitInputs, ARequest.ExcludedPaths);
    { Cache identity must survive an equivalent checkout at another absolute
      path. Content is still read relative to the concrete project root. }
    SourceDirectory := ExtractFileDir(
      ARequest.BuildRequest.Inputs.EntryPoint);
    AddField(Fields, 'source-directory', SourceDirectory);
    AddField(Fields, 'source-directory.content',
      PathFingerprint(AProjectRoot, SourceDirectory,
        ARequest.ExcludedPaths));
    AddField(Fields, 'output', ARequest.PublicOutput);
    AddStringArray(Fields, 'environment', ARequest.Environment);
    AddPathArray(Fields, AProjectRoot, 'unit-paths',
      ARequest.BuildRequest.Inputs.UnitPaths, ARequest.ExcludedPaths);
    AddPathArray(Fields, AProjectRoot, 'include-paths',
      ARequest.BuildRequest.Inputs.IncludePaths, ARequest.ExcludedPaths);
    AddPathArray(Fields, AProjectRoot, 'workspace-paths',
      ARequest.WorkspacePaths, ARequest.ExcludedPaths);
    AddPathArray(Fields, AProjectRoot, 'prerequisite-outputs',
      ARequest.PrerequisiteOutputs, EmptyPaths);
    AddPathArray(Fields, AProjectRoot, 'resources',
      ARequest.BuildRequest.Inputs.Resources, ARequest.ExcludedPaths);
    AddStringArray(Fields, 'hook-definition', ARequest.HookDefinition);
    AddPathArray(Fields, AProjectRoot, 'hook-inputs',
      ARequest.HookInputs, ARequest.ExcludedPaths);
    ManifestFingerprint := PathFingerprint(
      AProjectRoot, AManifestPath, EmptyPaths);
    if ManifestFingerprint <> 'file:' + ARequest.ManifestContentHash then
      raise ELWPTParsedManifestChanged.Create(
        'manifest changed after it was parsed');
    AddField(Fields, 'manifest', ManifestFingerprint);
    AddField(Fields, 'cfg',
      PathFingerprint(AProjectRoot, ACfgPath, EmptyPaths));
    AddField(Fields, 'lock',
      PathFingerprint(AProjectRoot, ALockPath, EmptyPaths));
    AddField(Fields, 'modules', PathFingerprint(AProjectRoot, AModulesPath,
      ARequest.ExcludedPaths));
    Fields.LineBreak := #10;
    Result := TextHash(Fields.Text);
  finally
    Fields.Free;
  end;
end;

function ProcessIsAlive(APID: LongInt): Boolean;
{$IFDEF UNIX}
begin
  if APID <= 0 then Exit(False);
  Result := (FpKill(APID, 0) = 0) or (fpgeterrno = ESysEPERM);
end;
{$ENDIF}
{$IFDEF MSWINDOWS}
var
  Handle: THandle;
  ExitCode: DWORD;
begin
  if APID <= 0 then Exit(False);
  Handle := Windows.OpenProcess(
    Windows.PROCESS_QUERY_INFORMATION, False, DWORD(APID));
  if Handle = 0 then Exit(False);
  try
    Result := Windows.GetExitCodeProcess(Handle, ExitCode)
      and (ExitCode = Windows.STILL_ACTIVE);
  finally
    Windows.CloseHandle(Handle);
  end;
end;
{$ENDIF}

function ReadPID(const APath: string): LongInt;
var
  Lines: TStringList;
begin
  Result := -1;
  if not LongPathFileExists(APath) then Exit;
  Lines := TStringList.Create;
  try
    LoadProtectedStrings(Lines, APath);
    if Lines.Count > 0 then
      Result := StrToIntDef(Trim(Lines[0]), -1);
  finally
    Lines.Free;
  end;
end;

function IncompleteStateIsAbandoned(const APath: string): Boolean;
var
  Age: LongInt;
begin
  Age := LongPathFileAge(APath);
  if Age < 0 then Exit(False);
  Result := MilliSecondsBetween(Now, FileDateToDateTime(Age))
    >= SESSION_PARTIAL_GRACE_MILLISECONDS;
end;

function EnsureDirectory(const APath: string): Boolean;
var
  Attempt: Integer;
begin
  for Attempt := 1 to 100 do
  begin
    if LongPathDirectoryExists(APath) or LongPathForceDirectories(APath) then
      Exit(True);
    Sleep(10);
  end;
  Result := LongPathDirectoryExists(APath);
end;

function ReadSessionState(const APath: string): string;
var
  Lines: TStringList;
begin
  Result := '';
  if not LongPathFileExists(APath) then Exit;
  Lines := TStringList.Create;
  try
    LoadProtectedStrings(Lines, APath);
    if Lines.Count > 1 then Result := Trim(Lines[1]);
  finally
    Lines.Free;
  end;
end;

constructor TLWPTSessionOwnerGuard.Create(const APath: string);
{$IFDEF UNIX}
var
  LockSpec: TLWPTFlock;
{$ENDIF}
{$IFDEF MSWINDOWS}
var
  Overlapped: TOverlapped;
{$ENDIF}
begin
  inherited Create;
  FPath := APath;
  FLocked := False;
  if not EnsureDirectory(ExtractFileDir(FPath)) then
    raise ELWPTError.CreateFmt(
      'could not create build session owner guard directory %s',
      [ExtractFileDir(FPath)]);
  {$IFDEF UNIX}
  FDescriptor := -1;
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  FHandle := THandle(Windows.INVALID_HANDLE_VALUE);
  {$ENDIF}
  {$IFDEF UNIX}
  FDescriptor := OpenProtectedDescriptor(FPath, O_RDWR or O_CREAT);
  if FDescriptor < 0 then
    raise ELWPTError.CreateFmt(
      'could not open build session owner guard %s', [FPath]);
  FillChar(LockSpec, SizeOf(LockSpec), 0);
  LockSpec.l_type := F_WRLCK_LWPT;
  LockSpec.l_whence := SEEK_SET;
  LockSpec.l_start := 0;
  LockSpec.l_len := 1;
  if FpFcntl(FDescriptor, F_SetLk, LockSpec) <> 0 then
  begin
    FpClose(FDescriptor);
    FDescriptor := -1;
    raise ELWPTError.CreateFmt(
      'build session owner guard is already held %s', [FPath]);
  end;
  FLocked := True;
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  FHandle := Windows.CreateFileW(PWideChar(WindowsExtendedPath(FPath)),
    Windows.GENERIC_READ or Windows.GENERIC_WRITE,
    Windows.FILE_SHARE_READ or Windows.FILE_SHARE_WRITE
      or Windows.FILE_SHARE_DELETE,
    nil, Windows.OPEN_ALWAYS, Windows.FILE_ATTRIBUTE_NORMAL, 0);
  if FHandle = THandle(Windows.INVALID_HANDLE_VALUE) then
    raise ELWPTError.CreateFmt(
      'could not open build session owner guard %s', [FPath]);
  FillChar(Overlapped, SizeOf(Overlapped), 0);
  if not Windows.LockFileEx(FHandle,
    LOCKFILE_EXCLUSIVE_LOCK_LWPT or LOCKFILE_FAIL_IMMEDIATELY_LWPT,
    0, 1, 0, Overlapped) then
  begin
    Windows.CloseHandle(FHandle);
    FHandle := THandle(Windows.INVALID_HANDLE_VALUE);
    raise ELWPTError.CreateFmt(
      'build session owner guard is already held %s', [FPath]);
  end;
  FLocked := True;
  {$ENDIF}
end;

destructor TLWPTSessionOwnerGuard.Destroy;
{$IFDEF UNIX}
var
  LockSpec: TLWPTFlock;
{$ENDIF}
{$IFDEF MSWINDOWS}
var
  Overlapped: TOverlapped;
{$ENDIF}
begin
  {$IFDEF UNIX}
  if FDescriptor >= 0 then
  begin
    if FLocked then
    begin
      FillChar(LockSpec, SizeOf(LockSpec), 0);
      LockSpec.l_type := F_UNLCK_LWPT;
      LockSpec.l_whence := SEEK_SET;
      LockSpec.l_start := 0;
      LockSpec.l_len := 1;
      FpFcntl(FDescriptor, F_SetLk, LockSpec);
    end;
    FpClose(FDescriptor);
    FDescriptor := -1;
  end;
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  if FHandle <> THandle(Windows.INVALID_HANDLE_VALUE) then
  begin
    if FLocked then
    begin
      FillChar(Overlapped, SizeOf(Overlapped), 0);
      Windows.UnlockFileEx(FHandle, 0, 1, 0, Overlapped);
    end;
    Windows.CloseHandle(FHandle);
    FHandle := THandle(Windows.INVALID_HANDLE_VALUE);
  end;
  {$ENDIF}
  FLocked := False;
  inherited Destroy;
end;

function SessionOwnerGuardHeld(const APath: string): Boolean;
{$IFDEF UNIX}
var
  Descriptor: LongInt;
  ErrorCode: Integer;
  LockSpec: TLWPTFlock;
begin
  Descriptor := OpenProtectedDescriptor(APath, O_RDWR);
  if Descriptor < 0 then
  begin
    ErrorCode := FpGetErrNo;
    Exit(ErrorCode <> ESysENOENT);
  end;
  try
    FillChar(LockSpec, SizeOf(LockSpec), 0);
    LockSpec.l_type := F_WRLCK_LWPT;
    LockSpec.l_whence := SEEK_SET;
    LockSpec.l_start := 0;
    LockSpec.l_len := 1;
    if FpFcntl(Descriptor, F_SetLk, LockSpec) = 0 then
    begin
      LockSpec.l_type := F_UNLCK_LWPT;
      FpFcntl(Descriptor, F_SetLk, LockSpec);
      Exit(False);
    end;
    Result := True;
  finally
    FpClose(Descriptor);
  end;
end;
{$ENDIF}
{$IFDEF MSWINDOWS}
var
  Handle: THandle;
  Overlapped: TOverlapped;
  ErrorCode: DWORD;
begin
  Handle := Windows.CreateFileW(PWideChar(WindowsExtendedPath(APath)),
    Windows.GENERIC_READ or Windows.GENERIC_WRITE,
    Windows.FILE_SHARE_READ or Windows.FILE_SHARE_WRITE
      or Windows.FILE_SHARE_DELETE,
    nil, Windows.OPEN_EXISTING, Windows.FILE_ATTRIBUTE_NORMAL, 0);
  if Handle = THandle(Windows.INVALID_HANDLE_VALUE) then
  begin
    ErrorCode := Windows.GetLastError;
    Exit(not (ErrorCode in
      [Windows.ERROR_FILE_NOT_FOUND, Windows.ERROR_PATH_NOT_FOUND]));
  end;
  try
    FillChar(Overlapped, SizeOf(Overlapped), 0);
    if Windows.LockFileEx(Handle,
      LOCKFILE_EXCLUSIVE_LOCK_LWPT or LOCKFILE_FAIL_IMMEDIATELY_LWPT,
      0, 1, 0, Overlapped) then
    begin
      Windows.UnlockFileEx(Handle, 0, 1, 0, Overlapped);
      Exit(False);
    end;
    Result := True;
  finally
    Windows.CloseHandle(Handle);
  end;
end;
{$ENDIF}

constructor TLWPTPublicationLock.Create(const APath: string);
var
  Started: TDateTime;
  PIDLine: AnsiString;
  Acquired: Boolean;
  i: Integer;
  {$IFDEF UNIX}
  LockSpec: TLWPTFlock;
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  Written: DWORD;
  Overlapped: TOverlapped;
  {$ENDIF}
begin
  inherited Create;
  FPath := APath;
  FCriticalSectionIndex := 0;
  for i := 1 to Length(FPath) do
    FCriticalSectionIndex :=
      (FCriticalSectionIndex * 33 + Ord(FPath[i]))
      mod Length(PublicationCriticalSections);
  FCriticalSectionEntered := False;
  {$IFDEF UNIX}
  FDescriptor := -1;
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  FHandle := THandle(Windows.INVALID_HANDLE_VALUE);
  {$ENDIF}
  EnterCriticalSection(
    PublicationCriticalSections[FCriticalSectionIndex]);
  FCriticalSectionEntered := True;
  try
    LongPathForceDirectories(ExtractFileDir(FPath));
    Started := Now;
    Acquired := False;
    {$IFDEF UNIX}
    FDescriptor := OpenProtectedDescriptor(FPath, O_RDWR or O_CREAT, &644);
    if FDescriptor < 0 then
      raise EConcurrencyError.CreateFmt(
        'could not open build publication lock %s', [FPath]);
    FillChar(LockSpec, SizeOf(LockSpec), 0);
    LockSpec.l_type := F_WRLCK_LWPT;
    LockSpec.l_whence := SEEK_SET;
    LockSpec.l_start := 0;
    LockSpec.l_len := 1;
    repeat
      Acquired := FpFcntl(FDescriptor, F_SetLk, LockSpec) = 0;
      if Acquired then Break;
      Sleep(10);
    until MilliSecondsBetween(Now, Started) >=
      PUBLICATION_LOCK_WAIT_MILLISECONDS;
    if not Acquired then
      raise EConcurrencyError.CreateFmt(
        'timed out waiting for build publication lock %s', [FPath]);
    FpLseek(FDescriptor, 0, SEEK_SET);
    PIDLine := AnsiString(IntToStr(GetProcessID)) + AnsiChar(#10);
    if Length(PIDLine) > 0 then
      FpWrite(FDescriptor, PIDLine[1], Length(PIDLine));
    {$ENDIF}
    {$IFDEF MSWINDOWS}
    FHandle := Windows.CreateFileW(PWideChar(WindowsExtendedPath(FPath)),
      Windows.GENERIC_READ or Windows.GENERIC_WRITE,
      Windows.FILE_SHARE_READ or Windows.FILE_SHARE_WRITE, nil,
      Windows.OPEN_ALWAYS, Windows.FILE_ATTRIBUTE_NORMAL, 0);
    if FHandle = THandle(Windows.INVALID_HANDLE_VALUE) then
      raise EConcurrencyError.CreateFmt(
        'could not open build publication lock %s', [FPath]);
    repeat
      FillChar(Overlapped, SizeOf(Overlapped), 0);
      Acquired := Windows.LockFileEx(FHandle,
        LOCKFILE_EXCLUSIVE_LOCK_LWPT or LOCKFILE_FAIL_IMMEDIATELY_LWPT,
        0, 1, 0, Overlapped);
      if Acquired then Break;
      Sleep(10);
    until MilliSecondsBetween(Now, Started) >=
      PUBLICATION_LOCK_WAIT_MILLISECONDS;
    if not Acquired then
      raise EConcurrencyError.CreateFmt(
        'timed out waiting for build publication lock %s', [FPath]);
    Windows.SetFilePointer(FHandle, 0, nil, Windows.FILE_BEGIN);
    PIDLine := AnsiString(IntToStr(GetProcessID)) + AnsiChar(#10);
    if Length(PIDLine) > 0 then
      Windows.WriteFile(FHandle, PIDLine[1], Length(PIDLine), Written, nil);
    Windows.SetEndOfFile(FHandle);
    {$ENDIF}
  except
    {$IFDEF UNIX}
    if FDescriptor >= 0 then
    begin
      FpClose(FDescriptor);
      FDescriptor := -1;
    end;
    {$ENDIF}
    {$IFDEF MSWINDOWS}
    if FHandle <> THandle(Windows.INVALID_HANDLE_VALUE) then
    begin
      Windows.CloseHandle(FHandle);
      FHandle := THandle(Windows.INVALID_HANDLE_VALUE);
    end;
    {$ENDIF}
    LeaveCriticalSection(
      PublicationCriticalSections[FCriticalSectionIndex]);
    FCriticalSectionEntered := False;
    raise;
  end;
end;

destructor TLWPTPublicationLock.Destroy;
{$IFDEF UNIX}
var
  LockSpec: TLWPTFlock;
{$ENDIF}
{$IFDEF MSWINDOWS}
var
  Overlapped: TOverlapped;
{$ENDIF}
begin
  {$IFDEF UNIX}
  if FDescriptor >= 0 then
  begin
    FillChar(LockSpec, SizeOf(LockSpec), 0);
    LockSpec.l_type := F_UNLCK_LWPT;
    LockSpec.l_whence := SEEK_SET;
    LockSpec.l_start := 0;
    LockSpec.l_len := 1;
    FpFcntl(FDescriptor, F_SetLk, LockSpec);
    FpClose(FDescriptor);
    FDescriptor := -1;
  end;
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  if FHandle <> THandle(Windows.INVALID_HANDLE_VALUE) then
  begin
    FillChar(Overlapped, SizeOf(Overlapped), 0);
    Windows.UnlockFileEx(FHandle, 0, 1, 0, Overlapped);
    Windows.CloseHandle(FHandle);
    FHandle := THandle(Windows.INVALID_HANDLE_VALUE);
  end;
  {$ENDIF}
  if FCriticalSectionEntered then
  begin
    LeaveCriticalSection(
      PublicationCriticalSections[FCriticalSectionIndex]);
    FCriticalSectionEntered := False;
  end;
  inherited Destroy;
end;

function BuildSessionProjectIdentity(const AProjectRoot: string): string;
var
  IdentityPath, PhysicalIdentity: string;
begin
  IdentityPath := ExcludeTrailingPathDelimiter(ExpandFileName(AProjectRoot));
  PhysicalIdentity := DirectoryIdentity(IdentityPath);
  if PhysicalIdentity <> '' then
    Exit(TextHash('build-session-project-physical-v1'#10
      + PhysicalIdentity));
  {$IFDEF MSWINDOWS}
  IdentityPath := LowerCase(IdentityPath);
  {$ENDIF}
  Result := TextHash('build-session-project-path-v1'#10 + IdentityPath);
end;

function BuildSessionLedgerPath(const AProjectRoot: string): string;
begin
  Result := RootedPath(AProjectRoot, BUILD_SESSION_ROOT_LEDGER);
end;

function BuildSessionLedgerLockPath(const AProjectRoot: string): string;
begin
  Result := RootedPath(AProjectRoot, BUILD_SESSIONS_DIR)
    + '/locks/session-roots.lock';
end;

function AcquireBuildCoordinationLock(const AProjectRoot: string): TObject;
begin
  Result := TLWPTPublicationLock.Create(
    BuildSessionLedgerLockPath(AProjectRoot));
end;

function BuildSessionsProjectRoot(const AProjectRoot,
  AConfiguredRoot: string): string;
var
  Identity: string;
begin
  if SamePath(AConfiguredRoot,
    RootedPath(AProjectRoot, BUILD_SESSIONS_DIR)) then
    Exit(ExpandFileName(AConfiguredRoot));
  Identity := BuildSessionProjectIdentity(AProjectRoot);
  Result := IncludeTrailingPathDelimiter(ExpandFileName(AConfiguredRoot))
    + 'p-' + Copy(Identity, 8, 16);
end;

function SessionRootIdentityMatches(const ARoot,
  AProjectIdentity: string): Boolean;
var
  IdentityPath, RootIdentity: string;
  Lines: TStringList;
begin
  Result := False;
  if ExtractFileName(ExcludeTrailingPathDelimiter(ARoot))
    <> 'p-' + Copy(AProjectIdentity, 8, 16) then Exit;
  if IsDirSymlinkOrJunction(ARoot) then Exit;
  RootIdentity := DirectoryIdentity(ARoot);
  if RootIdentity = '' then Exit;
  IdentityPath := IncludeTrailingPathDelimiter(ARoot)
    + SESSION_ROOT_IDENTITY_FILE;
  if not LongPathFileExists(IdentityPath) then Exit;
  if IsDirSymlinkOrJunction(IdentityPath) then Exit;
  Lines := TStringList.Create;
  try
    LoadProtectedStrings(Lines, IdentityPath);
    Result := (Lines.Count = 3)
      and (Lines[0] = 'schema='
        + IntToStr(SESSION_ROOT_IDENTITY_SCHEMA_VERSION))
      and (Lines[1] = 'project=' + AProjectIdentity)
      and (Lines[2] = 'root=' + RootIdentity);
  finally
    Lines.Free;
  end;
end;

procedure EnsureSessionRootIdentity(const ARoot,
  AProjectIdentity: string);
var
  IdentityPath, RootIdentity: string;
  Lines: TStringList;
begin
  if (Pos(#10, ARoot) > 0) or (Pos(#13, ARoot) > 0) then
    raise ELWPTError.Create('build session root contains a line break');
  if IsDirSymlinkOrJunction(ARoot) then
    raise ELWPTError.CreateFmt(
      'build session root must not be a link: %s', [ARoot]);
  if not EnsureDirectory(ARoot) then
    raise ELWPTError.CreateFmt(
      'could not create build sessions directory %s', [ARoot]);
  IdentityPath := IncludeTrailingPathDelimiter(ARoot)
    + SESSION_ROOT_IDENTITY_FILE;
  if IsDirSymlinkOrJunction(IdentityPath) then
    raise ELWPTError.CreateFmt(
      'build session root identity must not be a link: %s',
      [IdentityPath]);
  RootIdentity := DirectoryIdentity(ARoot);
  if RootIdentity = '' then
    raise ELWPTError.CreateFmt(
      'could not identify build sessions directory %s', [ARoot]);
  if not LongPathFileExists(IdentityPath) then
  begin
    Lines := TStringList.Create;
    try
      Lines.Add('schema=' + IntToStr(SESSION_ROOT_IDENTITY_SCHEMA_VERSION));
      Lines.Add('project=' + AProjectIdentity);
      Lines.Add('root=' + RootIdentity);
      AtomicWriteText(IdentityPath, ARoot, Lines);
    finally
      Lines.Free;
    end;
  end;
  if not SessionRootIdentityMatches(ARoot, AProjectIdentity) then
    raise ELWPTError.CreateFmt(
      'build session root ownership does not match this project: %s',
      [ARoot]);
end;

procedure LoadSessionRootLedger(const AProjectRoot,
  AProjectIdentity: string; ARoots: TStrings);
var
  LedgerPath, Prefix: string;
  Lines: TStringList;
  i: Integer;
begin
  ARoots.Clear;
  LedgerPath := BuildSessionLedgerPath(AProjectRoot);
  if not LongPathFileExists(LedgerPath) then Exit;
  Lines := TStringList.Create;
  try
    LoadProtectedStrings(Lines, LedgerPath);
    if (Lines.Count < 2)
      or (Lines[0] <> 'schema='
        + IntToStr(SESSION_ROOT_LEDGER_SCHEMA_VERSION))
      or (Lines[1] <> 'project=' + AProjectIdentity) then
      raise ELWPTError.CreateFmt(
        'build session root ledger is invalid: %s', [LedgerPath]);
    Prefix := 'root=';
    for i := 2 to Lines.Count - 1 do
    begin
      if Copy(Lines[i], 1, Length(Prefix)) <> Prefix then
        raise ELWPTError.CreateFmt(
          'build session root ledger is invalid: %s', [LedgerPath]);
      if Copy(Lines[i], Length(Prefix) + 1, MaxInt) = '' then
        raise ELWPTError.CreateFmt(
          'build session root ledger is invalid: %s', [LedgerPath]);
      ARoots.Add(Copy(Lines[i], Length(Prefix) + 1, MaxInt));
    end;
  finally
    Lines.Free;
  end;
end;

procedure SaveSessionRootLedger(const AProjectRoot,
  AProjectIdentity: string; ARoots: TStrings);
var
  Lines: TStringList;
  i: Integer;
begin
  Lines := TStringList.Create;
  try
    Lines.Add('schema=' + IntToStr(SESSION_ROOT_LEDGER_SCHEMA_VERSION));
    Lines.Add('project=' + AProjectIdentity);
    for i := 0 to ARoots.Count - 1 do
      Lines.Add('root=' + ARoots[i]);
    AtomicWriteText(BuildSessionLedgerPath(AProjectRoot),
      RootedPath(AProjectRoot, TMP_DIR), Lines);
  finally
    Lines.Free;
  end;
end;

procedure RegisterSessionRoot(const AProjectRoot,
  ASessionsRoot: string);
var
  LedgerLock: TLWPTPublicationLock;
  Roots: TStringList;
  ProjectIdentity: string;
begin
  ProjectIdentity := BuildSessionProjectIdentity(AProjectRoot);
  LedgerLock := TLWPTPublicationLock.Create(
    BuildSessionLedgerLockPath(AProjectRoot));
  Roots := TStringList.Create;
  try
    EnsureSessionRootIdentity(ASessionsRoot, ProjectIdentity);
    LoadSessionRootLedger(AProjectRoot, ProjectIdentity, Roots);
    Roots.CaseSensitive := {$IFDEF MSWINDOWS}False{$ELSE}True{$ENDIF};
    if Roots.IndexOf(ASessionsRoot) < 0 then
    begin
      Roots.Add(ASessionsRoot);
      Roots.Sort;
      SaveSessionRootLedger(AProjectRoot, ProjectIdentity, Roots);
    end;
  finally
    Roots.Free;
    LedgerLock.Free;
  end;
end;

{ Publication lock files are stable names for advisory byte-range locks.
  The operating system releases ownership when the handle closes or the
  process exits; the files themselves remain and are safe to reuse. }

function EncodeBase36(AValue: QWord): string;
const
  DIGITS = '0123456789abcdefghijklmnopqrstuvwxyz';
begin
  if AValue = 0 then Exit('0');
  Result := '';
  while AValue > 0 do
  begin
    Result := DIGITS[(AValue mod 36) + 1] + Result;
    AValue := AValue div 36;
  end;
end;

function SessionTimestamp: string;
begin
  { Base36 milliseconds keep the slug short: session directory names are a
    fixed prefix of every compiler-written staging path, and each saved
    character is headroom under COMPILER_PATH_LIMIT. }
  Result := EncodeBase36(QWord(Round(Now * MSecsPerDay)));
end;

function SessionOwnerGuardPath(const ASessionsRoot,
  ASessionID: string): string;
begin
  Result := IncludeTrailingPathDelimiter(ASessionsRoot)
    + 'locks/owners/' + ASessionID + '.lock';
end;

constructor TLWPTBuildSession.Create(const AProjectRoot: string);
begin
  Create(AProjectRoot, RootedPath(AProjectRoot, BUILD_SESSIONS_DIR));
end;

constructor TLWPTBuildSession.Create(const AProjectRoot,
  ASessionsRoot: string);
var
  BaseRoot, PendingRoot: string;
  CollisionCounter: Integer;
  InvocationCounter: QWord;
begin
  inherited Create;
  FProjectRoot := ExpandFileName(AProjectRoot);
  FSessionOwnerGuardPath := '';
  FSessionOwnerGuard := nil;
  BaseRoot := ExpandFileName(ASessionsRoot);
  FDefaultSessionsRoot := SamePath(BaseRoot,
    RootedPath(FProjectRoot, BUILD_SESSIONS_DIR));
  if not FDefaultSessionsRoot then
  begin
    BaseRoot := BuildSessionsProjectRoot(FProjectRoot, BaseRoot);
    RegisterSessionRoot(FProjectRoot, BaseRoot);
  end;
  FSessionsRoot := BaseRoot;
  if not EnsureDirectory(BaseRoot) then
    raise ELWPTError.CreateFmt(
      'could not create build sessions directory %s', [BaseRoot]);
  Inc(NextSessionCounter);
  InvocationCounter := NextSessionCounter;
  CollisionCounter := 0;
  repeat
    { Compact form: the session slug prefixes every compiler staging path,
      so base36 PID + timestamp keep it well inside COMPILER_PATH_LIMIT
      even for deeply nested project roots. }
    FSessionID := 's-' + EncodeBase36(QWord(GetProcessID)) + '-'
      + SessionTimestamp + '-' + UIntToStr(InvocationCounter) + '-'
      + IntToStr(CollisionCounter);
    FSessionRoot := IncludeTrailingPathDelimiter(BaseRoot) + FSessionID;
    PendingRoot := IncludeTrailingPathDelimiter(BaseRoot) + '.creating-'
      + FSessionID;
    Inc(CollisionCounter);
  until (not LongPathDirectoryExists(FSessionRoot))
    and (not LongPathDirectoryExists(PendingRoot));
  if not EnsureDirectory(PendingRoot) then
    raise ELWPTError.CreateFmt(
      'could not create build session directory %s', [PendingRoot]);
  FFinished := False;
  FSessionRoot := PendingRoot;
  FSessionOwnerGuardPath := SessionOwnerGuardPath(BaseRoot, FSessionID);
  try
    FSessionOwnerGuard := TLWPTSessionOwnerGuard.Create(
      FSessionOwnerGuardPath);
    WriteState('active');
    if not LongPathRenameFile(PendingRoot,
      IncludeTrailingPathDelimiter(BaseRoot) + FSessionID) then
      raise ELWPTError.CreateFmt(
        'could not publish build session directory %s', [FSessionID]);
    FSessionRoot := IncludeTrailingPathDelimiter(BaseRoot) + FSessionID;
  except
    FreeAndNil(FSessionOwnerGuard);
    if LongPathFileExists(FSessionOwnerGuardPath) then
      LongPathDeleteFile(FSessionOwnerGuardPath);
    if LongPathDirectoryExists(PendingRoot) then WipeDir(PendingRoot);
    if LongPathDirectoryExists(IncludeTrailingPathDelimiter(BaseRoot)
      + FSessionID) then
      WipeDir(IncludeTrailingPathDelimiter(BaseRoot) + FSessionID);
    raise;
  end;
end;

destructor TLWPTBuildSession.Destroy;
begin
  if not FFinished then
    try
      Finish(False, 'process exited without completing the session');
    except
      { Destruction must not hide the command error that caused the
        session to be retained. Repair can still reclaim the directory. }
    end;
  FSessionOwnerGuard.Free;
  inherited Destroy;
end;

procedure TLWPTBuildSession.WriteState(const AState: string);
var
  Lines: TStringList;
begin
  Lines := TStringList.Create;
  try
    Lines.Add(IntToStr(GetProcessID));
    Lines.Add(AState);
    Lines.Add(IntToStr(BUILD_SESSION_SCHEMA_VERSION));
    AtomicWriteText(FSessionRoot + '/session.state', FSessionRoot, Lines);
  finally
    Lines.Free;
  end;
end;

function TLWPTBuildSession.JobRoot(const AName: string): string;
begin
  Result := FSessionRoot + '/jobs/' + BuildSessionPathKey(AName);
  LongPathForceDirectories(Result);
end;

function TLWPTBuildSession.JobLogPath(const AName: string): string;
begin
  Result := FSessionRoot + ObservabilityLogsDirectory
    + BuildSessionPathKey(AName) + ObservabilityLogExtension;
end;

function TLWPTBuildSession.JobLogReference(const AName: string): string;
begin
  Result := SessionReference + ObservabilityLogsDirectory
    + BuildSessionPathKey(AName) + ObservabilityLogExtension;
end;

function TLWPTBuildSession.SessionReference: string;
begin
  if FDefaultSessionsRoot then
    Result := BUILD_SESSIONS_DIR + '/' + FSessionID
  else
    Result := FSessionRoot;
end;

procedure TLWPTBuildSession.WriteJobLog(const AName, AOutput: string);
var
  LogPath: string;
  Bytes: TBytes;
begin
  LogPath := JobLogPath(AName);
  if not LongPathForceDirectories(ExtractFileDir(LogPath)) then
    raise ELWPTError.CreateFmt('could not create session log directory %s',
      [ExtractFileDir(LogPath)]);
  { Committed-path write goes through the atomic helper (staged under the
    session root, atomic rename) — never a raw TFileStream — so an
    interrupted write cannot leave a truncated log behind JobLogReference.
    Byte-exact copy: the captured output must not be re-encoded. }
  SetLength(Bytes, Length(AOutput));
  if Length(AOutput) > 0 then
    Move(AOutput[1], Bytes[0], Length(AOutput));
  AtomicWriteBytes(LogPath, FSessionRoot, Bytes);
end;

procedure TLWPTBuildSession.Finish(ASuccess: Boolean; const ADetail: string);
var
  HasLogs: Boolean;
  Lines: TStringList;
begin
  if FFinished then Exit;
  if ASuccess then
  begin
    { The guard lives beside session directories, so it remains observable
      while private compiler staging is removed on every platform.
      Stable job logs remain until lwpt repair reclaims the completed session. }
    HasLogs := LongPathDirectoryExists(FSessionRoot
      + ObservabilityLogsDirectory);
    WriteState('completing');
    if HasLogs then
    begin
      if LongPathDirectoryExists(FSessionRoot + '/jobs') then
        WipeDir(FSessionRoot + '/jobs');
      WriteState('completed');
    end
    else
      WipeDir(FSessionRoot);
    FreeAndNil(FSessionOwnerGuard);
    if LongPathFileExists(FSessionOwnerGuardPath)
      and (not LongPathDeleteFile(FSessionOwnerGuardPath)) then
      raise ELWPTError.CreateFmt(
        'could not remove build session owner guard %s',
        [FSessionOwnerGuardPath]);
    FFinished := True;
    Exit;
  end;
  if ADetail <> '' then
  begin
    Lines := TStringList.Create;
    try
      Lines.Add(ADetail);
      AtomicWriteText(FSessionRoot + '/failure.txt', FSessionRoot, Lines);
    finally
      Lines.Free;
    end;
  end;
  WriteState('failed');
  FreeAndNil(FSessionOwnerGuard);
  FFinished := True;
end;

function BuildPublicationLockPath(const ASessionsRoot, AOutput: string): string;
var
  OutputIdentity, ParentPath, ParentIdentity, OutputName: string;
begin
  OutputIdentity := ExpandFileName(AOutput);
  ParentPath := ExtractFileDir(OutputIdentity);
  if (ParentPath <> '') and (not EnsureDirectory(ParentPath)) then
    raise ELWPTError.CreateFmt(
      'could not create build output directory %s', [ParentPath]);
  ParentIdentity := DirectoryIdentity(ParentPath);
  if ParentIdentity = '' then ParentIdentity := ExpandFileName(ParentPath);
  OutputName := ExtractFileName(OutputIdentity);
  {$IFDEF MSWINDOWS}
  OutputName := LowerCase(OutputName);
  {$ENDIF}
  {$IFDEF DARWIN}
  OutputName := LowerCase(OutputName);
  {$ENDIF}
  Result := ExcludeTrailingPathDelimiter(ASessionsRoot)
    + '/locks/' + Copy(TextHash(ParentIdentity + '/' + OutputName),
      8, 64) + '.lock';
end;

function PublishBuildArtifact(const AProjectRoot, ACandidatePath,
  ADestinationPath, AExpectedFingerprint, AManifestPath, ACfgPath,
  ALockPath, AModulesPath: string;
  const ARequest: TLWPTBuildPublicationRequest;
  const ASessionsRoot: string):
  TLWPTBuildPublicationResult;
var
  CoordinatorLock, Lock: TLWPTPublicationLock;
  CurrentFingerprint, PublicationSessionsRoot: string;
  Destination: string;
begin
  Destination := RootedPath(AProjectRoot, ADestinationPath);
  PublicationSessionsRoot := ASessionsRoot;
  if PublicationSessionsRoot = '' then
    PublicationSessionsRoot := RootedPath(AProjectRoot, BUILD_SESSIONS_DIR);
  { Session-root selection can change while builds overlap. The project-local
    ledger lock gives every root generation one publication rendezvous; the
    output-specific lock remains in the resolved namespace for stable
    same-root coordination. }
  CoordinatorLock := TLWPTPublicationLock.Create(
    BuildSessionLedgerLockPath(AProjectRoot));
  try
    Lock := TLWPTPublicationLock.Create(
      BuildPublicationLockPath(PublicationSessionsRoot, Destination));
    try
      try
        CurrentFingerprint := CaptureBuildPublicationFingerprint(
          AProjectRoot, AManifestPath, ACfgPath, ALockPath, AModulesPath,
          ARequest);
      except
        on ELWPTParsedManifestChanged do Exit(bprStale);
      end;
      if CurrentFingerprint <> AExpectedFingerprint then
        Exit(bprStale);
      { The destination may be the running LWPT (self-hosted rebuild) or
        another live executable; see AtomicReplaceExecutable. Retired
        images are swept only below the project root, never through a
        redirected output directory. }
      if not AtomicReplaceExecutable(ACandidatePath, Destination,
        AProjectRoot) then
        raise ELWPTError.CreateFmt(
          'could not atomically publish "%s" to "%s"; the completed '
          + 'candidate remains private', [ACandidatePath, Destination]);
      Result := bprPublished;
    finally
      Lock.Free;
    end;
  finally
    CoordinatorLock.Free;
  end;
end;

procedure RepairBuildSessions(const AProjectRoot, ATemporaryRoot: string;
  out ARemoved, ARetained: Integer;
  out ATemporaryRootCleaned: Boolean);
var
  Root, SessionPath, SessionID, StatePath, AgePath, OwnerPath: string;
  PID: LongInt;
  State: string;
  OwnerHeld: Boolean;
  LedgerLock: TLWPTPublicationLock;
  Roots: TStringList;
  ProjectIdentity: string;
  RootRequiresIdentity: Boolean;
  i: Integer;

  procedure ReclaimSessionPattern(const APattern: string);
  var
    Entries: TLWPTDirectoryEntries;
    EntryIndex: Integer;
  begin
    if RootRequiresIdentity
      and not SessionRootIdentityMatches(Root, ProjectIdentity) then Exit;
    Entries := ListDirectoryEntries(Root, APattern, faAnyFile);
    for EntryIndex := 0 to High(Entries) do
    begin
      if (Entries[EntryIndex].Attr and faDirectory) = 0 then Continue;
      SessionPath := Root + '/' + Entries[EntryIndex].Name;
      SessionID := Entries[EntryIndex].Name;
      if Copy(SessionID, 1, Length('.creating-')) = '.creating-' then
        Delete(SessionID, 1, Length('.creating-'));
      OwnerPath := SessionOwnerGuardPath(Root, SessionID);
      StatePath := SessionPath + '/session.state';
      PID := ReadPID(StatePath);
      State := ReadSessionState(StatePath);
      OwnerHeld := SessionOwnerGuardHeld(OwnerPath);
      if LongPathFileExists(StatePath) then AgePath := StatePath
      else AgePath := SessionPath;
      if OwnerHeld then
        Inc(ARetained)
      else if (State <> 'failed')
        and (not IncompleteStateIsAbandoned(AgePath))
        and ((State = '') or ProcessIsAlive(PID)) then
        Inc(ARetained)
      else
      begin
        if RootRequiresIdentity
          and not SessionRootIdentityMatches(Root, ProjectIdentity) then
          Exit;
        WipeDir(SessionPath);
        if LongPathFileExists(OwnerPath) then LongPathDeleteFile(OwnerPath);
        Inc(ARemoved);
      end;
    end;
  end;

  procedure ReclaimRoot(const ARoot: string;
    ARequireIdentity: Boolean);
  begin
    Root := ARoot;
    RootRequiresIdentity := ARequireIdentity;
    if not LongPathDirectoryExists(Root) then Exit;
    if RootRequiresIdentity
      and not SessionRootIdentityMatches(Root, ProjectIdentity) then Exit;
    ReclaimSessionPattern('s-*');
    { A process can crash between creating and publishing its visible
      session directory. The hidden creating form has the same state
      record, so repair can retain its live owner or reclaim the orphan. }
    ReclaimSessionPattern('.creating-s-*');
    { Sessions left behind by binaries that used the long pre-compaction
      slug ('session-<pid>-<datetime>-...') remain reclaimable. }
    ReclaimSessionPattern('session-*');
    ReclaimSessionPattern('.creating-session-*');
  end;
begin
  ARemoved := 0;
  ARetained := 0;
  ATemporaryRootCleaned := False;
  ProjectIdentity := BuildSessionProjectIdentity(AProjectRoot);
  LedgerLock := TLWPTPublicationLock.Create(
    BuildSessionLedgerLockPath(AProjectRoot));
  Roots := TStringList.Create;
  try
    { Ledger publication stages through the project temporary root while
      holding this same lock. Serialize repair's residue sweep with that
      writer so a live atomic ledger update cannot lose its staged file. }
    if (ATemporaryRoot <> '') and LongPathDirectoryExists(ATemporaryRoot) then
    begin
      WipeDir(ATemporaryRoot);
      ATemporaryRootCleaned := True;
    end;
    ReclaimRoot(RootedPath(AProjectRoot, BUILD_SESSIONS_DIR), False);
    LoadSessionRootLedger(AProjectRoot, ProjectIdentity, Roots);
    for i := 0 to Roots.Count - 1 do
      if SessionRootIdentityMatches(Roots[i], ProjectIdentity) then
        ReclaimRoot(Roots[i], True);
  finally
    Roots.Free;
    LedgerLock.Free;
  end;
end;

procedure RepairBuildSessions(const AProjectRoot: string;
  out ARemoved, ARetained: Integer);
var
  TemporaryRootCleaned: Boolean;
begin
  RepairBuildSessions(AProjectRoot, '', ARemoved, ARetained,
    TemporaryRootCleaned);
end;

var
  CriticalSectionIndex: Integer;

initialization
  for CriticalSectionIndex := Low(PublicationCriticalSections)
    to High(PublicationCriticalSections) do
    InitCriticalSection(PublicationCriticalSections[CriticalSectionIndex]);

finalization
  for CriticalSectionIndex := Low(PublicationCriticalSections)
    to High(PublicationCriticalSections) do
    DoneCriticalSection(PublicationCriticalSections[CriticalSectionIndex]);

end.
