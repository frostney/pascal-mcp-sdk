program RegistryMirror.E2E.Test;

{$mode delphi}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  BaseUnix,
  {$ENDIF}
  Classes,
  Process,
  SysUtils,

  HTTPClient,
  TestingPascalLibrary,
  TOML,

  Tests.LwptSubprocess,
  Tests.RegistryOrigin,
  Tests.RegistryProcess,
  Tests.RegistryServer,
  Tests.Scratch;

type
  TRegistryMirrorE2E = class(TTestSuite)
  private
    FScratch, FMirrorRoot, FMirrorURL: string;
    FOrigin: TRegistryOriginFixture;
    FMirrorServer: TProcess;
    function InitMirror(const AKeyID, APublicKey: string; const AUpstream: string = ''): TLwptResult;
    function Sync: TLwptResult;
    procedure RequireSuccess(const ALabel: string; const ARun: TLwptResult);
  protected
    procedure BeforeEach; override;
    procedure AfterEach; override;
  public
    procedure SetupTests; override;
    procedure BootstrapOutageAndRestart;
    procedure MirrorClientVerifiesOriginDuringOutage;
    procedure IncrementalSyncReusesVerifiedObjects;
    procedure FailedSyncPreservesAcceptedPointer;
    procedure MissingAndWrongPinsFailClosed;
    procedure UpstreamKeyBytesArePreserved;
    procedure ForcedShutdownIsBounded;
    procedure SignedRotationsSurviveOutage;
    procedure ReadinessPreservesCLIDiagnostic;
    procedure BootstrapConsumesMultipleRotationPages;
    procedure ByteBudgetsAreMirrorInitOptions;
    procedure ReadinessRequiresServedCheckpoint;
    procedure OriginStartRecoversFromPortCollision;
    procedure MirrorStartProvesListenerOwnership;
  end;

{ Shares the file with a live origin's atomic renames; see ReadBinaryFile. }
function ReadBytes(const APath: string): TBytes;
begin
  Result := BytesOf(ReadBinaryFile(APath));
end;

function Text(const ABytes: TBytes): string;
begin
  Result := '';
  if Length(ABytes) > 0 then SetString(Result, PAnsiChar(@ABytes[0]), Length(ABytes));
end;

function Field(const ADocument: string; const AName: string): string;
var
  Parser: TTOMLParser;
  Root, Node: TTOMLNode;
begin
  Parser := TTOMLParser.Create;
  try
    Root := Parser.ParseDocument(ADocument);
    try
      if not Root.Children.TryGetValue(AName, Node) then
        raise Exception.Create('missing registry fixture field: ' + AName);
      Result := Node.ScalarText;
    finally
      Root.Free;
    end;
  finally
    Parser.Free;
  end;
end;

function HTTPStatus(const AURL: string): Integer;
var
  Options: THTTPRequestOptions;
begin
  Options := DefaultHTTPRequestOptions;
  Options.RequestTimeoutMilliseconds := 1000;
  Result := HTTPGet(AURL, nil, Options).StatusCode;
end;

procedure WriteBytes(const APath: string; const ABytes: TBytes);
var
  Stream: TFileStream;
begin
  Stream := TFileStream.Create(APath, fmCreate);
  try
    if Length(ABytes) > 0 then Stream.WriteBuffer(ABytes[0], Length(ABytes));
  finally
    Stream.Free;
  end;
end;

procedure TRegistryMirrorE2E.BeforeEach;
var
  Port: Word;
begin
  FScratch := CreateScratchRoot('registry-mirror-e2e');
  FOrigin := TRegistryOriginFixture.Create(FScratch + '/origin');
  FMirrorRoot := FScratch + '/mirror';
  Port := FindAvailableRegistryTestPort;
  FMirrorURL := 'http://localhost:' + IntToStr(Port) + '/mirror';
end;

procedure TRegistryMirrorE2E.AfterEach;
begin
  StopRegistryCLI(FMirrorServer);
  FreeAndNil(FOrigin);
  RecursiveDelete(FScratch);
end;

procedure TRegistryMirrorE2E.RequireSuccess(const ALabel: string; const ARun: TLwptResult);
begin
  DumpRunFailure(ALabel, ARun, 0);
  Expect<Integer>(ARun.ExitCode).ToBe(0);
  if ARun.ExitCode <> 0 then raise Exception.Create(ALabel + ': ' + ARun.Stderr);
end;

function TRegistryMirrorE2E.InitMirror(const AKeyID, APublicKey: string; const AUpstream: string): TLwptResult;
var
  Port, Upstream: string;
begin
  Upstream := AUpstream;
  if Upstream = '' then Upstream := FOrigin.BaseURL;
  Port := Copy(FMirrorURL, Length('http://localhost:') + 1, MaxInt);
  Port := Copy(Port, 1, Pos('/', Port) - 1);
  Result := RunLwpt(['registry', 'init', '--role', 'mirror', '--data-dir', FMirrorRoot,
    '--identity', FOrigin.Identity, '--base-url', FMirrorURL, '--port', Port,
    '--upstream', Upstream, '--key-id', AKeyID, '--public-key', APublicKey]);
end;

function TRegistryMirrorE2E.Sync: TLwptResult;
begin
  Result := RunLwpt(['registry', 'sync', '--data-dir', FMirrorRoot]);
end;

procedure TRegistryMirrorE2E.BootstrapOutageAndRestart;
var
  Archive: TBytes;
  Checkpoint, ArtifactURL: string;
  Run: TLwptResult;
begin
  Archive := BytesOf('archive' + #0 + 'binary');
  FOrigin.Publish('binary-package', '1.0.0', Archive);
  FOrigin.Start;
  RequireSuccess('mirror init', InitMirror(FOrigin.KeyID, FOrigin.PublicKey));
  Expect<Boolean>(FileExists(FMirrorRoot + '/keys/root.seed')).ToBe(False);
  RequireSuccess('bootstrap sync', Sync);
  Checkpoint := Text(RegistryHTTPBody(FOrigin.BaseURL + '/v1/checkpoints/latest.toml'));
  FMirrorServer := StartRegistryCLI(FMirrorRoot, FMirrorURL);
  FOrigin.Stop;
  Expect<string>(Text(RegistryHTTPBody(FMirrorURL + '/v1/checkpoints/latest.toml'))).ToBe(Checkpoint);
  ArtifactURL := FMirrorURL + '/v1/objects/sha256/' + Copy(RegistryArtifactHash(Archive), 8, 64);
  Expect<string>(Text(RegistryHTTPBody(ArtifactURL))).ToBe(Text(Archive));
  Run := RunLwpt(['registry', 'verify', '--data-dir', FMirrorRoot]);
  RequireSuccess('mirror verify during outage', Run);
  Expect<Boolean>(Pos('freshness = "fresh"', Run.Stdout) > 0).ToBe(True);
  Expect<Boolean>(Pos('last_successful_sync = "', Run.Stdout) > 0).ToBe(True);
  Expect<Boolean>(Pos(FOrigin.Identity, Run.Stdout) > 0).ToBe(True);
  StopRegistryCLI(FMirrorServer);
  FMirrorServer := StartRegistryCLI(FMirrorRoot, FMirrorURL);
  { Restart may relocate the mirror to a new port. }
  ArtifactURL := FMirrorURL + '/v1/objects/sha256/' + Copy(RegistryArtifactHash(Archive), 8, 64);
  Expect<string>(Text(RegistryHTTPBody(ArtifactURL))).ToBe(Text(Archive));
  Run := Sync;
  Expect<Integer>(Run.ExitCode).ToBe(1);
  Expect<string>(Text(RegistryHTTPBody(FMirrorURL + '/v1/checkpoints/latest.toml'))).ToBe(Checkpoint);
  Run := RunLwpt(['registry', 'verify', '--data-dir', FMirrorRoot]);
  RequireSuccess('verify records failed sync without losing fresh content', Run);
  Expect<Boolean>(Pos('registry_transport_failed', Run.Stdout) > 0).ToBe(True);
end;

procedure TRegistryMirrorE2E.MirrorClientVerifiesOriginDuringOutage;
var
  Replay: TRegistryTestServer;
  Routes: TRegistryHTTPRouteArray;
  Archive, Signature: TBytes;
  ClientRoot, ClientURL, ReplayURL, ArtifactHash, Checkpoint, SignatureText: string;
  Run: TLwptResult;
  Port: Word;
  Offset: Integer;

  function InitClient(const ARoot, AUpstream: string): TLwptResult;
  begin
    Result := RunLwpt(['registry', 'init', '--role', 'mirror', '--data-dir', ARoot,
      '--identity', FOrigin.Identity, '--base-url', ClientURL, '--port', IntToStr(Port),
      '--upstream', AUpstream, '--key-id', FOrigin.KeyID, '--public-key', FOrigin.PublicKey]);
  end;

  procedure Capture(const APath, AKind: string; const ARewrite: Boolean = False);
  var
    Body: TBytes;
  begin
    Body := RegistryHTTPBody(FMirrorURL + APath);
    if ARewrite then
      Body := BytesOf(StringReplace(Text(Body), FMirrorURL, ReplayURL, [rfReplaceAll]));
    SetLength(Routes, Length(Routes) + 1);
    Routes[High(Routes)] := RegistryRoute('/replay' + APath,
      'application/vnd.' + RegistryProgramName + '.registry-' + AKind + '+toml', Body);
  end;

begin
  Archive := BytesOf('origin-bound archive' + #0 + 'binary');
  ArtifactHash := RegistryArtifactHash(Archive);
  FOrigin.Publish('verified-package', '1.0.0', Archive);
  FOrigin.Start;
  RequireSuccess('first mirror init', InitMirror(FOrigin.KeyID, FOrigin.PublicKey));
  RequireSuccess('first mirror sync', Sync);
  FMirrorServer := StartRegistryCLI(FMirrorRoot, FMirrorURL);
  FOrigin.Stop;
  Checkpoint := Text(RegistryHTTPBody(FMirrorURL + '/v1/checkpoints/latest.toml'));
  Port := FindAvailableRegistryTestPort;
  ClientURL := 'http://localhost:' + IntToStr(Port) + '/client';
  ClientRoot := FScratch + '/client';
  RequireSuccess('second mirror pins origin while contacting first mirror', InitClient(ClientRoot, FMirrorURL));
  RequireSuccess('second mirror bootstrap during origin outage',
    RunLwpt(['registry', 'sync', '--data-dir', ClientRoot]));
  RequireSuccess('second mirror repeated sync during origin outage',
    RunLwpt(['registry', 'sync', '--data-dir', ClientRoot]));
  Run := RunLwpt(['registry', 'verify', '--data-dir', ClientRoot]);
  RequireSuccess('second mirror verifies retained origin proof and artifact', Run);
  Expect<Boolean>(Pos('origin = "' + FOrigin.Identity + '"', Run.Stdout) > 0).ToBe(True);
  Expect<string>(RegistryArtifactHash(ReadBytes(ClientRoot + '/objects/sha256/'
    + Copy(ArtifactHash, 8, 64)))).ToBe(ArtifactHash);
  Expect<string>(Field(Text(ReadBytes(ClientRoot + '/state/current.toml')), 'checkpoint_hash'))
    .ToBe(RegistryArtifactHash(BytesOf(Checkpoint)));

  Replay := TRegistryTestServer.Create(nil);
  try
    ReplayURL := 'http://localhost:' + IntToStr(Replay.Port) + '/replay';
    Capture('/.well-known/' + RegistryProgramName + '-registry', 'discovery', True);
    Capture('/v1/capabilities', 'capabilities', True);
    Capture('/v1/checkpoints/latest.toml', 'checkpoint');
    Capture('/v1/checkpoints/latest.sig.toml', 'signature');
    Signature := Routes[High(Routes)].Body;
    SignatureText := Text(Signature);
    Offset := Pos('signature = "hex:', SignatureText) + Length('signature = "hex:');
    Expect<Boolean>(Offset > Length('signature = "hex:')).ToBe(True);
    if SignatureText[Offset] = '0' then SignatureText[Offset] := '1'
    else SignatureText[Offset] := '0';
    Routes[High(Routes)].Body := BytesOf(SignatureText);
    Capture('/v1/keys/' + FOrigin.KeyID + '.toml', 'key');
    Replay.SetRoutes(Routes);
    Replay.Start;
    StopRegistryCLI(FMirrorServer);
    ClientRoot := FScratch + '/rejected-client';
    RequireSuccess('tampered replay client retains same origin pin', InitClient(ClientRoot, ReplayURL));
    Run := RunLwpt(['registry', 'sync', '--data-dir', ClientRoot]);
    Expect<Integer>(Run.ExitCode).ToBe(1);
    Expect<Boolean>(Pos('signature_invalid', Run.Stderr + Run.Stdout) > 0).ToBe(True);
    Expect<Boolean>(FileExists(ClientRoot + '/state/current.toml')).ToBe(False);
  finally
    Replay.Free;
  end;
end;

procedure TRegistryMirrorE2E.IncrementalSyncReusesVerifiedObjects;
var
  Archive: TBytes;
  ObjectPath: string;
begin
  Archive := BytesOf('first package');
  FOrigin.Publish('first-package', '1.0.0', Archive);
  FOrigin.Start;
  RequireSuccess('mirror init', InitMirror(FOrigin.KeyID, FOrigin.PublicKey));
  RequireSuccess('first sync', Sync);
  ObjectPath := '/objects/sha256/' + Copy(RegistryArtifactHash(Archive), 8, 64);
  Expect<Boolean>(DeleteFile(FOrigin.Root + ObjectPath)).ToBe(True);
  RequireSuccess('idempotent sync does not refetch verified object', Sync);
  FOrigin.Publish('second-package', '1.0.0', BytesOf('second package'));
  RequireSuccess('incremental sync reuses old verified object', Sync);
  RequireSuccess('verify incrementally mirrored artifacts',
    RunLwpt(['registry', 'verify', '--data-dir', FMirrorRoot]));
  Expect<string>(Text(ReadBytes(FMirrorRoot + ObjectPath))).ToBe(Text(Archive));
end;

procedure TRegistryMirrorE2E.FailedSyncPreservesAcceptedPointer;
var
  Archive: TBytes;
  PointerBefore, ObjectPath, SiblingPath, Checkpoint, Candidate, CandidateHash,
    CandidateSnapshot, PreviousSnapshot, CandidatePrefix: string;
  Run: TLwptResult;
begin
  FOrigin.Publish('first-package', '1.0.0', BytesOf('first'));
  FOrigin.Start;
  RequireSuccess('mirror init', InitMirror(FOrigin.KeyID, FOrigin.PublicKey));
  RequireSuccess('first sync', Sync);
  PointerBefore := Text(ReadBytes(FMirrorRoot + '/state/current.toml'));
  FMirrorServer := StartRegistryCLI(FMirrorRoot, FMirrorURL);
  Checkpoint := Text(RegistryHTTPBody(FMirrorURL + '/v1/checkpoints/latest.toml'));
  PreviousSnapshot := Field(Checkpoint, 'snapshot');
  Archive := BytesOf('second');
  FOrigin.Publish('second-package', '1.0.0', Archive);
  FOrigin.Publish('verified-sibling', '1.0.0', BytesOf('verified sibling'));
  SiblingPath := '/objects/sha256/' + Copy(RegistryArtifactHash(BytesOf('verified sibling')), 8, 64);
  Candidate := Text(RegistryHTTPBody(FOrigin.BaseURL + '/v1/checkpoints/latest.toml'));
  CandidateSnapshot := Field(Candidate, 'snapshot');
  CandidateHash := RegistryArtifactHash(BytesOf(Candidate));
  CandidatePrefix := '/checkpoints/renewals/sha256/' + Copy(CandidateHash, 8, 64);
  { A crash can leave these exact staged files without activating the pointer. }
  WriteBytes(FMirrorRoot + CandidatePrefix + '.toml', BytesOf(Candidate));
  WriteBytes(FMirrorRoot + CandidatePrefix + '.sig.toml',
    RegistryHTTPBody(FOrigin.BaseURL + '/v1/checkpoints/latest.sig.toml'));
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1' + CandidatePrefix + '.toml')).ToBe(404);
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1' + CandidatePrefix + '.sig.toml')).ToBe(404);
  ObjectPath := FOrigin.Root + '/objects/sha256/' + Copy(RegistryArtifactHash(Archive), 8, 64);
  WriteBytes(ObjectPath, BytesOf('tamper'));
  Run := Sync;
  Expect<Integer>(Run.ExitCode).ToBe(1);
  Expect<string>(Text(ReadBytes(FMirrorRoot + '/state/current.toml'))).ToBe(PointerBefore);
  Expect<string>(Text(ReadBytes(FMirrorRoot + SiblingPath))).ToBe('verified sibling');
  Expect<Boolean>(DeleteFile(FOrigin.Root + SiblingPath)).ToBe(True);
  Expect<string>(Text(RegistryHTTPBody(FMirrorURL + '/v1/checkpoints/latest.toml'))).ToBe(Checkpoint);
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1/snapshots/sha256/'
    + Copy(CandidateSnapshot, 8, 64) + '.toml')).ToBe(404);
  Expect<Boolean>(DeleteFile(ObjectPath)).ToBe(True);
  Run := Sync;
  Expect<Integer>(Run.ExitCode).ToBe(1);
  Expect<string>(Text(ReadBytes(FMirrorRoot + '/state/current.toml'))).ToBe(PointerBefore);
  WriteBytes(ObjectPath, Archive);
  RequireSuccess('retry after tampered and missing archive', Sync);
  Expect<Boolean>(Text(ReadBytes(FMirrorRoot + '/state/current.toml')) <> PointerBefore).ToBe(True);
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1/snapshots/sha256/'
    + Copy(CandidateSnapshot, 8, 64) + '.toml')).ToBe(200);
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1/snapshots/sha256/'
    + Copy(PreviousSnapshot, 8, 64) + '.toml')).ToBe(200);
end;

procedure TRegistryMirrorE2E.UpstreamKeyBytesArePreserved;
var
  KeyPath, HonestDocument, KeyDocument: string;
begin
  FOrigin.Publish('package', '1.0.0', BytesOf('archive'));
  KeyPath := '/keys/ed25519-' + Copy(FOrigin.KeyID, Length('ed25519:') + 1, 64) + '.toml';
  HonestDocument := Text(ReadBytes(FOrigin.Root + KeyPath));
  KeyDocument := StringReplace(HonestDocument,
    'valid_from_sequence = 1', 'valid_from_sequence = 2', []);
  WriteBytes(FOrigin.Root + KeyPath, BytesOf(KeyDocument));
  FOrigin.Start;
  RequireSuccess('mirror init pins key effective at current sequence',
    InitMirror(FOrigin.KeyID, FOrigin.PublicKey));
  RequireSuccess('mirror sync preserves upstream key record', Sync);
  FMirrorServer := StartRegistryCLI(FMirrorRoot, FMirrorURL);
  Expect<string>(Text(RegistryHTTPBody(FMirrorURL + '/v1/keys/'
    + FOrigin.KeyID + '.toml'))).ToBe(KeyDocument);
  StopRegistryCLI(FMirrorServer);
  { The unsigned effective sequence is bound to one accepted state only; the
    upstream's corrected record replaces it on the next synchronization. }
  WriteBytes(FOrigin.Root + KeyPath, BytesOf(HonestDocument));
  RequireSuccess('corrected upstream key record rebinds', Sync);
  RequireSuccess('verify rebound key record offline',
    RunLwpt(['registry', 'verify', '--data-dir', FMirrorRoot]));
  FMirrorServer := StartRegistryCLI(FMirrorRoot, FMirrorURL);
  Expect<string>(Text(RegistryHTTPBody(FMirrorURL + '/v1/keys/'
    + FOrigin.KeyID + '.toml'))).ToBe(HonestDocument);
end;

procedure TRegistryMirrorE2E.SignedRotationsSurviveOutage;
var
  KeyTwo, KeyThree, PointerBefore, RotationPath, Page, Cursor: string;
  OldSignature, RotationDocument: TBytes;
begin
  FOrigin.Publish('rotating-package', '1.0.0', BytesOf('rotating archive'));
  FOrigin.Start;
  RequireSuccess('first local rotation', RunLwpt(['registry', 'rotate-key', '--data-dir',
    FOrigin.Root, '--from-key', FOrigin.KeyID]));
  KeyTwo := Field(Text(RegistryHTTPBody(FOrigin.BaseURL + '/v1/checkpoints/latest.toml')), 'key_id');
  RequireSuccess('second local rotation', RunLwpt(['registry', 'rotate-key', '--data-dir',
    FOrigin.Root, '--from-key', KeyTwo]));
  KeyThree := Field(Text(RegistryHTTPBody(FOrigin.BaseURL + '/v1/checkpoints/latest.toml')), 'key_id');
  Expect<Integer>(RunLwpt(['registry', 'rotate-key', '--data-dir', FOrigin.Root,
    '--from-key', KeyTwo]).ExitCode).ToBe(1);
  Expect<string>(Field(Text(RegistryHTTPBody(FOrigin.BaseURL + '/v1/checkpoints/latest.toml')), 'key_id')).ToBe(KeyThree);
  RequireSuccess('root-pinned mirror init after two rotations', InitMirror(FOrigin.KeyID, FOrigin.PublicKey));
  RequireSuccess('bootstrap verifies both complete signed transitions', Sync);
  FMirrorServer := StartRegistryCLI(FMirrorRoot, FMirrorURL);
  Page := Text(RegistryHTTPBody(FMirrorURL + '/v1/rotations?after=0&limit=1'));
  Expect<Boolean>(Pos('effective_sequence = 3', Page) > 0).ToBe(True);
  Cursor := Field(Page, 'next_cursor');
  Expect<Boolean>(Cursor <> '').ToBe(True);
  Page := Text(RegistryHTTPBody(FMirrorURL + '/v1/rotations?after=0&limit=1&cursor=' + Cursor));
  Expect<Boolean>(Pos('effective_sequence = 4', Page) > 0).ToBe(True);
  Expect<string>(Field(Page, 'next_cursor')).ToBe('');
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1/rotations?after=1&limit=1&cursor=' + Cursor)).ToBe(400);
  PointerBefore := Text(ReadBytes(FMirrorRoot + '/state/current.toml'));
  RequireSuccess('incremental local rotation', RunLwpt(['registry', 'rotate-key', '--data-dir',
    FOrigin.Root, '--from-key', KeyThree]));
  RotationPath := FOrigin.Root + '/rotations/5';
  OldSignature := ReadBytes(RotationPath + '.old.sig.toml');
  RotationDocument := ReadBytes(RotationPath + '.toml');
  WriteBytes(RotationPath + '.old.sig.toml', BytesOf('tampered'));
  Expect<Integer>(Sync.ExitCode).ToBe(1);
  Expect<string>(Text(ReadBytes(FMirrorRoot + '/state/current.toml'))).ToBe(PointerBefore);
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1/rotations/5.toml')).ToBe(404);
  WriteBytes(RotationPath + '.old.sig.toml', OldSignature);
  WriteBytes(RotationPath + '.toml', BytesOf(StringReplace(Text(RotationDocument),
    'from_key = "' + KeyThree + '"', 'from_key = "' + FOrigin.KeyID + '"', [])));
  Expect<Integer>(Sync.ExitCode).ToBe(1);
  Expect<string>(Text(ReadBytes(FMirrorRoot + '/state/current.toml'))).ToBe(PointerBefore);
  WriteBytes(RotationPath + '.toml', RotationDocument);
  Expect<Boolean>(DeleteFile(RotationPath + '.old.sig.toml')).ToBe(True);
  Expect<Integer>(Sync.ExitCode).ToBe(1);
  Expect<string>(Text(ReadBytes(FMirrorRoot + '/state/current.toml'))).ToBe(PointerBefore);
  WriteBytes(RotationPath + '.old.sig.toml', OldSignature);
  RequireSuccess('retry accepts only the verified new transition', Sync);
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1/rotations/3.old.sig.toml')).ToBe(200);
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1/keys/' + KeyTwo + '.toml')).ToBe(200);
  FOrigin.Stop;
  StopRegistryCLI(FMirrorServer);
  FMirrorServer := StartRegistryCLI(FMirrorRoot, FMirrorURL);
  Expect<Integer>(HTTPStatus(FMirrorURL + '/v1/rotations/5.new.sig.toml')).ToBe(200);
  RequireSuccess('offline verification retains the entire signed chain',
    RunLwpt(['registry', 'verify', '--data-dir', FMirrorRoot]));
  Expect<Boolean>(FileExists(FMirrorRoot + '/keys/root.seed')).ToBe(False);
end;

procedure TRegistryMirrorE2E.ReadinessPreservesCLIDiagnostic;
var
  Child: TProcess;
  Diagnostic: string;
begin
  Child := nil;
  Diagnostic := '';
  try
    try
      Child := StartRegistryCLI(FScratch + '/missing', FMirrorURL);
    except
      on E: Exception do Diagnostic := E.Message;
    end;
    if Pos('exit=1', Diagnostic) = 0 then WriteLn(StdErr, Diagnostic);
    Expect<Boolean>(Pos('exit=1', Diagnostic) > 0).ToBe(True);
    Expect<Boolean>(Pos('origin_not_initialized:', Diagnostic) > 0).ToBe(True);
    Expect<Boolean>(Pos('last probe:', Diagnostic) > 0).ToBe(True);
  finally
    StopRegistryCLI(Child);
  end;
end;

procedure TRegistryMirrorE2E.BootstrapConsumesMultipleRotationPages;
var
  Proxy: TRegistryTestServer;
  Routes: TRegistryHTTPRouteArray;
  ProxyURL, KeyTwo, Page, Cursor: string;

  procedure AddRoute(const APath, AKind: string; const ARewrite: Boolean = False);
  var
    Body: TBytes;
    Document: string;
  begin
    Body := RegistryHTTPBody(FOrigin.BaseURL + APath);
    if ARewrite then
    begin
      Document := StringReplace(Text(Body), FOrigin.BaseURL + '/v1', ProxyURL + '/v1', [rfReplaceAll]);
      Document := StringReplace(Document, 'base_url = "' + FOrigin.BaseURL + '"',
        'base_url = "' + ProxyURL + '"', []);
      Document := StringReplace(Document, 'max_page_size = 100', 'max_page_size = 1', []);
      Body := BytesOf(Document);
    end;
    SetLength(Routes, Length(Routes) + 1);
    Routes[High(Routes)] := RegistryRoute('/proxy' + APath,
      'application/vnd.' + RegistryProgramName + '.registry-' + AKind + '+toml', Body);
  end;

  procedure AddPublicDirectory(const ADirectory, AKind: string);
  var
    Entry: TSearchRec;
    Name, Kind: string;
  begin
    if FindFirst(FOrigin.Root + '/' + ADirectory + '/*.toml', faAnyFile, Entry) <> 0 then Exit;
    try
      repeat
        if Entry.Attr and faDirectory <> 0 then Continue;
        Name := Entry.Name;
        Kind := AKind;
        if ADirectory = 'keys' then
          Name := Field(Text(ReadBytes(FOrigin.Root + '/keys/' + Name)), 'key_id') + '.toml';
        if Pos('.sig.toml', Name) > 0 then Kind := 'signature';
        AddRoute('/v1/' + ADirectory + '/' + Name, Kind);
      until FindNext(Entry) <> 0;
    finally
      FindClose(Entry);
    end;
  end;

begin
  FOrigin.Start;
  RequireSuccess('first pagination rotation', RunLwpt(['registry', 'rotate-key',
    '--data-dir', FOrigin.Root, '--from-key', FOrigin.KeyID]));
  KeyTwo := Field(Text(RegistryHTTPBody(FOrigin.BaseURL + '/v1/checkpoints/latest.toml')), 'key_id');
  RequireSuccess('second pagination rotation', RunLwpt(['registry', 'rotate-key',
    '--data-dir', FOrigin.Root, '--from-key', KeyTwo]));
  Proxy := TRegistryTestServer.Create(nil);
  try
    ProxyURL := 'http://localhost:' + IntToStr(Proxy.Port) + '/proxy';
    AddRoute('/.well-known/' + RegistryProgramName + '-registry', 'discovery', True);
    AddRoute('/v1/capabilities', 'capabilities', True);
    AddRoute('/v1/checkpoints/latest.toml', 'checkpoint');
    AddRoute('/v1/checkpoints/latest.sig.toml', 'signature');
    AddPublicDirectory('keys', 'key');
    AddPublicDirectory('rotations', 'key-rotation');
    AddPublicDirectory('snapshots/sha256', 'snapshot');
    Page := Text(RegistryHTTPBody(FOrigin.BaseURL + '/v1/rotations?after=0&limit=1'));
    Cursor := Field(Page, 'next_cursor');
    Expect<Boolean>(Cursor <> '').ToBe(True);
    AddRoute('/v1/rotations?after=0&limit=1', 'rotation-page', True);
    AddRoute('/v1/rotations?after=0&limit=1&cursor=' + Cursor, 'rotation-page', True);
    Proxy.SetRoutes(Routes);
    Proxy.Start;
    FOrigin.Stop;
    RequireSuccess('mirror initialized against one-item-page transport',
      InitMirror(FOrigin.KeyID, FOrigin.PublicKey, ProxyURL));
    RequireSuccess('actual CLI consumes both pages and original signed bytes', Sync);
    RequireSuccess('retained multi-page proof verifies without origin',
      RunLwpt(['registry', 'verify', '--data-dir', FMirrorRoot]));
  finally
    Proxy.Free;
  end;
end;

procedure TRegistryMirrorE2E.ForcedShutdownIsBounded;
var
  Child: TProcess;
  Started: QWord;
  Stopped: TRegistryStopResult;
  ReadyPath: string;
begin
  ReadyPath := FScratch + '/stubborn-child-ready';
  Child := TProcess.Create(nil);
  try
    Child.Executable := ParamStr(0);
    Child.Parameters.Add('--registry-stubborn-child');
    Child.Parameters.Add(ReadyPath);
    Child.Execute;
    Started := GetTickCount64;
    while not FileExists(ReadyPath) and Child.Running
      and (GetTickCount64 - Started < 2000) do Sleep(10);
    Expect<Boolean>(FileExists(ReadyPath)).ToBe(True);
    Started := GetTickCount64;
    Stopped := StopRegistryProcess(Child, 25, 2000);
    Expect<Boolean>(GetTickCount64 - Started < 2500).ToBe(True);
    Expect<Boolean>(Stopped.Stopped).ToBe(True);
    Expect<Boolean>(Child = nil).ToBe(True);
    {$IFDEF UNIX}
    Expect<Boolean>(Stopped.Forced).ToBe(True);
    {$ENDIF}
  finally
    StopRegistryProcess(Child, 25, 2000);
  end;
end;

procedure TRegistryMirrorE2E.MissingAndWrongPinsFailClosed;
var
  Other: TRegistryOriginFixture;
  Run: TLwptResult;
begin
  Run := InitMirror('', '');
  Expect<Integer>(Run.ExitCode).ToBe(1);
  Expect<Boolean>(FileExists(FMirrorRoot + '/registry.toml')).ToBe(False);
  Other := TRegistryOriginFixture.Create(FScratch + '/other-origin');
  try
    FOrigin.Start;
    RequireSuccess('explicit different pin is persisted, never replaced by discovery',
      InitMirror(Other.KeyID, Other.PublicKey));
    Run := Sync;
    Expect<Integer>(Run.ExitCode).ToBe(1);
    Expect<Boolean>(FileExists(FMirrorRoot + '/state/current.toml')).ToBe(False);
    Run := InitMirror(FOrigin.KeyID, FOrigin.PublicKey);
    Expect<Integer>(Run.ExitCode).ToBe(1);
    Expect<Boolean>(Pos('identity_conflict', Run.Stderr) > 0).ToBe(True);
  finally
    Other.Free;
  end;
end;

procedure TRegistryMirrorE2E.ByteBudgetsAreMirrorInitOptions;
var
  Port: string;
  Run: TLwptResult;
  Config: string;

  function InitWith(const AStore, ASync: string): TLwptResult;
  begin
    Result := RunLwpt(['registry', 'init', '--role', 'mirror', '--data-dir', FMirrorRoot,
      '--identity', FOrigin.Identity, '--base-url', FMirrorURL, '--port', Port,
      '--upstream', FOrigin.BaseURL, '--key-id', FOrigin.KeyID,
      '--public-key', FOrigin.PublicKey, '--max-store-bytes', AStore,
      '--max-sync-bytes', ASync]);
  end;
begin
  Port := Copy(FMirrorURL, Length('http://localhost:') + 1, MaxInt);
  Port := Copy(Port, 1, Pos('/', Port) - 1);
  Run := InitWith('4194304', '8388608');
  Expect<Integer>(Run.ExitCode).ToBe(1);
  Expect<Boolean>(Pos('invalid_configuration:', Run.Stderr) > 0).ToBe(True);
  Expect<Integer>(InitWith('0', '1048576').ExitCode).ToBe(1);
  Expect<Boolean>(FileExists(FMirrorRoot + '/registry.toml')).ToBe(False);
  RequireSuccess('mirror init with explicit byte budgets', InitWith('4194304', '2097152'));
  Config := Text(ReadBytes(FMirrorRoot + '/registry.toml'));
  Expect<Boolean>(Pos('max_store_bytes = 4194304' + #10, Config) > 0).ToBe(True);
  Expect<Boolean>(Pos('max_sync_bytes = 2097152' + #10, Config) > 0).ToBe(True);
  Run := RunLwpt(['registry', 'init', '--data-dir', FScratch + '/origin-budget',
    '--max-store-bytes', '4194304']);
  Expect<Integer>(Run.ExitCode).ToBe(1);
  Expect<Boolean>(Pos('mirror-only', Run.Stderr) > 0).ToBe(True);
  Expect<Integer>(RunLwpt(['registry', 'sync', '--data-dir', FMirrorRoot,
    '--max-sync-bytes', '2097152']).ExitCode).ToBe(1);
end;

procedure TRegistryMirrorE2E.ReadinessRequiresServedCheckpoint;
var
  Impostor: TRegistryTestServer;
  Routes: TRegistryHTTPRouteArray;
  BaseURL, Diagnostic: string;
  Child: TProcess;
begin
  { Another listener answers discovery for this base URL but cannot serve
    the data directory's checkpoint; readiness must not be claimed. }
  Impostor := TRegistryTestServer.Create(nil, True);
  Child := nil;
  try
    BaseURL := 'http://localhost:' + IntToStr(Impostor.Port) + '/origin';
    SetLength(Routes, 1);
    Routes[0] := RegistryRoute('/origin/.well-known/' + RegistryProgramName + '-registry',
      'application/vnd.' + RegistryProgramName + '.registry-discovery+toml',
      BytesOf('base_url = "' + BaseURL + '"' + #10));
    Impostor.SetRoutes(Routes);
    Impostor.Start;
    Diagnostic := '';
    { No relocation: the origin's own configured port may be held by another
      process, and relocating would make an unrelated listener ready. }
    try
      Child := StartRegistryCLI(FOrigin.Root, BaseURL, False);
    except
      on E: Exception do Diagnostic := E.Message;
    end;
    Expect<Boolean>(Child = nil).ToBe(True);
    Expect<Boolean>(Pos('did not become ready', Diagnostic) > 0).ToBe(True);
  finally
    StopRegistryCLI(Child);
    Impostor.Free;
  end;
end;

procedure TRegistryMirrorE2E.OriginStartRecoversFromPortCollision;
var
  Occupier: TRegistryTestServer;
  BaseBefore: string;
begin
  FOrigin.Publish('package', '1.0.0', BytesOf('archive'));
  { The occupier binds a kernel-chosen port first and the origin is then
    configured for it, so the collision is certain rather than raced. }
  Occupier := TRegistryTestServer.Create(nil, True);
  try
    FOrigin.MoveToPort(Occupier.Port);
    BaseBefore := FOrigin.BaseURL;
    FOrigin.Start;
    Expect<Boolean>(FOrigin.BaseURL <> BaseBefore).ToBe(True);
    Expect<Boolean>(Pos('base_url = "' + FOrigin.BaseURL + '"', Text(RegistryHTTPBody(
      FOrigin.BaseURL + '/.well-known/' + RegistryProgramName + '-registry'))) > 0).ToBe(True);
    Expect<Integer>(Occupier.RequestCount).ToBe(0);
    { The identity pinned by mirrors is unchanged by relocation. }
    RequireSuccess('mirror init against the relocated origin',
      InitMirror(FOrigin.KeyID, FOrigin.PublicKey));
    RequireSuccess('sync from the relocated origin', Sync);
  finally
    Occupier.Free;
  end;
end;

procedure TRegistryMirrorE2E.MirrorStartProvesListenerOwnership;
var
  Impostor: TRegistryTestServer;
  Routes: TRegistryHTTPRouteArray;
  URLBefore: string;
begin
  FOrigin.Start;
  RequireSuccess('uninitialized mirror init', InitMirror(FOrigin.KeyID, FOrigin.PublicKey));
  { The impostor binds a kernel-chosen port first and the never-synchronized
    mirror is then configured for it. It answers discovery with the mirror's
    own base URL and must not be mistaken for the mirror. }
  Impostor := TRegistryTestServer.Create(nil, True);
  try
    FMirrorURL := RelocateRegistryPortTo(FMirrorRoot, FMirrorURL, Impostor.Port);
    URLBefore := FMirrorURL;
    SetLength(Routes, 1);
    Routes[0] := RegistryRoute('/mirror/.well-known/' + RegistryProgramName + '-registry',
      'application/vnd.' + RegistryProgramName + '.registry-discovery+toml',
      BytesOf('base_url = "' + URLBefore + '"' + #10));
    Impostor.SetRoutes(Routes);
    Impostor.Start;
    FMirrorServer := StartRegistryCLI(FMirrorRoot, FMirrorURL);
    Expect<Boolean>(FMirrorURL <> URLBefore).ToBe(True);
    Expect<Boolean>(Pos('role = "mirror"', Text(RegistryHTTPBody(
      FMirrorURL + '/.well-known/' + RegistryProgramName + '-registry'))) > 0).ToBe(True);
  finally
    Impostor.Free;
  end;
end;

procedure TRegistryMirrorE2E.SetupTests;
begin
  Test('CLI mirror bootstrap survives origin outage and restart', BootstrapOutageAndRestart);
  Test('origin-pinned mirror client verifies served mirror bytes and rejects altered signature', MirrorClientVerifiesOriginDuringOutage);
  Test('incremental and idempotent sync reuse verified objects', IncrementalSyncReusesVerifiedObjects);
  Test('tampered or missing objects preserve the live accepted pointer', FailedSyncPreservesAcceptedPointer);
  Test('missing and wrong root pins fail without trust replacement', MissingAndWrongPinsFailClosed);
  Test('mirror preserves exact upstream key bytes and rebinds a corrected record', UpstreamKeyBytesArePreserved);
  Test('shared listener shutdown force-kills and reaps within its bound', ForcedShutdownIsBounded);
  Test('signed rotation bootstrap and incremental retry retain offline provenance', SignedRotationsSurviveOutage);
  Test('readiness failures retain the original CLI diagnostic and exit status', ReadinessPreservesCLIDiagnostic);
  Test('bootstrap consumes multiple bounded rotation pages with exact signed bytes', BootstrapConsumesMultipleRotationPages);
  Test('byte budgets are validated mirror init options', ByteBudgetsAreMirrorInitOptions);
  Test('readiness requires the listener to serve this data directory', ReadinessRequiresServedCheckpoint);
  Test('an origin start recovers from a port collision with a new port', OriginStartRecoversFromPortCollision);
  Test('an uninitialized mirror start proves it owns its listener', MirrorStartProvesListenerOwnership);
end;

begin
  if ParamStr(1) = '--registry-stubborn-child' then
  begin
    {$IFDEF UNIX}
    FpSignal(SIGTERM, SignalHandler(SIG_IGN));
    {$ENDIF}
    WriteBytes(ParamStr(2), BytesOf('ready'));
    Sleep(10000); { Independent finite fallback if the parent test aborts. }
    Halt(0);
  end;
  TestRunnerProgram.AddSuite(TRegistryMirrorE2E.Create('registry mirror E2E'));
  TestRunnerProgram.Run;
end.
