{ InstallDirectArchivesWindows.E2E.Test — Windows-only live archive fetch
  through the real lwpt binary.

  This complements the host-shorthand GitHub/GitLab E2E suites by bypassing
  tag/source URL construction and exercising the SChannel archive-body read
  path directly against stable archive endpoints. It exists for the Windows
  SChannel archive-fetch failure: corrupted SECBUFFER_EXTRA handling can turn
  the next TLS record into SEC_E_INVALID_TOKEN or an access violation. }

program InstallDirectArchivesWindows.E2E.Test;

{$mode delphi}{$H+}

uses
  Classes,
  SysUtils,

  TestingPascalLibrary,
  Tests.LwptSubprocess,
  Tests.Scratch;

const
  GITHUB_DEP_NAME = 'github-archive';
  GITLAB_DEP_NAME = 'gitlab-archive';
  GITHUB_ARCHIVE_URL =
    'https://codeload.github.com/octocat/Hello-World/tar.gz/' +
    '7fd1a60b01f91b314f59955a4e4d4e80d8edf11d';
  GITLAB_ARCHIVE_URL =
    'https://gitlab.com/gitlab-examples/ci-debug-trace/-/archive/' +
    'dd648b2e48ce6518303b0bb580b2ee32fadaf045/' +
    'ci-debug-trace-dd648b2e48ce6518303b0bb580b2ee32fadaf045.tar.gz';

type
  TLWPTInstallDirectArchivesWindowsE2E = class(TTestSuite)
  private
    FOrigDir, FScratch, FRoot: string;
    FSkipped: Boolean;
    FInstallExitCode: Integer;
    FInstallStdout: string;
    FInstallStderr: string;
    procedure SetupScratchProject;
  protected
    procedure BeforeAll; override;
    procedure AfterAll; override;
  public
    procedure SetupTests; override;
    procedure TestInstallExitsZero;
    procedure TestArchivesDownloadedAndExtracted;
    procedure TestLockfileRecordsDirectArchiveURLs;
  end;

function ReadFileText(const APath: string): string;
var
  SL: TStringList;
begin
  SL := TStringList.Create;
  try
    SL.LoadFromFile(APath);
    Result := SL.Text;
  finally
    SL.Free;
  end;
end;

procedure TLWPTInstallDirectArchivesWindowsE2E.SetupScratchProject;
begin
  ForceDirectories(FRoot + '/source');
  WriteTextFile(FRoot + '/source/main.pas',
    'program main;'#10 +
    '{$mode delphi}{$H+}'#10 +
    'begin end.'#10);
  WriteTextFile(FRoot + '/lwpt.toml',
    '[package]'#10 +
    'name = "direct-archives-windows-e2e"'#10 +
    'version = "0.0.0"'#10 +
    'units = ["source"]'#10 +
    ''#10 +
    '[dependencies]'#10 +
    GITHUB_DEP_NAME + ' = "' + GITHUB_ARCHIVE_URL + '"'#10 +
    GITLAB_DEP_NAME + ' = "' + GITLAB_ARCHIVE_URL + '"'#10);
end;

procedure TLWPTInstallDirectArchivesWindowsE2E.BeforeAll;
var
  R: TLwptResult;
begin
  FOrigDir := GetCurrentDir;
  FScratch := CreateScratchRoot('install-direct-archives-windows-e2e');
  FRoot := FScratch + '/root';
  FSkipped := SkipNetworkTests;
  {$IFNDEF MSWINDOWS}
  FSkipped := True;
  {$ENDIF}
  SetLwptBinaryPath(ExpandFileName('build/lwpt'));

  if FSkipped then
  begin
    WriteLn('  [skip] Windows SChannel live-network test skipped');
    Exit;
  end;

  RecursiveDelete(FScratch);
  ForceDirectories(FRoot);
  SetupScratchProject;

  R := RunLwpt(['install'], FRoot);
  FInstallExitCode := R.ExitCode;
  FInstallStdout := R.Stdout;
  FInstallStderr := R.Stderr;

  { Transient third-party downtime (the archive host unreachable at the
    TCP/DNS layer) is not an LWPT defect — skip rather than fail. A
    content/hash/parse failure leaves FSkipped False so the assertions
    below still fail hard. }
  if (not FSkipped) and IsNetworkUnavailable(R) then
  begin
    WriteLn('  [skip] archive host unreachable (transient network); e2e fetch skipped');
    FSkipped := True;
  end;
end;

procedure TLWPTInstallDirectArchivesWindowsE2E.AfterAll;
begin
  SetCurrentDir(FOrigDir);
end;

procedure TLWPTInstallDirectArchivesWindowsE2E.TestInstallExitsZero;
begin
  if FSkipped then
  begin
    Expect<Boolean>(True).ToBe(True);
    Exit;
  end;
  if FInstallExitCode <> 0 then
  begin
    WriteLn('--- install stdout ---'#10, FInstallStdout, #10'---');
    WriteLn('--- install stderr ---'#10, FInstallStderr, #10'---');
  end;
  Expect<Integer>(FInstallExitCode).ToBe(0);
end;

procedure TLWPTInstallDirectArchivesWindowsE2E.TestArchivesDownloadedAndExtracted;
begin
  if FSkipped then
  begin
    Expect<Boolean>(True).ToBe(True);
    Exit;
  end;
  Expect<Boolean>(
    FileExists(FRoot + '/.lwpt/archives/' + GITHUB_DEP_NAME + '-url.tar.gz')
  ).ToBe(True);
  Expect<Boolean>(
    FileExists(FRoot + '/.lwpt/archives/' + GITLAB_DEP_NAME + '-url.tar.gz')
  ).ToBe(True);
  Expect<Boolean>(
    FileExists(FRoot + '/.lwpt/modules/' + GITHUB_DEP_NAME + '/README') or
    FileExists(FRoot + '/.lwpt/modules/' + GITHUB_DEP_NAME + '/README.md')
  ).ToBe(True);
  Expect<Boolean>(
    FileExists(FRoot + '/.lwpt/modules/' + GITLAB_DEP_NAME + '/README.md') or
    FileExists(FRoot + '/.lwpt/modules/' + GITLAB_DEP_NAME + '/.gitlab-ci.yml')
  ).ToBe(True);
end;

procedure TLWPTInstallDirectArchivesWindowsE2E.TestLockfileRecordsDirectArchiveURLs;
var
  Lock: string;
begin
  if FSkipped then
  begin
    Expect<Boolean>(True).ToBe(True);
    Exit;
  end;
  Lock := ReadFileText(FRoot + '/lwpt.lock');
  Expect<Boolean>(Pos('source = "' + GITHUB_ARCHIVE_URL + '"', Lock) > 0).ToBe(True);
  Expect<Boolean>(Pos('source = "' + GITLAB_ARCHIVE_URL + '"', Lock) > 0).ToBe(True);
  Expect<Boolean>(Pos('archiveHash = "sha256:', Lock) > 0).ToBe(True);
  Expect<Boolean>(Pos('computedHash = "sha256-tree2:', Lock) > 0).ToBe(True);
end;

procedure TLWPTInstallDirectArchivesWindowsE2E.SetupTests;
begin
  Test('install exits zero against direct archive URLs',
    TestInstallExitsZero);
  Test('direct archives are downloaded and extracted',
    TestArchivesDownloadedAndExtracted);
  Test('lockfile records direct archive URLs and hashes',
    TestLockfileRecordsDirectArchiveURLs);
end;

begin
  TestRunnerProgram.AddSuite(TLWPTInstallDirectArchivesWindowsE2E.Create(
    'install: direct archives via Windows SChannel (E2E)'));
  TestRunnerProgram.Run;
  ExitCode := TestResultToExitCode;
end.
