{ Tests.Scratch — scratch-directory file helpers shared by the
  integration and E2E test programs.

  Every per-test scratch project needs the same primitives: allocate
  an invocation-private root, write a small text file (creating parent
  dirs), and wipe a directory tree. These used to be copy-pasted into
  each test program; this unit is their single home, next to
  Tests.LwptSubprocess (the support dir is already on every test's
  compile path via LWPT.Command.Testing).

  CreateScratchRoot uses a compact base-36 PID + timestamp owner slug.
  Before allocating it, stale siblings are atomically claimed and
  removed. A dead owner's root is reaped only after a short grace
  period (orphaned descendants of a crashed run can briefly outlive
  it); a live-looking owner's root still falls to the age ceiling,
  which bounds PID recycling. PID checks fail closed when liveness is
  indeterminate; the age ceiling alone is used only on platforms
  without a liveness API. This lets concurrent test invocations
  coexist while recovering debris from interrupted runs.

  RecursiveDelete is link-aware: a symlink is unlinked and a Windows
  directory symlink/junction is removed as a node (RemoveDir detaches
  a junction without touching its target), never followed — so a link
  planted inside a scratch tree (by the build --clean symlink
  regression test, or by the installer's monorepo link path, which
  puts junctions under a scratch project's .lwpt/modules/) cannot
  make the wipe escape the tree, delete live package sources, or
  recurse forever.

  On Windows the wipe addresses every entry by its extended-length
  (`\\?\`) spelling, so it removes trees that toolkit code legitimately
  nests past MAX_PATH (#347); the root is located the same way.

  A wipe that cannot complete raises, naming the path: a test that
  silently proceeds on a half-wiped scratch dir turns into stale-state
  flakiness that is far harder to diagnose than a loud setup error. }

unit Tests.Scratch;

{$mode delphi}{$H+}

interface

function CreateScratchRoot(const ASuite: string): string;
procedure WriteTextFile(const APath, AContent: string);
procedure RecursiveDelete(const APath: string);
{ Reads a whole file as raw bytes. It shares read, write, and delete
  access, the way LWPT's own registry readers do, so a file the toolkit
  publishes with an atomic rename can be read while that rename still
  holds its handle. On Unix it takes no flock(2), so it can read a file
  whose fcntl(2) record lock another process holds, such as a held
  install lock on Darwin. On Windows a sharing violation from a briefly held
  handle (the rename's own write-through, a scanner) is retried for up to
  READ_SHARING_RETRY_MILLISECONDS before the open fails. }
function ReadBinaryFile(const APath: string): string;
function TestCompilerExecutable: string;
{ Creates APath with length ASize without writing its bytes. On Windows the
  file is marked sparse first, so a large reservation costs no disk. }
procedure CreateSparseFile(const APath: string; const ASize: Int64);
{ Sets the last-write (and, on Unix, last-access) time of the existing file
  APath to AUnixSeconds plus ANanoseconds after the Unix epoch, so a test can
  order two files inside one SysUtils.FileAge tick without sleeping. Unix
  keeps microseconds (utimes); Windows keeps 100-nanosecond ticks
  (SetFileTime on the extended-length spelling). Raises, naming the path,
  when the time cannot be set. }
procedure SetFileModificationTime(const APath: string;
  const AUnixSeconds: Int64; const ANanoseconds: LongInt);
{ SetFileModificationTime, then reads the time back through the platform's
  own query (stat, or GetFileAttributesExW) and reports whether the
  filesystem kept exactly the requested time, to the setter's resolution.
  False when the filesystem keeps coarser times, cannot represent that
  date, or refuses the time. Tests probe with it before they rely on
  sub-second precision or an extreme date. }
function FileModificationTimeIsKept(const APath: string;
  const AUnixSeconds: Int64; const ANanoseconds: LongInt): Boolean;

const
  { 2300-01-01T00:00:00Z, past the 2262 limit of a signed 64-bit
    nanosecond count since the Unix epoch. }
  FarFutureUnixSeconds = Int64(10413792000);
  { 1969-07-20T20:17:40Z, before the Unix epoch. }
  PreEpochUnixSeconds = Int64(-14182940);

type
  { What the filesystem under the scratch base keeps of a set time. }
  TTimestampSupport = record
    { A time one millisecond into a second is read back exactly. }
    SubSecond: Boolean;
    { FarFutureUnixSeconds and PreEpochUnixSeconds are read back exactly. }
    WideDates: Boolean;
  end;

{ Probes a scratch file with FileModificationTimeIsKept. Tests call it while
  registering cases, to choose between a precision-specific case and its
  coarse-timestamp counterpart, or to skip a date the filesystem cannot
  store. }
function ProbeTimestampSupport: TTimestampSupport;

const
  READ_SHARING_RETRY_MILLISECONDS = 2000;

type
  TScratchReadSharingRetryHook = procedure(const APath: string);

var
  { Test-only observation: incremented, atomically, each time
    ReadBinaryFile retries an open that failed with a sharing violation,
    so a test can prove a retry happened without timing it. }
  ScratchReadSharingRetries: LongInt = 0;
  { Test-only: when set, ReadBinaryFile calls it on the reading thread
    after each open that failed with a sharing violation and before it
    sleeps, so a test can release the conflicting handle at exactly that
    point. Production use leaves it nil. }
  ScratchReadSharingRetryHook: TScratchReadSharingRetryHook = nil;

implementation

uses
  {$IFDEF UNIX}
  BaseUnix,
  InitC,
  {$ENDIF}
  Classes,
  DateUtils,
  {$IFDEF MSWINDOWS}
  Windows,
  {$ENDIF}
  SysUtils;

const
  ScratchBase = 'build/tests/tmp';
  {$IFDEF UNIX}
  { FD_CLOEXEC, which the Linux RTL does not declare. }
  CLOSE_ON_EXEC = 1;
  {$ENDIF}
  ReapPrefix = '.reap-';
  StaleAgeDays = 7;
  DeadOwnerGraceMSec = 10 * 60 * 1000;
  Base36Radix = 36;
  OwnerSeparator = '-';

type
  TProcessLiveness = (plAlive, plDead, plUnknown, plUnavailable);

var
  LastScratchTimestamp: QWord = 0;
  ReapCounter: QWord = 0;

function EncodeBase36(AValue: QWord): string;
const
  Digits = '0123456789abcdefghijklmnopqrstuvwxyz';
begin
  if AValue = 0 then Exit('0');
  Result := '';
  while AValue > 0 do
  begin
    Result := Digits[(AValue mod Base36Radix) + 1] + Result;
    AValue := AValue div Base36Radix;
  end;
end;

function TryDecodeBase36(const AValue: string; out ADecoded: QWord): Boolean;
var
  Index: Integer;
  Digit: QWord;
begin
  Result := False;
  ADecoded := 0;
  if AValue = '' then Exit;
  for Index := 1 to Length(AValue) do
  begin
    case AValue[Index] of
      '0'..'9': Digit := Ord(AValue[Index]) - Ord('0');
      'a'..'z': Digit := Ord(AValue[Index]) - Ord('a') + 10;
    else
      Exit;
    end;
    if ADecoded > (High(QWord) - Digit) div Base36Radix then Exit;
    ADecoded := ADecoded * Base36Radix + Digit;
  end;
  Result := True;
end;

function CurrentScratchTimestamp: QWord; inline;
begin
  Result := QWord(Round(Now * MSecsPerDay));
end;

function NextScratchTimestamp: QWord;
begin
  Result := CurrentScratchTimestamp;
  if Result <= LastScratchTimestamp then Result := LastScratchTimestamp + 1;
  LastScratchTimestamp := Result;
end;

function PathExists(const APath: string): Boolean;
var
  Search: TSearchRec;
begin
  if APath = '' then Exit(False);
  Result := SysUtils.FindFirst(ExcludeTrailingPathDelimiter(APath),
    faAnyFile or faSymLink, Search) = 0;
  if Result then SysUtils.FindClose(Search);
end;

procedure ValidateSuiteName(const ASuite: string);
var
  Index: Integer;
begin
  if ASuite = '' then
    raise Exception.Create('CreateScratchRoot: suite name cannot be empty');
  for Index := 1 to Length(ASuite) do
    if not (ASuite[Index] in ['a'..'z', '0'..'9', '-']) then
      raise Exception.CreateFmt(
        'CreateScratchRoot: invalid suite name "%s"', [ASuite]);
end;

function ProcessLiveness(const APID: QWord): TProcessLiveness;
{$IFDEF UNIX}
var
  ErrorCode: cint;
begin
  if APID = 0 then Exit(plDead);
  if APID > QWord(High(LongInt)) then Exit(plUnknown);
  if FpKill(LongInt(APID), 0) = 0 then Exit(plAlive);
  ErrorCode := fpgeterrno;
  if ErrorCode = ESysESRCH then Exit(plDead);
  if ErrorCode = ESysEPERM then Exit(plAlive);
  Result := plUnknown;
end;
{$ELSE}
{$IFDEF MSWINDOWS}
var
  Handle: THandle;
  WaitResult, ErrorCode: DWORD;
begin
  if APID = 0 then Exit(plDead);
  if APID > QWord(High(DWORD)) then Exit(plDead);
  Handle := Windows.OpenProcess(Windows.SYNCHRONIZE, False, DWORD(APID));
  if Handle = 0 then
  begin
    ErrorCode := Windows.GetLastError;
    if ErrorCode = Windows.ERROR_INVALID_PARAMETER then Exit(plDead);
    { Like EPERM on Unix: the process exists but is not ours. }
    if ErrorCode = Windows.ERROR_ACCESS_DENIED then Exit(plAlive);
    Exit(plUnknown);
  end;
  try
    { GetExitCodeProcess cannot tell a running process from one that
      exited with code 259 (STILL_ACTIVE); a zero-timeout wait on the
      process handle has no such ambiguity. }
    WaitResult := Windows.WaitForSingleObject(Handle, 0);
    if WaitResult = Windows.WAIT_TIMEOUT then Result := plAlive
    else if WaitResult = Windows.WAIT_OBJECT_0 then Result := plDead
    else Result := plUnknown;
  finally
    Windows.CloseHandle(Handle);
  end;
end;
{$ELSE}
begin
  if APID = 0 then Exit(plDead);
  Result := plUnavailable;
end;
{$ENDIF}
{$ENDIF}

function OwnerIsStale(const APID: QWord; const ATimestamp: QWord): Boolean;
var
  Current, Age: QWord;
begin
  Current := CurrentScratchTimestamp;
  if Current > ATimestamp then Age := Current - ATimestamp
  else Age := 0;
  case ProcessLiveness(APID) of
    { A crashed owner's orphaned descendants can briefly outlive it
      and still write into the root; the grace period outlasts them. }
    plDead: Exit(Age >= DeadOwnerGraceMSec);
    { PID recycling can make an abandoned root look owned forever;
      the age ceiling bounds that. }
    plAlive, plUnknown: Exit(Age >= QWord(StaleAgeDays) * MSecsPerDay);
  end;
  Result := Age >= QWord(StaleAgeDays) * MSecsPerDay;
end;

function TryParseOwner(const AName, APrefix: string;
  out APID: QWord; out ATimestamp: QWord): Boolean;
var
  Tail, PIDPart, TimestampPart: string;
  Separator: Integer;
begin
  Result := False;
  APID := 0;
  ATimestamp := 0;
  if Copy(AName, 1, Length(APrefix)) <> APrefix then Exit;
  Tail := Copy(AName, Length(APrefix) + 1, MaxInt);
  Separator := Pos(OwnerSeparator, Tail);
  if Separator = 0 then Exit;
  PIDPart := Copy(Tail, 1, Separator - 1);
  TimestampPart := Copy(Tail, Separator + 1, MaxInt);
  if Pos(OwnerSeparator, TimestampPart) > 0 then Exit;
  if not TryDecodeBase36(PIDPart, APID) then Exit;
  if not TryDecodeBase36(TimestampPart, ATimestamp) then Exit;
  Result := True;
end;

function TryParseReapOwner(const AName: string;
  out APID: QWord; out ATimestamp: QWord): Boolean;
var
  Tail, OwnerPart, CounterPart: string;
  Separator: Integer;
  DecodedReapCounter: QWord;
begin
  Result := False;
  if Copy(AName, 1, Length(ReapPrefix)) <> ReapPrefix then Exit;
  Tail := Copy(AName, Length(ReapPrefix) + 1, MaxInt);
  Separator := LastDelimiter(OwnerSeparator, Tail);
  if Separator = 0 then Exit;
  OwnerPart := Copy(Tail, 1, Separator - 1);
  CounterPart := Copy(Tail, Separator + 1, MaxInt);
  if not TryDecodeBase36(CounterPart, DecodedReapCounter) then Exit;
  Result := TryParseOwner(OwnerPart, '', APID, ATimestamp);
end;

procedure RemoveLink(const APath: string; const AAttributes: LongInt);
begin
  {$IFDEF MSWINDOWS}
  if (AAttributes and faDirectory) <> 0 then
  begin
    if not RemoveDir(APath) then
      raise Exception.CreateFmt(
        'RecursiveDelete: failed to remove dir link "%s": %s',
        [APath, SysErrorMessage(GetLastOSError)]);
  end
  else
  {$ENDIF}
  if not SysUtils.DeleteFile(APath) then
    raise Exception.CreateFmt(
      'RecursiveDelete: failed to unlink "%s": %s',
      [APath, SysErrorMessage(GetLastOSError)]);
end;

procedure ClaimAndDelete(const APath, ABase: string);
var
  ClaimedPath: string;
begin
  repeat
    Inc(ReapCounter);
    ClaimedPath := ABase + ReapPrefix
      + EncodeBase36(QWord(GetProcessID)) + OwnerSeparator
      + EncodeBase36(NextScratchTimestamp) + OwnerSeparator
      + EncodeBase36(ReapCounter);
  until not PathExists(ClaimedPath);
  if not RenameFile(APath, ClaimedPath) then
  begin
    { Another invocation may have claimed the same stale root after
      enumeration. Only report an error when the source still exists. }
    if PathExists(APath) then
      raise Exception.CreateFmt(
        'CreateScratchRoot: failed to claim stale root "%s": %s',
        [APath, SysErrorMessage(GetLastOSError)]);
    Exit;
  end;
  RecursiveDelete(ClaimedPath);
end;

procedure ReapStaleRoots(const ABase, ASuite: string);
var
  Search: TSearchRec;
  Candidates: TStringList;
  Base, Candidate: string;
  PID: QWord;
  Timestamp: QWord;
  Index: Integer;
begin
  Base := IncludeTrailingPathDelimiter(ABase);
  Candidates := TStringList.Create;
  try
    if SysUtils.FindFirst(Base + '*', faAnyFile or faSymLink, Search) = 0 then
      try
        repeat
          if (Search.Name = '.') or (Search.Name = '..') then Continue;
          if (Search.Attr and (faDirectory or faSymLink)) = 0 then Continue;
          if TryParseOwner(Search.Name, ASuite + OwnerSeparator,
              PID, Timestamp)
            and OwnerIsStale(PID, Timestamp) then
            Candidates.Add(Base + Search.Name)
          else if TryParseReapOwner(Search.Name, PID, Timestamp)
            and OwnerIsStale(PID, Timestamp) then
            Candidates.Add(Base + Search.Name);
        until SysUtils.FindNext(Search) <> 0;
      finally
        SysUtils.FindClose(Search);
      end;
    for Index := 0 to Candidates.Count - 1 do
    begin
      Candidate := Candidates[Index];
      if PathExists(Candidate) then ClaimAndDelete(Candidate, Base);
    end;
  finally
    Candidates.Free;
  end;
end;

function CreateScratchRoot(const ASuite: string): string;
var
  Base, ProcessIDSlug: string;
begin
  ValidateSuiteName(ASuite);
  Base := ExpandFileName(ScratchBase);
  if not ForceDirectories(Base) and not DirectoryExists(Base) then
    raise Exception.CreateFmt(
      'CreateScratchRoot: failed to create base directory "%s": %s',
      [Base, SysErrorMessage(GetLastOSError)]);
  ReapStaleRoots(Base, ASuite);
  ProcessIDSlug := EncodeBase36(QWord(GetProcessID));
  repeat
    Result := IncludeTrailingPathDelimiter(Base) + ASuite
      + OwnerSeparator + ProcessIDSlug + OwnerSeparator
      + EncodeBase36(NextScratchTimestamp);
  until not PathExists(Result);
  if not ForceDirectories(Result) and not DirectoryExists(Result) then
    raise Exception.CreateFmt(
      'CreateScratchRoot: failed to create root "%s": %s',
      [Result, SysErrorMessage(GetLastOSError)]);
end;

procedure WriteTextFile(const APath, AContent: string);
var
  SL: TStringList;
begin
  ForceDirectories(ExtractFileDir(APath));
  SL := TStringList.Create;
  try
    SL.Text := AContent;
    SL.SaveToFile(APath);
  finally
    SL.Free;
  end;
end;

{$IFDEF MSWINDOWS}
const
  ERROR_SHARING_VIOLATION_LWPT = 32;

function ScratchExtendedPath(const APath: string): UnicodeString; forward;

{ Opens APath for reading with full sharing, retrying only a sharing
  violation within READ_SHARING_RETRY_MILLISECONDS. The caller closes the
  returned handle. }
function OpenSharedReadHandle(const APath: string): THandle;
var
  ErrorCode: DWORD;
  StartedAt: QWord;
  WidePath: UnicodeString;
begin
  { The extended-length spelling reaches files past MAX_PATH. }
  WidePath := ScratchExtendedPath(APath);
  StartedAt := GetTickCount64;
  repeat
    Result := Windows.CreateFileW(PWideChar(WidePath), Windows.GENERIC_READ,
      Windows.FILE_SHARE_READ or Windows.FILE_SHARE_WRITE
        or Windows.FILE_SHARE_DELETE, nil, Windows.OPEN_EXISTING,
      Windows.FILE_ATTRIBUTE_NORMAL, 0);
    if Result <> Windows.INVALID_HANDLE_VALUE then Exit;
    ErrorCode := Windows.GetLastError;
    if (ErrorCode <> ERROR_SHARING_VIOLATION_LWPT)
      or (GetTickCount64 - StartedAt >= READ_SHARING_RETRY_MILLISECONDS) then
      raise EFOpenError.CreateFmt('Unable to open file "%s": %s',
        [APath, SysErrorMessage(ErrorCode)]);
    InterLockedIncrement(ScratchReadSharingRetries);
    if Assigned(ScratchReadSharingRetryHook) then
      ScratchReadSharingRetryHook(APath);
    SysUtils.Sleep(10);
  until False;
end;
{$ENDIF}

function ReadBinaryFile(const APath: string): string;
var
  {$IFDEF MSWINDOWS}
  Handle: THandle;
  Stream: THandleStream;
  {$ELSE}
  Descriptor: cint;
  ErrorCode: cint;
  Stream: THandleStream;
  {$ENDIF}
begin
  {$IFDEF MSWINDOWS}
  Handle := OpenSharedReadHandle(APath);
  try
    Stream := THandleStream.Create(Handle);
    try
      SetLength(Result, Stream.Size);
      if Stream.Size > 0 then Stream.ReadBuffer(Result[1], Stream.Size);
    finally
      Stream.Free;
    end;
  finally
    Windows.CloseHandle(Handle);
  end;
  {$ELSE}
  { A plain open(2), never SysUtils.FileOpen: FileOpen takes flock(2), which
    on Darwin shares one lock list with fcntl(2) record locks and fails with
    EAGAIN while LWPT's install lock holds its record lock (#384). }
  repeat
    Descriptor := FpOpen(PChar(APath), O_RDONLY);
  until (Descriptor >= 0) or (FpGetErrNo <> ESysEINTR);
  if Descriptor < 0 then
  begin
    ErrorCode := FpGetErrNo;
    raise EFOpenError.CreateFmt('Unable to open file "%s": %s',
      [APath, SysErrorMessage(ErrorCode)]);
  end;
  FpFcntl(Descriptor, F_SetFd, CLOSE_ON_EXEC);
  try
    Stream := THandleStream.Create(Descriptor);
    try
      SetLength(Result, Stream.Size);
      if Stream.Size > 0 then Stream.ReadBuffer(Result[1], Stream.Size);
    finally
      Stream.Free;
    end;
  finally
    FpClose(Descriptor);
  end;
  {$ENDIF}
end;

procedure CreateSparseFile(const APath: string; const ASize: Int64);
{$IFDEF MSWINDOWS}
const
  FSCTL_SET_SPARSE_LWPT = $000900C4;
var
  Returned: DWORD;
{$ENDIF}
var
  Stream: TFileStream;
begin
  ForceDirectories(ExtractFileDir(APath));
  Stream := TFileStream.Create(APath, fmCreate);
  try
    {$IFDEF MSWINDOWS}
    Returned := 0;
    Windows.DeviceIoControl(Stream.Handle, FSCTL_SET_SPARSE_LWPT, nil, 0, nil,
      0, Returned, nil);
    {$ENDIF}
    Stream.Size := ASize;
  finally
    Stream.Free;
  end;
end;

function TestCompilerExecutable: string;
begin
  Result := GetEnvironmentVariable('LWPT_FPC');
  if Result = '' then Result := GetEnvironmentVariable('FPC');
  if Result <> '' then Exit;
  {$IFDEF MSWINDOWS}
  Result := 'fpc.exe';
  {$ELSE}
  Result := 'fpc';
  {$ENDIF}
end;

{$IFDEF MSWINDOWS}
{ The extended-length (`\\?\`) spelling of an absolute scratch path, from
  Win32's own parse, so cleanup reaches trees that toolkit code legitimately
  nests past MAX_PATH (#347). This unit stays free of LWPT units because
  root E2E programs share it; LWPT.Core's helpers are not available here. }
function ScratchExtendedPath(const APath: string): UnicodeString;
var
  Input, Full: UnicodeString;
  Needed, Written: DWORD;
  FilePart: PWideChar;
begin
  Input := UnicodeString(StringReplace(APath, '/', '\', [rfReplaceAll]));
  if Copy(Input, 1, 4) = '\\?\' then Exit(Input);
  Full := '';
  Needed := Windows.GetFullPathNameW(PWideChar(Input), 0, PWideChar(nil),
    FilePart);
  while Needed > 0 do
  begin
    SetLength(Full, Needed);
    Written := Windows.GetFullPathNameW(PWideChar(Input), Needed,
      PWideChar(Full), FilePart);
    if (Written = 0) or (Written < Needed) then
    begin
      SetLength(Full, Written);
      Break;
    end;
    Needed := Written;
  end;
  if Full = '' then Exit(Input);
  while (Length(Full) > 3) and (Full[Length(Full)] = '\') do
    SetLength(Full, Length(Full) - 1);
  if (Length(Full) >= 3) and (Full[2] = ':') and (Full[3] = '\') then
    Result := '\\?\' + Full
  else if (Copy(Full, 1, 2) = '\\') and (Copy(Full, 1, 4) <> '\\.\') then
    Result := '\\?\UNC\' + Copy(Full, 3, MaxInt)
  else
    Result := Full;
end;

procedure RaiseScratchError(const AFormat, APath: string);
begin
  raise Exception.CreateFmt(AFormat,
    [APath, SysErrorMessage(Windows.GetLastError)]);
end;

{ Removes the directory AExtended (an extended spelling) and its contents.
  Links are removed as nodes and never followed: RemoveDirectoryW detaches
  a directory link or junction, DeleteFileW removes a file link. ADisplay
  names the same path for diagnostics. }
procedure RecursiveDeleteExtended(const AExtended: UnicodeString;
  const ADisplay: string);
var
  Find: THandle;
  Data: TWin32FindDataW;
  Names: array of UnicodeString;
  Attributes: array of DWORD;
  Count, Index: Integer;
  Name, Child: UnicodeString;
  ChildDisplay: string;
begin
  Count := 0;
  Names := nil;
  Attributes := nil;
  { Snapshot the listing first; the deletions below never race the
    enumeration handle. }
  Find := Windows.FindFirstFileW(PWideChar(AExtended + '\*'), Data);
  if Find <> THandle(Windows.INVALID_HANDLE_VALUE) then
    try
      repeat
        Name := PWideChar(@Data.cFileName[0]);
        if (Name = '.') or (Name = '..') then Continue;
        if Count = Length(Names) then
        begin
          SetLength(Names, Count * 2 + 16);
          SetLength(Attributes, Count * 2 + 16);
        end;
        Names[Count] := Name;
        Attributes[Count] := Data.dwFileAttributes;
        Inc(Count);
      until not Windows.FindNextFileW(Find, Data);
    finally
      Windows.FindClose(Find);
    end;
  for Index := 0 to Count - 1 do
  begin
    Child := AExtended + '\' + Names[Index];
    ChildDisplay := IncludeTrailingPathDelimiter(ADisplay)
      + string(Names[Index]);
    if (Attributes[Index] and Windows.FILE_ATTRIBUTE_REPARSE_POINT) <> 0 then
    begin
      if (Attributes[Index] and Windows.FILE_ATTRIBUTE_DIRECTORY) <> 0 then
      begin
        if not Windows.RemoveDirectoryW(PWideChar(Child)) then
          RaiseScratchError(
            'RecursiveDelete: failed to remove dir link "%s": %s',
            ChildDisplay);
      end
      else if not Windows.DeleteFileW(PWideChar(Child)) then
        RaiseScratchError('RecursiveDelete: failed to unlink "%s": %s',
          ChildDisplay);
    end
    else if (Attributes[Index] and Windows.FILE_ATTRIBUTE_DIRECTORY) <> 0 then
      RecursiveDeleteExtended(Child, ChildDisplay)
    else if not Windows.DeleteFileW(PWideChar(Child)) then
      RaiseScratchError('RecursiveDelete: failed to delete "%s": %s',
        ChildDisplay);
  end;
  if not Windows.RemoveDirectoryW(PWideChar(AExtended)) then
    RaiseScratchError('RecursiveDelete: failed to remove directory "%s": %s',
      ADisplay);
end;

procedure RecursiveDelete(const APath: string);
var
  Extended: UnicodeString;
  Attributes: DWORD;
begin
  if APath = '' then Exit;
  Extended := ScratchExtendedPath(ExcludeTrailingPathDelimiter(APath));
  Attributes := Windows.GetFileAttributesW(PWideChar(Extended));
  if Attributes = $FFFFFFFF then Exit;
  { A root link is removed as a node through the same extended spelling as
    a child link; its target is never touched. }
  if (Attributes and Windows.FILE_ATTRIBUTE_REPARSE_POINT) <> 0 then
  begin
    if (Attributes and Windows.FILE_ATTRIBUTE_DIRECTORY) <> 0 then
    begin
      if not Windows.RemoveDirectoryW(PWideChar(Extended)) then
        RaiseScratchError(
          'RecursiveDelete: failed to remove dir link "%s": %s', APath);
    end
    else if not Windows.DeleteFileW(PWideChar(Extended)) then
      RaiseScratchError('RecursiveDelete: failed to unlink "%s": %s', APath);
    Exit;
  end;
  if (Attributes and Windows.FILE_ATTRIBUTE_DIRECTORY) = 0 then Exit;
  RecursiveDeleteExtended(Extended, ExcludeTrailingPathDelimiter(APath));
end;
{$ELSE}
procedure RecursiveDelete(const APath: string);
var
  SR, RootSearch: TSearchRec;
  Base: string;
begin
  if APath = '' then Exit;
  if SysUtils.FindFirst(ExcludeTrailingPathDelimiter(APath),
    faAnyFile or faSymLink, RootSearch) <> 0 then Exit;
  try
    if (RootSearch.Attr and faSymLink) <> 0 then
    begin
      RemoveLink(APath, RootSearch.Attr);
      Exit;
    end;
    if (RootSearch.Attr and faDirectory) = 0 then Exit;
  finally
    SysUtils.FindClose(RootSearch);
  end;
  Base := IncludeTrailingPathDelimiter(APath);
  { faSymLink in the mask makes FindFirst report links as links; a link is
    removed as a node instead of recursed into. A Unix symlink (even one
    whose Attr also carries faDirectory from the target) unlinks via
    DeleteFile; RemoveDir on a symlink is ENOTDIR. }
  if SysUtils.FindFirst(Base + '*', faAnyFile or faSymLink, SR) = 0 then
    try
      repeat
        if (SR.Name = '.') or (SR.Name = '..') then Continue;
        if (SR.Attr and faSymLink) <> 0 then
          RemoveLink(Base + SR.Name, SR.Attr)
        else if (SR.Attr and faDirectory) <> 0 then
          RecursiveDelete(Base + SR.Name)
        else if not SysUtils.DeleteFile(Base + SR.Name) then
          raise Exception.CreateFmt(
            'RecursiveDelete: failed to delete "%s": %s',
            [Base + SR.Name, SysErrorMessage(GetLastOSError)]);
      until SysUtils.FindNext(SR) <> 0;
    finally
      SysUtils.FindClose(SR);
    end;
  if not RemoveDir(APath) then
    raise Exception.CreateFmt(
      'RecursiveDelete: failed to remove directory "%s": %s',
      [APath, SysErrorMessage(GetLastOSError)]);
end;
{$ENDIF}

{$IFDEF MSWINDOWS}
const
  { FILETIME ticks are 100 ns from 1601-01-01; the Unix epoch is this many
    seconds later. }
  UnixEpochFileTimeSeconds = 11644473600;
  FileTimeTicksPerSecond = 10000000;
  NanosecondsPerFileTimeTick = 100;

function RequestedFileTimeTicks(const AUnixSeconds: Int64;
  const ANanoseconds: LongInt): QWord;
begin
  Result := QWord(AUnixSeconds + UnixEpochFileTimeSeconds)
    * FileTimeTicksPerSecond
    + QWord(ANanoseconds div NanosecondsPerFileTimeTick);
end;

{ The Win32 error of a failed attempt, or 0. }
function TrySetModificationTime(const APath: string;
  const AUnixSeconds: Int64; const ANanoseconds: LongInt;
  out AOperation: string): DWORD;
var
  Handle: THandle;
  Ticks: QWord;
  Stamp: TFileTime;
begin
  Result := 0;
  Ticks := RequestedFileTimeTicks(AUnixSeconds, ANanoseconds);
  Stamp.dwLowDateTime := DWORD(Ticks and $FFFFFFFF);
  Stamp.dwHighDateTime := DWORD(Ticks shr 32);
  AOperation := 'open';
  Handle := Windows.CreateFileW(PWideChar(ScratchExtendedPath(APath)),
    Windows.FILE_WRITE_ATTRIBUTES, Windows.FILE_SHARE_READ
    or Windows.FILE_SHARE_WRITE or Windows.FILE_SHARE_DELETE, nil,
    Windows.OPEN_EXISTING, Windows.FILE_FLAG_BACKUP_SEMANTICS, 0);
  if Handle = Windows.INVALID_HANDLE_VALUE then Exit(Windows.GetLastError);
  try
    AOperation := 'stamp';
    if not Windows.SetFileTime(Handle, nil, nil, @Stamp) then
      Result := Windows.GetLastError;
  finally
    Windows.CloseHandle(Handle);
  end;
end;

procedure SetFileModificationTime(const APath: string;
  const AUnixSeconds: Int64; const ANanoseconds: LongInt);
var
  Error: DWORD;
  Operation: string;
begin
  Error := TrySetModificationTime(APath, AUnixSeconds, ANanoseconds,
    Operation);
  if Error <> 0 then
    raise Exception.CreateFmt(
      'SetFileModificationTime: failed to %s "%s": %s',
      [Operation, APath, SysErrorMessage(Error)]);
end;

function FileModificationTimeIsKept(const APath: string;
  const AUnixSeconds: Int64; const ANanoseconds: LongInt): Boolean;
var
  Operation: string;
  Data: TWin32FileAttributeData;
  Ticks: QWord;
begin
  if TrySetModificationTime(APath, AUnixSeconds, ANanoseconds,
    Operation) <> 0 then Exit(False);
  if not Windows.GetFileAttributesExW(PWideChar(ScratchExtendedPath(APath)),
    GetFileExInfoStandard, @Data) then Exit(False);
  Ticks := (QWord(Data.ftLastWriteTime.dwHighDateTime) shl 32)
    or QWord(Data.ftLastWriteTime.dwLowDateTime);
  Result := Ticks = RequestedFileTimeTicks(AUnixSeconds, ANanoseconds);
end;
{$ELSE}
const
  NanosecondsPerMicrosecond = 1000;

function CUtimes(APath: PChar; ATimes: PTimeVal): cint; cdecl;
  external 'c' name 'utimes';

{ The libc errno of a failed utimes, or 0. utimes is a libc call, so its
  error is libc's errno, not the RTL's syscall errno that fpGetErrno reads
  on Linux. }
function TrySetModificationTime(const APath: string;
  const AUnixSeconds: Int64; const ANanoseconds: LongInt): cint;
var
  Times: array[0..1] of TTimeVal;
begin
  Times[0].tv_sec := AUnixSeconds;
  Times[0].tv_usec := ANanoseconds div NanosecondsPerMicrosecond;
  Times[1] := Times[0];
  if CUtimes(PChar(APath), @Times[0]) = 0 then Exit(0);
  Result := fpgetCerrno;
end;

procedure SetFileModificationTime(const APath: string;
  const AUnixSeconds: Int64; const ANanoseconds: LongInt);
var
  Error: cint;
begin
  Error := TrySetModificationTime(APath, AUnixSeconds, ANanoseconds);
  if Error <> 0 then
    raise Exception.CreateFmt(
      'SetFileModificationTime: failed to stamp "%s": %s',
      [APath, SysErrorMessage(Error)]);
end;

function FileModificationTimeIsKept(const APath: string;
  const AUnixSeconds: Int64; const ANanoseconds: LongInt): Boolean;
var
  Info: BaseUnix.Stat;
begin
  if TrySetModificationTime(APath, AUnixSeconds, ANanoseconds) <> 0 then
    Exit(False);
  if FpStat(APath, Info) <> 0 then Exit(False);
  Result := (Int64(Info.st_mtime) = AUnixSeconds)
    and (Int64(Info.{$IFDEF LINUX}st_mtime_nsec{$ELSE}st_mtimensec{$ENDIF})
      = Int64(ANanoseconds div NanosecondsPerMicrosecond)
        * NanosecondsPerMicrosecond);
end;
{$ENDIF}

function ProbeTimestampSupport: TTimestampSupport;
const
  ProbeSeconds = 1700000000;
  ProbeNanoseconds = 501000000;
var
  Root, Probe: string;
begin
  Root := CreateScratchRoot('timestamp-probe');
  try
    Probe := IncludeTrailingPathDelimiter(Root) + 'probe.txt';
    WriteTextFile(Probe, 'probe');
    Result.SubSecond := FileModificationTimeIsKept(Probe, ProbeSeconds,
      ProbeNanoseconds);
    Result.WideDates := FileModificationTimeIsKept(Probe,
      FarFutureUnixSeconds, 0)
      and FileModificationTimeIsKept(Probe, PreEpochUnixSeconds, 0);
  finally
    RecursiveDelete(Root);
  end;
end;

end.
