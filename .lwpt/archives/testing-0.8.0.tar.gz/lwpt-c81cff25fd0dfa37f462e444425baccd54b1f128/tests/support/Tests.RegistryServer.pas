{ Tests.RegistryServer -- deterministic multi-request loopback registry. }
unit Tests.RegistryServer;

{$mode delphi}{$H+}

interface

uses
  {$IFDEF UNIX}
  Sockets,
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  WinSock2,
  {$ENDIF}
  Classes,
  SysUtils;

type
  {$IF DEFINED(UNIX) OR DEFINED(MSWINDOWS)}
  TRegistryTestSocket = TSocket;
  {$ELSE}
  TRegistryTestSocket = PtrUInt;
  {$ENDIF}

  TRegistryHTTPRoute = record
    Path: string;
    MediaType: string;
    Status: Integer;
    Body: TBytes;
    { Optional bounded response barrier for concurrent transfer tests. }
    Gate: PRTLEvent;
    GateTimeoutMilliseconds: Cardinal;
    GateRequestLimit: Integer;
    Arrived: PLongInt;
  end;
  TRegistryHTTPRouteArray = array of TRegistryHTTPRoute;
  { Optional dynamic responder for targets without a static route. It runs on
    the serving thread and must be safe for concurrent calls. }
  TRegistryHTTPRouteHandler = function(const ATarget: string;
    out AMediaType: string; out ABody: TBytes): Integer of object;
  { Optional raw responder. It receives the complete request, the head and
    its Content-Length body, and returns the complete response bytes, so a
    test can play any status line and headers or relay to another server.
    It takes precedence over routes and Handler and runs on the serving
    thread. }
  TRegistryHTTPRawHandler = function(const ARequest: TBytes): TBytes of object;

  TRegistryTestServer = class
  private
    FListenSocket: TRegistryTestSocket;
    FPort: Word;
    FRequestCount: Integer;
    FAcceptedCount: Integer;
    FRoutes: TRegistryHTTPRouteArray;
    FStopping: LongInt;
    FStarted: Boolean;
    FThread: TThread;
    FError: string;
    FConcurrent: Boolean;
    FClients: TList;
    FHandler: TRegistryHTTPRouteHandler;
    FRawHandler: TRegistryHTTPRawHandler;
    FRequestLock: TRTLCriticalSection;
    FRequestedTargets, FRequestedHosts: TStringList;
    {$IFDEF MSWINDOWS}
    FWinSockStarted: Boolean;
    {$ENDIF}
    procedure Serve;
    procedure ServeClient(const AClient: TRegistryTestSocket);
    function StopRequested: Boolean;
  public
    { APort 0 lets the kernel choose; a fixed port lets a test occupy it. }
    constructor Create(const ARoutes: TRegistryHTTPRouteArray;
      const AConcurrent: Boolean = False; const APort: Word = 0);
    destructor Destroy; override;
    procedure SetRoutes(const ARoutes: TRegistryHTTPRouteArray);
    procedure Start;
    function WaitForRequests(const ACount: Integer;
      const ATimeoutMilliseconds: Cardinal = 5000): Boolean;
    { A snapshot of request targets in arrival order; the caller owns it. }
    function RequestedTargets: TStringList;
    { Host header values in arrival order; the caller owns the list. }
    function RequestedHosts: TStringList;
    property Handler: TRegistryHTTPRouteHandler read FHandler write FHandler;
    property RawHandler: TRegistryHTTPRawHandler read FRawHandler write FRawHandler;
    property Port: Word read FPort;
    property RequestCount: Integer read FRequestCount;
    property AcceptedCount: Integer read FAcceptedCount;
  end;

function RegistryRoute(const APath, AMediaType: string;
  const ABody: TBytes; const AStatus: Integer = 200): TRegistryHTTPRoute;

implementation

{$IFDEF UNIX}
uses
  BaseUnix;
{$ENDIF}

const
  CRLF = #13#10;
  CLIENT_IO_TIMEOUT_MS = 2000;
  {$IFDEF LINUX}
  TEST_SEND_FLAGS = $4000; { MSG_NOSIGNAL, as in the native registry listener. }
  {$ELSE}
  TEST_SEND_FLAGS = 0;
  {$ENDIF}
  {$IFDEF DARWIN}
  TEST_SO_NOSIGPIPE = $1022;
  {$ENDIF}

type
  TRegistryClientThread = class(TThread)
  private
    FOwner: TRegistryTestServer;
    FSocket: TRegistryTestSocket;
  protected
    procedure Execute; override;
  public
    constructor Create(AOwner: TRegistryTestServer; const ASocket: TRegistryTestSocket);
  end;

  TRegistryServerThread = class(TThread)
  private
    FOwner: TRegistryTestServer;
  protected
    procedure Execute; override;
  public
    constructor Create(AOwner: TRegistryTestServer);
  end;

function RegistryRoute(const APath, AMediaType: string;
  const ABody: TBytes; const AStatus: Integer): TRegistryHTTPRoute;
begin
  Result := Default(TRegistryHTTPRoute);
  Result.GateTimeoutMilliseconds := 5000;
  Result.Path := APath;
  Result.MediaType := AMediaType;
  Result.Status := AStatus;
  Result.Body := Copy(ABody, 0, Length(ABody));
end;

function InvalidSocketValue: TRegistryTestSocket;
begin
  {$IFDEF UNIX}
  Result := -1;
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  Result := INVALID_SOCKET;
  {$ENDIF}
end;

function SocketIsValid(const ASocket: TRegistryTestSocket): Boolean;
begin
  {$IFDEF UNIX}
  Result := ASocket >= 0;
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  Result := ASocket <> INVALID_SOCKET;
  {$ENDIF}
end;

procedure CloseTestSocket(var ASocket: TRegistryTestSocket);
var
  SocketToClose: TRegistryTestSocket;
begin
  if not SocketIsValid(ASocket) then Exit;
  SocketToClose := ASocket;
  ASocket := InvalidSocketValue;
  {$IFDEF UNIX}
  CloseSocket(SocketToClose);
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  WinSock2.closesocket(SocketToClose);
  {$ENDIF}
end;

function PrepareClient(const ASocket: TRegistryTestSocket): Boolean;
var
  {$IFDEF UNIX}
  Flags: LongInt;
  {$ELSE}
  Mode: u_long;
  {$ENDIF}
  {$IFDEF DARWIN}
  Enabled: LongInt;
  {$ENDIF}
begin
  {$IFDEF UNIX}
  Flags := fpFcntl(ASocket, F_GETFL, 0);
  Result := (Flags >= 0) and (fpFcntl(ASocket, F_SETFL, Flags or O_NONBLOCK) = 0);
  {$ELSE}
  Mode := 1;
  Result := WinSock2.ioctlsocket(ASocket, LongInt(FIONBIO), Mode) = 0;
  {$ENDIF}
  {$IFDEF DARWIN}
  Enabled := 1;
  Result := Result and (fpSetSockOpt(ASocket, SOL_SOCKET, TEST_SO_NOSIGPIPE,
    @Enabled, SizeOf(Enabled)) = 0);
  {$ENDIF}
end;

function RetrySocket: Boolean;
var
  Code: Integer;
begin
  {$IFDEF UNIX}
  Code := fpGetErrNo;
  Result := (Code = ESysEAGAIN) or (Code = ESysEWOULDBLOCK) or (Code = ESysEINTR);
  {$ELSE}
  Code := WSAGetLastError;
  Result := (Code = WSAEWOULDBLOCK) or (Code = WSAEINTR);
  {$ENDIF}
end;

function TRegistryTestServer.StopRequested: Boolean;
begin
  Result := InterlockedCompareExchange(FStopping, 0, 0) <> 0;
end;

function SendBytes(AOwner: TRegistryTestServer; const ASocket: TRegistryTestSocket;
  const ABytes: TBytes): Boolean;
var
  Sent, Offset: Integer;
  Started: QWord;
begin
  Offset := 0;
  Started := GetTickCount64;
  while Offset < Length(ABytes) do
  begin
    if AOwner.StopRequested or (GetTickCount64 - Started >= CLIENT_IO_TIMEOUT_MS) then Exit(False);
    {$IFDEF UNIX}
    Sent := fpSend(ASocket, @ABytes[Offset], Length(ABytes) - Offset, TEST_SEND_FLAGS);
    {$ENDIF}
    {$IFDEF MSWINDOWS}
    Sent := WinSock2.send(ASocket, PAnsiChar(@ABytes[Offset]),
      Length(ABytes) - Offset, 0);
    {$ENDIF}
    if (Sent < 0) and RetrySocket then
    begin
      Sleep(1);
      Continue;
    end;
    if Sent <= 0 then Exit(False);
    Inc(Offset, Sent);
  end;
  Result := True;
end;

function ReceiveRequest(AOwner: TRegistryTestServer; const ASocket: TRegistryTestSocket): string;
var
  Buffer: array[0..4095] of Byte;
  Received: Integer;
  Chunk: AnsiString;
  Started: QWord;
begin
  Result := '';
  Started := GetTickCount64;
  repeat
    if AOwner.StopRequested or (GetTickCount64 - Started >= CLIENT_IO_TIMEOUT_MS) then Exit('');
    {$IFDEF UNIX}
    Received := fpRecv(ASocket, @Buffer[0], SizeOf(Buffer), 0);
    {$ENDIF}
    {$IFDEF MSWINDOWS}
    Received := WinSock2.recv(ASocket, PAnsiChar(@Buffer[0]),
      SizeOf(Buffer), 0);
    {$ENDIF}
    if (Received < 0) and RetrySocket then
    begin
      Sleep(1);
      Continue;
    end;
    if Received <= 0 then Exit('');
    SetString(Chunk, PAnsiChar(@Buffer[0]), Received);
    Result := Result + string(Chunk);
    if Pos(CRLF + CRLF, Result) > 0 then Exit;
    if Length(Result) > 65536 then Exit('');
  until False;
end;

{ Completes a request whose head ARequest holds: reads the rest of its
  Content-Length body, bounded in size and time. }
function ReceiveBody(AOwner: TRegistryTestServer; const ASocket: TRegistryTestSocket;
  const ARequest: string): TBytes;
const
  MAXIMUM_BODY_BYTES = 64 * 1024 * 1024;
  BODY_TIMEOUT_MS = 20000;
var
  Buffer: array[0..65535] of Byte;
  Received, HeaderEnd, LineStart, LineEnd: Integer;
  Head, Line: string;
  Declared, Total: Int64;
  Started: QWord;
begin
  Result := BytesOf(ARequest);
  HeaderEnd := Pos(CRLF + CRLF, ARequest);
  if HeaderEnd = 0 then Exit;
  Head := Copy(ARequest, 1, HeaderEnd + 1);
  Declared := 0;
  LineStart := Pos(CRLF, Head) + 2;
  while LineStart < Length(Head) do
  begin
    LineEnd := Pos(CRLF, Copy(Head, LineStart, MaxInt));
    if LineEnd = 0 then Break;
    Line := Copy(Head, LineStart, LineEnd - 1);
    if SameText(Copy(Line, 1, Length('Content-Length:')), 'Content-Length:') then
      Declared := StrToInt64Def(Trim(Copy(Line, Length('Content-Length:') + 1,
        MaxInt)), 0);
    Inc(LineStart, LineEnd + 1);
  end;
  if (Declared <= 0) or (Declared > MAXIMUM_BODY_BYTES) then Exit;
  Total := HeaderEnd + 3 + Declared;
  Started := GetTickCount64;
  while Length(Result) < Total do
  begin
    if AOwner.StopRequested or (GetTickCount64 - Started >= BODY_TIMEOUT_MS) then Exit;
    {$IFDEF UNIX}
    Received := fpRecv(ASocket, @Buffer[0], SizeOf(Buffer), 0);
    {$ENDIF}
    {$IFDEF MSWINDOWS}
    Received := WinSock2.recv(ASocket, PAnsiChar(@Buffer[0]), SizeOf(Buffer), 0);
    {$ENDIF}
    if (Received < 0) and RetrySocket then
    begin
      Sleep(1);
      Continue;
    end;
    if Received <= 0 then Exit;
    SetLength(Result, Length(Result) + Received);
    Move(Buffer[0], Result[Length(Result) - Received], Received);
  end;
end;

function RequestPath(const ARequest: string): string;
var
  FirstSpace, SecondSpace: Integer;
begin
  FirstSpace := Pos(' ', ARequest);
  if FirstSpace = 0 then Exit('');
  SecondSpace := Pos(' ', Copy(ARequest, FirstSpace + 1, MaxInt));
  if SecondSpace = 0 then Exit('');
  Result := Copy(ARequest, FirstSpace + 1, SecondSpace - 1);
end;

function RequestHost(const ARequest: string): string;
var
  Start, Finish: Integer;
begin
  Result := '';
  Start := Pos(CRLF + 'Host: ', ARequest);
  if Start = 0 then Exit;
  Inc(Start, Length(CRLF + 'Host: '));
  Finish := Pos(CRLF, Copy(ARequest, Start, MaxInt));
  if Finish > 0 then Result := Copy(ARequest, Start, Finish - 1);
end;

function ResponseBytes(const AStatus: Integer; const AMediaType: string;
  const ABody: TBytes): TBytes;
var
  Head, Reason: string;
begin
  case AStatus of
    200: Reason := 'OK';
    404: Reason := 'Not Found';
    500: Reason := 'Internal Server Error';
  else
    Reason := 'Test Response';
  end;
  Head := 'HTTP/1.1 ' + IntToStr(AStatus) + ' ' + Reason + CRLF
    + 'Content-Type: ' + AMediaType + CRLF
    + 'Content-Length: ' + IntToStr(Length(ABody)) + CRLF
    + 'Connection: close' + CRLF + CRLF;
  SetLength(Result, Length(Head) + Length(ABody));
  if Head <> '' then Move(Head[1], Result[0], Length(Head));
  if Length(ABody) > 0 then
    Move(ABody[0], Result[Length(Head)], Length(ABody));
end;

constructor TRegistryServerThread.Create(AOwner: TRegistryTestServer);
begin
  inherited Create(True);
  FreeOnTerminate := False;
  FOwner := AOwner;
end;

procedure TRegistryServerThread.Execute;
begin
  FOwner.Serve;
end;

constructor TRegistryTestServer.Create(
  const ARoutes: TRegistryHTTPRouteArray; const AConcurrent: Boolean;
  const APort: Word);
var
  Addr: {$IFDEF UNIX}TInetSockAddr{$ELSE}TSockAddrIn{$ENDIF};
  AddrLength: LongInt;
  {$IFDEF MSWINDOWS}
  WinSockData: TWSAData;
  {$ENDIF}
begin
  inherited Create;
  FConcurrent := AConcurrent;
  FClients := TList.Create;
  InitCriticalSection(FRequestLock);
  FRequestedTargets := TStringList.Create;
  FRequestedHosts := TStringList.Create;
  FListenSocket := InvalidSocketValue;
  SetRoutes(ARoutes);
  {$IFDEF MSWINDOWS}
  if WSAStartup($0202, WinSockData) <> 0 then
    raise Exception.Create('registry test server WSAStartup failed');
  FWinSockStarted := True;
  {$ENDIF}
  {$IFDEF UNIX}
  FListenSocket := fpSocket(AF_INET, SOCK_STREAM, 0);
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  FListenSocket := WinSock2.socket(AF_INET, SOCK_STREAM, 0);
  {$ENDIF}
  if not SocketIsValid(FListenSocket) then
    raise Exception.Create('registry test server socket failed');
  FillChar(Addr, SizeOf(Addr), 0);
  Addr.sin_family := AF_INET;
  {$IFDEF UNIX}
  Addr.sin_addr := StrToNetAddr('127.0.0.1');
  Addr.sin_port := htons(APort);
  if fpBind(FListenSocket, @Addr, SizeOf(Addr)) <> 0 then
    raise Exception.Create('registry test server bind failed');
  if fpListen(FListenSocket, 16) <> 0 then
    raise Exception.Create('registry test server listen failed');
  AddrLength := SizeOf(Addr);
  if fpGetSockName(FListenSocket, @Addr, @AddrLength) <> 0 then
    raise Exception.Create('registry test server getsockname failed');
  FPort := ntohs(Addr.sin_port);
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  Addr.sin_addr.S_addr := WinSock2.inet_addr('127.0.0.1');
  Addr.sin_port := WinSock2.htons(APort);
  if WinSock2.bind(FListenSocket, PSockAddr(@Addr), SizeOf(Addr)) <> 0 then
    raise Exception.Create('registry test server bind failed');
  if WinSock2.listen(FListenSocket, 16) <> 0 then
    raise Exception.Create('registry test server listen failed');
  AddrLength := SizeOf(Addr);
  if WinSock2.getsockname(FListenSocket, Addr, AddrLength) <> 0 then
    raise Exception.Create('registry test server getsockname failed');
  FPort := WinSock2.ntohs(Addr.sin_port);
  {$ENDIF}
  FThread := TRegistryServerThread.Create(Self);
end;

procedure TRegistryTestServer.SetRoutes(
  const ARoutes: TRegistryHTTPRouteArray);
var
  I: Integer;
begin
  if FStarted then
    raise Exception.Create('cannot replace routes after server start');
  SetLength(FRoutes, Length(ARoutes));
  for I := 0 to High(ARoutes) do FRoutes[I] := ARoutes[I];
end;

destructor TRegistryTestServer.Destroy;
var
  I: Integer;
  WakeSocket: TRegistryTestSocket;
  Addr: {$IFDEF UNIX}TInetSockAddr{$ELSE}TSockAddrIn{$ENDIF};
begin
  InterlockedExchange(FStopping, 1);
  { A caller may release a reserved listener or fail while preparing routes
    before Start. Let its suspended worker observe FStopping before joining. }
  if Assigned(FThread) and not FStarted then FThread.Start;
  if Assigned(FThread) and (not FThread.Finished) then
  begin
    {$IFDEF UNIX}
    WakeSocket := fpSocket(AF_INET, SOCK_STREAM, 0);
    {$ENDIF}
    {$IFDEF MSWINDOWS}
    WakeSocket := WinSock2.socket(AF_INET, SOCK_STREAM, 0);
    {$ENDIF}
    if SocketIsValid(WakeSocket) then
    begin
      FillChar(Addr, SizeOf(Addr), 0);
      Addr.sin_family := AF_INET;
      Addr.sin_port := {$IFDEF UNIX}htons{$ELSE}WinSock2.htons{$ENDIF}(FPort);
      {$IFDEF UNIX}
      Addr.sin_addr := StrToNetAddr('127.0.0.1');
      fpConnect(WakeSocket, @Addr, SizeOf(Addr));
      {$ENDIF}
      {$IFDEF MSWINDOWS}
      Addr.sin_addr.S_addr := WinSock2.inet_addr('127.0.0.1');
      WinSock2.connect(WakeSocket, PSockAddr(@Addr), SizeOf(Addr));
      {$ENDIF}
      CloseTestSocket(WakeSocket);
    end;
    FThread.WaitFor;
  end;
  FThread.Free;
  if Assigned(FClients) then
    for I := 0 to FClients.Count - 1 do TObject(FClients[I]).Free;
  FClients.Free;
  FRequestedTargets.Free;
  FRequestedHosts.Free;
  DoneCriticalSection(FRequestLock);
  CloseTestSocket(FListenSocket);
  {$IFDEF MSWINDOWS}
  if FWinSockStarted then WinSock2.WSACleanup;
  {$ENDIF}
  inherited Destroy;
end;

procedure TRegistryTestServer.Start;
begin
  FStarted := True;
  FThread.Start;
end;

constructor TRegistryClientThread.Create(AOwner: TRegistryTestServer;
  const ASocket: TRegistryTestSocket);
begin
  inherited Create(True);
  FreeOnTerminate := False;
  FOwner := AOwner;
  FSocket := ASocket;
end;

procedure TRegistryClientThread.Execute;
begin
  try
    FOwner.ServeClient(FSocket);
  finally
    CloseTestSocket(FSocket);
  end;
end;

procedure TRegistryTestServer.ServeClient(const AClient: TRegistryTestSocket);
var
  I, Arrival, Status: Integer;
  Request, Path, MediaType: string;
  Response, Body: TBytes;
begin
  Request := ReceiveRequest(Self, AClient);
  if Request = '' then Exit;
  Path := RequestPath(Request);
  EnterCriticalSection(FRequestLock);
  try
    FRequestedTargets.Add(Path);
    FRequestedHosts.Add(RequestHost(Request));
  finally
    LeaveCriticalSection(FRequestLock);
  end;
  InterlockedIncrement(FRequestCount);
  if Assigned(FRawHandler) then
  begin
    try
      Response := FRawHandler(ReceiveBody(Self, AClient, Request));
    except
      on E: Exception do
        Response := ResponseBytes(500, 'text/plain',
          BytesOf('raw handler failed: ' + E.Message));
    end;
    SendBytes(Self, AClient, Response);
    Exit;
  end;
  for I := 0 to High(FRoutes) do
    if FRoutes[I].Path = Path then
    begin
      Arrival := 0;
      if Assigned(FRoutes[I].Arrived) then Arrival := InterlockedIncrement(FRoutes[I].Arrived^);
      if Assigned(FRoutes[I].Gate) and ((FRoutes[I].GateRequestLimit = 0)
        or (Arrival <= FRoutes[I].GateRequestLimit)) then
        RTLEventWaitFor(FRoutes[I].Gate, FRoutes[I].GateTimeoutMilliseconds);
      Response := ResponseBytes(FRoutes[I].Status, FRoutes[I].MediaType, FRoutes[I].Body);
      SendBytes(Self, AClient, Response);
      Exit;
    end;
  if Assigned(FHandler) then
  begin
    try
      Status := FHandler(Path, MediaType, Body);
    except
      on E: Exception do
      begin
        Status := 500;
        MediaType := 'text/plain';
        Body := BytesOf('route handler failed: ' + E.Message);
      end;
    end;
    SendBytes(Self, AClient, ResponseBytes(Status, MediaType, Body));
    Exit;
  end;
  Response := ResponseBytes(404, 'text/plain', BytesOf('missing route: ' + Path));
  SendBytes(Self, AClient, Response);
end;

function TRegistryTestServer.RequestedHosts: TStringList;
begin
  Result := TStringList.Create;
  EnterCriticalSection(FRequestLock);
  try
    Result.Assign(FRequestedHosts);
  finally
    LeaveCriticalSection(FRequestLock);
  end;
end;

function TRegistryTestServer.RequestedTargets: TStringList;
begin
  Result := TStringList.Create;
  EnterCriticalSection(FRequestLock);
  try
    Result.Assign(FRequestedTargets);
  finally
    LeaveCriticalSection(FRequestLock);
  end;
end;

procedure TRegistryTestServer.Serve;
var
  Client: TRegistryTestSocket;
  Worker: TRegistryClientThread;
  Addr: {$IFDEF UNIX}TInetSockAddr{$ELSE}TSockAddrIn{$ENDIF};
  AddrLength: LongInt;
begin
  try
    while not StopRequested do
    begin
      AddrLength := SizeOf(Addr);
      {$IFDEF UNIX}
      Client := fpAccept(FListenSocket, @Addr, @AddrLength);
      {$ENDIF}
      {$IFDEF MSWINDOWS}
      Client := WinSock2.accept(FListenSocket, PSockAddr(@Addr), @AddrLength);
      {$ENDIF}
      if not SocketIsValid(Client) then Continue;
      InterlockedIncrement(FAcceptedCount);
      try
        if StopRequested or not PrepareClient(Client) then Continue;
        if FConcurrent then
        begin
          Worker := TRegistryClientThread.Create(Self, Client);
          FClients.Add(Worker);
          Client := InvalidSocketValue;
          Worker.Start;
        end
        else ServeClient(Client);
      finally
        CloseTestSocket(Client);
      end;
    end;
  except
    on E: Exception do FError := E.Message;
  end;
end;

function TRegistryTestServer.WaitForRequests(const ACount: Integer;
  const ATimeoutMilliseconds: Cardinal): Boolean;
var
  Started: QWord;
begin
  Started := GetTickCount64;
  while (FRequestCount < ACount)
    and (GetTickCount64 - Started < ATimeoutMilliseconds) do Sleep(1);
  if FError <> '' then
    raise Exception.Create('registry test server failed: ' + FError);
  Result := FRequestCount >= ACount;
end;

end.
